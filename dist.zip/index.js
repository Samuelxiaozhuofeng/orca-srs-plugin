var Aa = Object.defineProperty;
var Ba = (e, t, r) => t in e ? Aa(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var ce = (e, t, r) => Ba(e, typeof t != "symbol" ? t + "" : t, r);
function Ao(e) {
  return e && e.replace(/#[\w/\u4e00-\u9fa5]+/g, "").trim();
}
function Qr(e) {
  var r, n;
  const t = (r = e._repr) == null ? void 0 : r.type;
  return t === "srs.card" || t === "srs.cloze-card" || ((n = e.properties) == null ? void 0 : n.some((a) => a.name === "srs.isCard"));
}
function Fa(e) {
  var n;
  if (!(e != null && e.children) || e.children.length === 0) return "（无答案）";
  const t = e.children[0], r = (n = orca.state.blocks) == null ? void 0 : n[t];
  return (r == null ? void 0 : r.text) || "（无答案）";
}
function cr(e) {
  var s, i;
  const t = ((s = e._repr) == null ? void 0 : s.front) ?? e.text ?? "（无题目）", r = ((i = e._repr) == null ? void 0 : i.back) ?? Fa(e), n = Ao(t), a = Ao(r);
  return { front: n, back: a };
}
function Me(e) {
  return (e == null ? void 0 : e.toLowerCase()) === "card";
}
const Qe = "Default", Pa = "牌组", kr = /* @__PURE__ */ new Map();
function gt(e) {
  if (!e.refs || e.refs.length === 0)
    return "basic";
  const t = e.refs.find(
    (a) => a.type === 2 && // RefType.Property（标签引用）
    Me(a.alias)
    // 标签名称为 "card"（大小写不敏感）
  );
  if (!t || !t.data || t.data.length === 0)
    return "basic";
  const r = t.data.find((a) => a.name === "type");
  if (!r)
    return "basic";
  const n = r.value;
  if (Array.isArray(n)) {
    if (n.length === 0 || !n[0] || typeof n[0] != "string")
      return "basic";
    const a = n[0].trim().toLowerCase();
    return a === "cloze" ? "cloze" : a === "direction" ? "direction" : a === "excerpt" ? "excerpt" : "basic";
  } else if (typeof n == "string") {
    const a = n.trim().toLowerCase();
    return a === "cloze" ? "cloze" : a === "direction" ? "direction" : a === "excerpt" ? "excerpt" : "basic";
  }
  return "basic";
}
async function Bt(e) {
  if (!e.refs || e.refs.length === 0)
    return Qe;
  const t = e.refs.find(
    (c) => c.type === 2 && // RefType.Property（标签引用）
    Me(c.alias)
    // 标签名称为 "card"（大小写不敏感）
  );
  if (!t || !t.data || t.data.length === 0)
    return Qe;
  const r = t.data.find((c) => c.name === Pa);
  if (!r)
    return Qe;
  const n = r.value;
  if (!Array.isArray(n) || n.length === 0)
    return Qe;
  const a = La(n[0]);
  if (!a)
    return Qe;
  const s = e.refs.find((c) => c.id === a);
  if (!s)
    return Qe;
  const i = await Wa(s.to);
  return i || Qe;
}
function La(e) {
  if (typeof e == "number" && Number.isFinite(e)) return e;
  if (typeof e == "string" && e.trim() !== "") {
    const t = Number(e);
    if (Number.isFinite(t)) return t;
  }
  return null;
}
async function Wa(e) {
  var i, c, l;
  const t = kr.get(e);
  if (t !== void 0) return t;
  const r = (i = orca.state.blocks) == null ? void 0 : i[e], n = (c = r == null ? void 0 : r.text) == null ? void 0 : c.trim();
  if (n)
    return kr.set(e, n), n;
  const a = await orca.invokeBackend("get-block", e), s = (l = a == null ? void 0 : a.text) == null ? void 0 : l.trim();
  return s ? (kr.set(e, s), s) : null;
}
function mn(e) {
  const t = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Date(), n = r.getTime(), a = new Date(r.getFullYear(), r.getMonth(), r.getDate()), s = new Date(a);
  s.setDate(s.getDate() + 1);
  for (const c of e) {
    const l = c.deck;
    t.has(l) || t.set(l, {
      name: l,
      totalCount: 0,
      newCount: 0,
      overdueCount: 0,
      todayCount: 0,
      futureCount: 0
    });
    const d = t.get(l);
    d.totalCount++, c.isNew ? d.newCount++ : c.srs.due.getTime() <= n ? d.overdueCount++ : c.srs.due >= a && c.srs.due < s ? d.todayCount++ : d.futureCount++;
  }
  const i = Array.from(t.values());
  return i.sort((c, l) => c.name === "Default" && l.name !== "Default" ? -1 : c.name !== "Default" && l.name === "Default" ? 1 : c.name.localeCompare(l.name)), {
    decks: i,
    totalCards: e.length,
    totalNew: e.filter((c) => c.isNew).length,
    totalOverdue: e.filter((c) => c.isNew ? !1 : c.srs.due.getTime() <= n).length
  };
}
function Oa(e) {
  const t = /* @__PURE__ */ new Date(), r = t.getTime(), n = new Date(t.getFullYear(), t.getMonth(), t.getDate()), a = new Date(n);
  a.setDate(a.getDate() + 1);
  let s = 0, i = 0, c = 0;
  const l = e.length;
  for (const d of e)
    d.isNew ? i++ : d.srs.due.getTime() <= r && (c++, d.srs.due >= n && d.srs.due < a && s++);
  return {
    todayCount: s,
    newCount: i,
    pendingCount: c,
    totalCount: l
  };
}
const Bo = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  calculateDeckStats: mn,
  calculateHomeStats: Oa,
  extractCardType: gt,
  extractDeckName: Bt
}, Symbol.toStringTag, { value: "Module" }));
var I = /* @__PURE__ */ ((e) => (e[e.New = 0] = "New", e[e.Learning = 1] = "Learning", e[e.Review = 2] = "Review", e[e.Relearning = 3] = "Relearning", e))(I || {}), E = /* @__PURE__ */ ((e) => (e[e.Manual = 0] = "Manual", e[e.Again = 1] = "Again", e[e.Hard = 2] = "Hard", e[e.Good = 3] = "Good", e[e.Easy = 4] = "Easy", e))(E || {});
class K {
  static card(t) {
    return {
      ...t,
      state: K.state(t.state),
      due: K.time(t.due),
      last_review: t.last_review ? K.time(t.last_review) : void 0
    };
  }
  static rating(t) {
    if (typeof t == "string") {
      const r = t.charAt(0).toUpperCase(), n = t.slice(1).toLowerCase(), a = E[`${r}${n}`];
      if (a === void 0)
        throw new Error(`Invalid rating:[${t}]`);
      return a;
    } else if (typeof t == "number")
      return t;
    throw new Error(`Invalid rating:[${t}]`);
  }
  static state(t) {
    if (typeof t == "string") {
      const r = t.charAt(0).toUpperCase(), n = t.slice(1).toLowerCase(), a = I[`${r}${n}`];
      if (a === void 0)
        throw new Error(`Invalid state:[${t}]`);
      return a;
    } else if (typeof t == "number")
      return t;
    throw new Error(`Invalid state:[${t}]`);
  }
  static time(t) {
    const r = new Date(t);
    if (typeof t == "object" && t !== null && !Number.isNaN(Date.parse(t) || +r))
      return r;
    if (typeof t == "string") {
      const n = Date.parse(t);
      if (Number.isNaN(n))
        throw new Error(`Invalid date:[${t}]`);
      return new Date(n);
    } else if (typeof t == "number")
      return new Date(t);
    throw new Error(`Invalid date:[${t}]`);
  }
  static review_log(t) {
    return {
      ...t,
      due: K.time(t.due),
      rating: K.rating(t.rating),
      state: K.state(t.state),
      review: K.time(t.review)
    };
  }
}
Date.prototype.scheduler = function(e, t) {
  return We(this, e, t);
};
Date.prototype.diff = function(e, t) {
  return xt(this, e, t);
};
Date.prototype.format = function() {
  return Ha(this);
};
Date.prototype.dueFormat = function(e, t, r) {
  return Ia(this, e, t, r);
};
function We(e, t, r) {
  return new Date(
    r ? K.time(e).getTime() + t * 24 * 60 * 60 * 1e3 : K.time(e).getTime() + t * 60 * 1e3
  );
}
function xt(e, t, r) {
  if (!e || !t)
    throw new Error("Invalid date");
  const n = K.time(e).getTime() - K.time(t).getTime();
  let a = 0;
  switch (r) {
    case "days":
      a = Math.floor(n / (24 * 60 * 60 * 1e3));
      break;
    case "minutes":
      a = Math.floor(n / (60 * 1e3));
      break;
  }
  return a;
}
function Ha(e) {
  const t = K.time(e), r = t.getFullYear(), n = t.getMonth() + 1, a = t.getDate(), s = t.getHours(), i = t.getMinutes(), c = t.getSeconds();
  return `${r}-${bt(n)}-${bt(a)} ${bt(s)}:${bt(
    i
  )}:${bt(c)}`;
}
function bt(e) {
  return e < 10 ? `0${e}` : `${e}`;
}
const Rr = [60, 60, 24, 31, 12], $r = ["second", "min", "hour", "day", "month", "year"];
function Ia(e, t, r, n = $r) {
  e = K.time(e), t = K.time(t), n.length !== $r.length && (n = $r);
  let a = e.getTime() - t.getTime(), s = 0;
  for (a /= 1e3, s = 0; s < Rr.length && !(a < Rr[s]); s++)
    a /= Rr[s];
  return `${Math.floor(a)}${r ? n[s] : ""}`;
}
const Na = Object.freeze([
  E.Again,
  E.Hard,
  E.Good,
  E.Easy
]), Ya = [
  {
    start: 2.5,
    end: 7,
    factor: 0.15
  },
  {
    start: 7,
    end: 20,
    factor: 0.1
  },
  {
    start: 20,
    end: 1 / 0,
    factor: 0.05
  }
];
function Ua(e, t, r) {
  let n = 1;
  for (const i of Ya)
    n += i.factor * Math.max(Math.min(e, i.end) - i.start, 0);
  e = Math.min(e, r);
  let a = Math.max(2, Math.round(e - n));
  const s = Math.min(Math.round(e + n), r);
  return e > t && (a = Math.max(a, t + 1)), a = Math.min(a, s), { min_ivl: a, max_ivl: s };
}
function Re(e, t, r) {
  return Math.min(Math.max(e, t), r);
}
function qa(e, t) {
  const r = Date.UTC(
    e.getUTCFullYear(),
    e.getUTCMonth(),
    e.getUTCDate()
  ), n = Date.UTC(
    t.getUTCFullYear(),
    t.getUTCMonth(),
    t.getUTCDate()
  );
  return Math.floor(
    (n - r) / 864e5
    /** 1000 * 60 * 60 * 24*/
  );
}
const Va = (e) => {
  const t = e.slice(-1), r = parseInt(e.slice(0, -1), 10);
  if (Number.isNaN(r) || !Number.isFinite(r) || r < 0)
    throw new Error(`Invalid step value: ${e}`);
  switch (t) {
    case "m":
      return r;
    case "h":
      return r * 60;
    case "d":
      return r * 1440;
    default:
      throw new Error(`Invalid step unit: ${e}, expected m/h/d`);
  }
}, Ka = (e, t, r) => {
  const n = t === I.Relearning || t === I.Review ? e.relearning_steps : e.learning_steps, a = n.length;
  if (a === 0 || r >= a) return {};
  const s = n[0], i = Va, c = () => i(s), l = () => {
    if (a === 1) return Math.round(i(s) * 1.5);
    const h = n[1];
    return Math.round((i(s) + i(h)) / 2);
  }, d = (h) => h < 0 || h >= a ? null : n[h], u = (h) => i(h), f = {}, x = d(Math.max(0, r));
  if (t === I.Review)
    return f[E.Again] = {
      scheduled_minutes: i(x),
      next_step: 0
    }, f;
  {
    f[E.Again] = {
      scheduled_minutes: c(),
      next_step: 0
    }, f[E.Hard] = {
      scheduled_minutes: l(),
      next_step: r
    };
    const h = d(r + 1);
    if (h) {
      const y = u(h);
      y && (f[E.Good] = {
        scheduled_minutes: Math.round(y),
        next_step: r + 1
      });
    }
  }
  return f;
};
function Ga() {
  const e = this.review_time.getTime(), t = this.current.reps, r = this.current.difficulty * this.current.stability;
  return `${e}_${t}_${r}`;
}
var dr = /* @__PURE__ */ ((e) => (e.SCHEDULER = "Scheduler", e.LEARNING_STEPS = "LearningSteps", e.SEED = "Seed", e))(dr || {});
class vn {
  // init
  constructor(t, r, n, a) {
    ce(this, "last");
    ce(this, "current");
    ce(this, "review_time");
    ce(this, "next", /* @__PURE__ */ new Map());
    ce(this, "algorithm");
    ce(this, "strategies");
    ce(this, "elapsed_days", 0);
    this.algorithm = n, this.last = K.card(t), this.current = K.card(t), this.review_time = K.time(r), this.strategies = a, this.init();
  }
  checkGrade(t) {
    if (!Number.isFinite(t) || t < 0 || t > 4)
      throw new Error(`Invalid grade "${t}",expected 1-4`);
  }
  init() {
    const { state: t, last_review: r } = this.current;
    let n = 0;
    t !== I.New && r && (n = qa(r, this.review_time)), this.current.last_review = this.review_time, this.elapsed_days = n, this.current.elapsed_days = n, this.current.reps += 1;
    let a = Ga;
    if (this.strategies) {
      const s = this.strategies.get(dr.SEED);
      s && (a = s);
    }
    this.algorithm.seed = a.call(this);
  }
  preview() {
    return {
      [E.Again]: this.review(E.Again),
      [E.Hard]: this.review(E.Hard),
      [E.Good]: this.review(E.Good),
      [E.Easy]: this.review(E.Easy),
      [Symbol.iterator]: this.previewIterator.bind(this)
    };
  }
  *previewIterator() {
    for (const t of Na)
      yield this.review(t);
  }
  review(t) {
    const { state: r } = this.last;
    let n;
    switch (this.checkGrade(t), r) {
      case I.New:
        n = this.newState(t);
        break;
      case I.Learning:
      case I.Relearning:
        n = this.learningState(t);
        break;
      case I.Review:
        n = this.reviewState(t);
        break;
    }
    return n;
  }
  buildLog(t) {
    const { last_review: r, due: n, elapsed_days: a } = this.last;
    return {
      rating: t,
      state: this.current.state,
      due: r || n,
      stability: this.current.stability,
      difficulty: this.current.difficulty,
      elapsed_days: this.elapsed_days,
      last_elapsed_days: a,
      scheduled_days: this.current.scheduled_days,
      learning_steps: this.current.learning_steps,
      review: this.review_time
    };
  }
}
class Ja {
  constructor(t) {
    ce(this, "c");
    ce(this, "s0");
    ce(this, "s1");
    ce(this, "s2");
    const r = Qa();
    this.c = 1, this.s0 = r(" "), this.s1 = r(" "), this.s2 = r(" "), t == null && (t = Date.now()), this.s0 -= r(t), this.s0 < 0 && (this.s0 += 1), this.s1 -= r(t), this.s1 < 0 && (this.s1 += 1), this.s2 -= r(t), this.s2 < 0 && (this.s2 += 1);
  }
  next() {
    const t = 2091639 * this.s0 + this.c * 23283064365386963e-26;
    return this.s0 = this.s1, this.s1 = this.s2, this.c = t | 0, this.s2 = t - this.c, this.s2;
  }
  set state(t) {
    this.c = t.c, this.s0 = t.s0, this.s1 = t.s1, this.s2 = t.s2;
  }
  get state() {
    return {
      c: this.c,
      s0: this.s0,
      s1: this.s1,
      s2: this.s2
    };
  }
}
function Qa() {
  let e = 4022871197;
  return function(r) {
    r = String(r);
    for (let n = 0; n < r.length; n++) {
      e += r.charCodeAt(n);
      let a = 0.02519603282416938 * e;
      e = a >>> 0, a -= e, a *= e, e = a >>> 0, a -= e, e += a * 4294967296;
    }
    return (e >>> 0) * 23283064365386963e-26;
  };
}
function Xa(e) {
  const t = new Ja(e), r = () => t.next();
  return r.int32 = () => t.next() * 4294967296 | 0, r.double = () => r() + (r() * 2097152 | 0) * 11102230246251565e-32, r.state = () => t.state, r.importState = (n) => (t.state = n, r), r;
}
const Za = 0.9, es = 36500, ts = !1, ur = !0, rs = Object.freeze([
  "1m",
  "10m"
]), os = Object.freeze([
  "10m"
]), Oe = 1e-3, It = 100, Fo = 0.5, ns = 0.1542, Po = Object.freeze([
  0.212,
  1.2931,
  2.3065,
  8.2956,
  6.4133,
  0.8334,
  3.0194,
  1e-3,
  1.8722,
  0.1666,
  0.796,
  1.4835,
  0.0614,
  0.2629,
  1.6483,
  0.6014,
  1.8729,
  0.5425,
  0.0912,
  0.0658,
  ns
]), as = 2, ss = (e, t = ur) => [
  [Oe, It],
  [Oe, It],
  [Oe, It],
  [Oe, It],
  [1, 10],
  [1e-3, 4],
  [1e-3, 4],
  [1e-3, 0.75],
  [0, 4.5],
  [0, 0.8],
  [1e-3, 3.5],
  [1e-3, 5],
  [1e-3, 0.25],
  [1e-3, 0.9],
  [0, 4],
  [0, 1],
  [1, 6],
  [0, e],
  [0, e],
  [
    t ? 0.01 : 0,
    0.8
  ],
  [0.1, 0.8]
], Dr = (e, t, r = ur) => {
  let n = as;
  if (Math.max(0, t) > 1) {
    const s = -(Math.log(e[11]) + Math.log(Math.pow(2, e[13]) - 1) + e[14] * 0.3) / t;
    n = Re(+s.toFixed(8), 0.01, 2);
  }
  return ss(n, r).slice(
    0,
    e.length
  ).map(
    ([s, i], c) => Re(e[c] || 0, s, i)
  );
}, Xr = (e, t = 0, r = ur) => {
  if (e === void 0)
    return [...Po];
  switch (e.length) {
    case 21:
      return Dr(
        Array.from(e),
        t,
        r
      );
    case 19:
      return console.debug("[FSRS-6]auto fill w from 19 to 21 length"), Dr(
        Array.from(e),
        t,
        r
      ).concat([0, Fo]);
    case 17: {
      const n = Dr(
        Array.from(e),
        t,
        r
      );
      return n[4] = +(n[5] * 2 + n[4]).toFixed(8), n[5] = +(Math.log(n[5] * 3 + 1) / 3).toFixed(8), n[6] = +(n[6] + 0.5).toFixed(8), console.debug("[FSRS-6]auto fill w from 17 to 21 length"), n.concat([0, 0, 0, Fo]);
    }
    default:
      return console.warn("[FSRS]Invalid parameters length, using default parameters"), [...Po];
  }
}, Nr = (e) => {
  const t = Array.isArray(e == null ? void 0 : e.learning_steps) ? e.learning_steps : rs, r = Array.isArray(e == null ? void 0 : e.relearning_steps) ? e.relearning_steps : os, n = (e == null ? void 0 : e.enable_short_term) ?? ur, a = Xr(
    e == null ? void 0 : e.w,
    r.length,
    n
  );
  return {
    request_retention: (e == null ? void 0 : e.request_retention) || Za,
    maximum_interval: (e == null ? void 0 : e.maximum_interval) || es,
    w: a,
    enable_fuzz: (e == null ? void 0 : e.enable_fuzz) ?? ts,
    enable_short_term: n,
    learning_steps: t,
    relearning_steps: r
  };
};
function Tt(e, t) {
  return {
    due: e ? K.time(e) : /* @__PURE__ */ new Date(),
    stability: 0,
    difficulty: 0,
    elapsed_days: 0,
    scheduled_days: 0,
    reps: 0,
    lapses: 0,
    learning_steps: 0,
    state: I.New,
    last_review: void 0
  };
}
const bn = (e) => {
  const t = typeof e == "number" ? -e : -e[20], r = Math.exp(Math.pow(t, -1) * Math.log(0.9)) - 1;
  return { decay: t, factor: +r.toFixed(8) };
};
function Yr(e, t, r) {
  const { decay: n, factor: a } = bn(e);
  return +Math.pow(1 + a * t / r, n).toFixed(8);
}
class is {
  constructor(t) {
    ce(this, "param");
    ce(this, "intervalModifier");
    ce(this, "_seed");
    /**
     * The formula used is :
     * $$R(t,S) = (1 + \text{FACTOR} \times \frac{t}{9 \cdot S})^{\text{DECAY}}$$
     * @param {number} elapsed_days t days since the last review
     * @param {number} stability Stability (interval when R=90%)
     * @return {number} r Retrievability (probability of recall)
     */
    ce(this, "forgetting_curve");
    this.param = new Proxy(
      Nr(t),
      this.params_handler_proxy()
    ), this.intervalModifier = this.calculate_interval_modifier(
      this.param.request_retention
    ), this.forgetting_curve = Yr.bind(this, this.param.w);
  }
  get interval_modifier() {
    return this.intervalModifier;
  }
  set seed(t) {
    this._seed = t;
  }
  /**
   * @see https://github.com/open-spaced-repetition/fsrs4anki/wiki/The-Algorithm#fsrs-5
   *
   * The formula used is: $$I(r,s) = (r^{\frac{1}{DECAY}} - 1) / FACTOR \times s$$
   * @param request_retention 0<request_retention<=1,Requested retention rate
   * @throws {Error} Requested retention rate should be in the range (0,1]
   */
  calculate_interval_modifier(t) {
    if (t <= 0 || t > 1)
      throw new Error("Requested retention rate should be in the range (0,1]");
    const { decay: r, factor: n } = bn(this.param.w);
    return +((Math.pow(t, 1 / r) - 1) / n).toFixed(8);
  }
  /**
   * Get the parameters of the algorithm.
   */
  get parameters() {
    return this.param;
  }
  /**
   * Set the parameters of the algorithm.
   * @param params Partial<FSRSParameters>
   */
  set parameters(t) {
    this.update_parameters(t);
  }
  params_handler_proxy() {
    const t = this;
    return {
      set: function(r, n, a) {
        return n === "request_retention" && Number.isFinite(a) ? t.intervalModifier = t.calculate_interval_modifier(
          Number(a)
        ) : n === "w" && (a = Xr(
          a,
          r.relearning_steps.length,
          r.enable_short_term
        ), t.forgetting_curve = Yr.bind(this, a), t.intervalModifier = t.calculate_interval_modifier(
          Number(r.request_retention)
        )), Reflect.set(r, n, a), !0;
      }
    };
  }
  update_parameters(t) {
    const r = Nr(t);
    for (const n in r) {
      const a = n;
      this.param[a] = r[a];
    }
  }
  /**
     * The formula used is :
     * $$ S_0(G) = w_{G-1}$$
     * $$S_0 = \max \lbrace S_0,0.1\rbrace $$
  
     * @param g Grade (rating at Anki) [1.again,2.hard,3.good,4.easy]
     * @return Stability (interval when R=90%)
     */
  init_stability(t) {
    return Math.max(this.param.w[t - 1], 0.1);
  }
  /**
   * The formula used is :
   * $$D_0(G) = w_4 - e^{(G-1) \cdot w_5} + 1 $$
   * $$D_0 = \min \lbrace \max \lbrace D_0(G),1 \rbrace,10 \rbrace$$
   * where the $$D_0(1)=w_4$$ when the first rating is good.
   *
   * @param {Grade} g Grade (rating at Anki) [1.again,2.hard,3.good,4.easy]
   * @return {number} Difficulty $$D \in [1,10]$$
   */
  init_difficulty(t) {
    return +(this.param.w[4] - Math.exp((t - 1) * this.param.w[5]) + 1).toFixed(8);
  }
  /**
   * If fuzzing is disabled or ivl is less than 2.5, it returns the original interval.
   * @param {number} ivl - The interval to be fuzzed.
   * @param {number} elapsed_days t days since the last review
   * @return {number} - The fuzzed interval.
   **/
  apply_fuzz(t, r) {
    if (!this.param.enable_fuzz || t < 2.5) return Math.round(t);
    const a = Xa(this._seed)(), { min_ivl: s, max_ivl: i } = Ua(
      t,
      r,
      this.param.maximum_interval
    );
    return Math.floor(a * (i - s + 1) + s);
  }
  /**
   *   @see The formula used is : {@link FSRSAlgorithm.calculate_interval_modifier}
   *   @param {number} s - Stability (interval when R=90%)
   *   @param {number} elapsed_days t days since the last review
   */
  next_interval(t, r) {
    const n = Math.min(
      Math.max(1, Math.round(t * this.intervalModifier)),
      this.param.maximum_interval
    );
    return this.apply_fuzz(n, r);
  }
  /**
   * @see https://github.com/open-spaced-repetition/fsrs4anki/issues/697
   */
  linear_damping(t, r) {
    return +(t * (10 - r) / 9).toFixed(8);
  }
  /**
   * The formula used is :
   * $$\text{delta}_d = -w_6 \cdot (g - 3)$$
   * $$\text{next}_d = D + \text{linear damping}(\text{delta}_d , D)$$
   * $$D^\prime(D,R) = w_7 \cdot D_0(4) +(1 - w_7) \cdot \text{next}_d$$
   * @param {number} d Difficulty $$D \in [1,10]$$
   * @param {Grade} g Grade (rating at Anki) [1.again,2.hard,3.good,4.easy]
   * @return {number} $$\text{next}_D$$
   */
  next_difficulty(t, r) {
    const n = -this.param.w[6] * (r - 3), a = t + this.linear_damping(n, t);
    return Re(
      this.mean_reversion(this.init_difficulty(E.Easy), a),
      1,
      10
    );
  }
  /**
   * The formula used is :
   * $$w_7 \cdot \text{init} +(1 - w_7) \cdot \text{current}$$
   * @param {number} init $$w_2 : D_0(3) = w_2 + (R-2) \cdot w_3= w_2$$
   * @param {number} current $$D - w_6 \cdot (R - 2)$$
   * @return {number} difficulty
   */
  mean_reversion(t, r) {
    return +(this.param.w[7] * t + (1 - this.param.w[7]) * r).toFixed(
      8
    );
  }
  /**
   * The formula used is :
   * $$S^\prime_r(D,S,R,G) = S\cdot(e^{w_8}\cdot (11-D)\cdot S^{-w_9}\cdot(e^{w_{10}\cdot(1-R)}-1)\cdot w_{15}(\text{if} G=2) \cdot w_{16}(\text{if} G=4)+1)$$
   * @param {number} d Difficulty D \in [1,10]
   * @param {number} s Stability (interval when R=90%)
   * @param {number} r Retrievability (probability of recall)
   * @param {Grade} g Grade (Rating[0.again,1.hard,2.good,3.easy])
   * @return {number} S^\prime_r new stability after recall
   */
  next_recall_stability(t, r, n, a) {
    const s = E.Hard === a ? this.param.w[15] : 1, i = E.Easy === a ? this.param.w[16] : 1;
    return +Re(
      r * (1 + Math.exp(this.param.w[8]) * (11 - t) * Math.pow(r, -this.param.w[9]) * (Math.exp((1 - n) * this.param.w[10]) - 1) * s * i),
      Oe,
      36500
    ).toFixed(8);
  }
  /**
   * The formula used is :
   * $$S^\prime_f(D,S,R) = w_{11}\cdot D^{-w_{12}}\cdot ((S+1)^{w_{13}}-1) \cdot e^{w_{14}\cdot(1-R)}$$
   * enable_short_term = true : $$S^\prime_f \in \min \lbrace \max \lbrace S^\prime_f,0.01\rbrace, \frac{S}{e^{w_{17} \cdot w_{18}}} \rbrace$$
   * enable_short_term = false : $$S^\prime_f \in \min \lbrace \max \lbrace S^\prime_f,0.01\rbrace, S \rbrace$$
   * @param {number} d Difficulty D \in [1,10]
   * @param {number} s Stability (interval when R=90%)
   * @param {number} r Retrievability (probability of recall)
   * @return {number} S^\prime_f new stability after forgetting
   */
  next_forget_stability(t, r, n) {
    return +Re(
      this.param.w[11] * Math.pow(t, -this.param.w[12]) * (Math.pow(r + 1, this.param.w[13]) - 1) * Math.exp((1 - n) * this.param.w[14]),
      Oe,
      36500
    ).toFixed(8);
  }
  /**
   * The formula used is :
   * $$S^\prime_s(S,G) = S \cdot e^{w_{17} \cdot (G-3+w_{18})}$$
   * @param {number} s Stability (interval when R=90%)
   * @param {Grade} g Grade (Rating[0.again,1.hard,2.good,3.easy])
   */
  next_short_term_stability(t, r) {
    const n = Math.pow(t, -this.param.w[19]) * Math.exp(this.param.w[17] * (r - 3 + this.param.w[18])), a = r >= 3 ? Math.max(n, 1) : n;
    return +Re(t * a, Oe, 36500).toFixed(8);
  }
  /**
   * Calculates the next state of memory based on the current state, time elapsed, and grade.
   *
   * @param memory_state - The current state of memory, which can be null.
   * @param t - The time elapsed since the last review.
   * @param {Rating} g Grade (Rating[0.Manual,1.Again,2.Hard,3.Good,4.Easy])
   * @returns The next state of memory with updated difficulty and stability.
   */
  next_state(t, r, n) {
    const { difficulty: a, stability: s } = t ?? {
      difficulty: 0,
      stability: 0
    };
    if (r < 0)
      throw new Error(`Invalid delta_t "${r}"`);
    if (n < 0 || n > 4)
      throw new Error(`Invalid grade "${n}"`);
    if (a === 0 && s === 0)
      return {
        difficulty: Re(this.init_difficulty(n), 1, 10),
        stability: this.init_stability(n)
      };
    if (n === 0)
      return {
        difficulty: a,
        stability: s
      };
    if (a < 1 || s < Oe)
      throw new Error(
        `Invalid memory state { difficulty: ${a}, stability: ${s} }`
      );
    const i = this.forgetting_curve(r, s), c = this.next_recall_stability(a, s, i, n), l = this.next_forget_stability(a, s, i), d = this.next_short_term_stability(s, n);
    let u = c;
    if (n === 1) {
      let [x, h] = [0, 0];
      this.param.enable_short_term && (x = this.param.w[17], h = this.param.w[18]);
      const y = s / Math.exp(x * h);
      u = Re(+y.toFixed(8), Oe, l);
    }
    return r === 0 && this.param.enable_short_term && (u = d), { difficulty: this.next_difficulty(a, n), stability: u };
  }
}
class Lo extends vn {
  constructor(r, n, a, s) {
    super(r, n, a, s);
    ce(this, "learningStepsStrategy");
    let i = Ka;
    if (this.strategies) {
      const c = this.strategies.get(dr.LEARNING_STEPS);
      c && (i = c);
    }
    this.learningStepsStrategy = i;
  }
  getLearningInfo(r, n) {
    var l, d;
    const a = this.algorithm.parameters;
    r.learning_steps = r.learning_steps || 0;
    const s = this.learningStepsStrategy(
      a,
      r.state,
      // In the original learning steps setup (Again = 5m, Hard = 10m, Good = FSRS),
      // not adding 1 can cause slight variations in the memory state’s ds.
      this.current.state === I.Learning && n !== E.Again && n !== E.Hard ? r.learning_steps + 1 : r.learning_steps
    ), i = Math.max(
      0,
      ((l = s[n]) == null ? void 0 : l.scheduled_minutes) ?? 0
    ), c = Math.max(0, ((d = s[n]) == null ? void 0 : d.next_step) ?? 0);
    return {
      scheduled_minutes: i,
      next_steps: c
    };
  }
  /**
   * @description This function applies the learning steps based on the current card's state and grade.
   */
  applyLearningSteps(r, n, a) {
    const { scheduled_minutes: s, next_steps: i } = this.getLearningInfo(
      this.current,
      n
    );
    if (s > 0 && s < 1440)
      r.learning_steps = i, r.scheduled_days = 0, r.state = a, r.due = We(
        this.review_time,
        Math.round(s),
        !1
        /** true:days false: minute */
      );
    else if (r.state = I.Review, s >= 1440)
      r.learning_steps = i, r.due = We(
        this.review_time,
        Math.round(s),
        !1
        /** true:days false: minute */
      ), r.scheduled_days = Math.floor(s / 1440);
    else {
      r.learning_steps = 0;
      const c = this.algorithm.next_interval(
        r.stability,
        this.elapsed_days
      );
      r.scheduled_days = c, r.due = We(this.review_time, c, !0);
    }
  }
  newState(r) {
    const n = this.next.get(r);
    if (n)
      return n;
    const a = K.card(this.current);
    a.difficulty = Re(this.algorithm.init_difficulty(r), 1, 10), a.stability = this.algorithm.init_stability(r), this.applyLearningSteps(a, r, I.Learning);
    const s = {
      card: a,
      log: this.buildLog(r)
    };
    return this.next.set(r, s), s;
  }
  learningState(r) {
    const n = this.next.get(r);
    if (n)
      return n;
    const { state: a, difficulty: s, stability: i } = this.last, c = K.card(this.current);
    c.difficulty = this.algorithm.next_difficulty(s, r), c.stability = this.algorithm.next_short_term_stability(i, r), this.applyLearningSteps(
      c,
      r,
      a
      /** Learning or Relearning */
    );
    const l = {
      card: c,
      log: this.buildLog(r)
    };
    return this.next.set(r, l), l;
  }
  reviewState(r) {
    const n = this.next.get(r);
    if (n)
      return n;
    const a = this.elapsed_days, { difficulty: s, stability: i } = this.last, c = this.algorithm.forgetting_curve(a, i), l = K.card(this.current), d = K.card(this.current), u = K.card(this.current), f = K.card(this.current);
    this.next_ds(
      l,
      d,
      u,
      f,
      s,
      i,
      c
    ), this.next_interval(d, u, f, a), this.next_state(d, u, f), this.applyLearningSteps(l, E.Again, I.Relearning), l.lapses += 1;
    const x = {
      card: l,
      log: this.buildLog(E.Again)
    }, h = {
      card: d,
      log: super.buildLog(E.Hard)
    }, y = {
      card: u,
      log: super.buildLog(E.Good)
    }, g = {
      card: f,
      log: super.buildLog(E.Easy)
    };
    return this.next.set(E.Again, x), this.next.set(E.Hard, h), this.next.set(E.Good, y), this.next.set(E.Easy, g), this.next.get(r);
  }
  /**
   * Review next_ds
   */
  next_ds(r, n, a, s, i, c, l) {
    r.difficulty = this.algorithm.next_difficulty(
      i,
      E.Again
    );
    const d = c / Math.exp(
      this.algorithm.parameters.w[17] * this.algorithm.parameters.w[18]
    ), u = this.algorithm.next_forget_stability(
      i,
      c,
      l
    );
    r.stability = Re(+d.toFixed(8), Oe, u), n.difficulty = this.algorithm.next_difficulty(
      i,
      E.Hard
    ), n.stability = this.algorithm.next_recall_stability(
      i,
      c,
      l,
      E.Hard
    ), a.difficulty = this.algorithm.next_difficulty(
      i,
      E.Good
    ), a.stability = this.algorithm.next_recall_stability(
      i,
      c,
      l,
      E.Good
    ), s.difficulty = this.algorithm.next_difficulty(
      i,
      E.Easy
    ), s.stability = this.algorithm.next_recall_stability(
      i,
      c,
      l,
      E.Easy
    );
  }
  /**
   * Review next_interval
   */
  next_interval(r, n, a, s) {
    let i, c;
    i = this.algorithm.next_interval(r.stability, s), c = this.algorithm.next_interval(n.stability, s), i = Math.min(i, c), c = Math.max(c, i + 1);
    const l = Math.max(
      this.algorithm.next_interval(a.stability, s),
      c + 1
    );
    r.scheduled_days = i, r.due = We(this.review_time, i, !0), n.scheduled_days = c, n.due = We(this.review_time, c, !0), a.scheduled_days = l, a.due = We(this.review_time, l, !0);
  }
  /**
   * Review next_state
   */
  next_state(r, n, a) {
    r.state = I.Review, r.learning_steps = 0, n.state = I.Review, n.learning_steps = 0, a.state = I.Review, a.learning_steps = 0;
  }
}
class Wo extends vn {
  newState(t) {
    const r = this.next.get(t);
    if (r)
      return r;
    this.current.scheduled_days = 0, this.current.elapsed_days = 0;
    const n = K.card(this.current), a = K.card(this.current), s = K.card(this.current), i = K.card(this.current);
    return this.init_ds(n, a, s, i), this.next_interval(
      n,
      a,
      s,
      i,
      0
    ), this.next_state(n, a, s, i), this.update_next(n, a, s, i), this.next.get(t);
  }
  init_ds(t, r, n, a) {
    t.difficulty = Re(
      this.algorithm.init_difficulty(E.Again),
      1,
      10
    ), t.stability = this.algorithm.init_stability(E.Again), r.difficulty = Re(
      this.algorithm.init_difficulty(E.Hard),
      1,
      10
    ), r.stability = this.algorithm.init_stability(E.Hard), n.difficulty = Re(
      this.algorithm.init_difficulty(E.Good),
      1,
      10
    ), n.stability = this.algorithm.init_stability(E.Good), a.difficulty = Re(
      this.algorithm.init_difficulty(E.Easy),
      1,
      10
    ), a.stability = this.algorithm.init_stability(E.Easy);
  }
  /**
   * @see https://github.com/open-spaced-repetition/ts-fsrs/issues/98#issuecomment-2241923194
   */
  learningState(t) {
    return this.reviewState(t);
  }
  reviewState(t) {
    const r = this.next.get(t);
    if (r)
      return r;
    const n = this.elapsed_days, { difficulty: a, stability: s } = this.last, i = this.algorithm.forgetting_curve(n, s), c = K.card(this.current), l = K.card(this.current), d = K.card(this.current), u = K.card(this.current);
    return this.next_ds(
      c,
      l,
      d,
      u,
      a,
      s,
      i
    ), this.next_interval(c, l, d, u, n), this.next_state(c, l, d, u), c.lapses += 1, this.update_next(c, l, d, u), this.next.get(t);
  }
  /**
   * Review next_ds
   */
  next_ds(t, r, n, a, s, i, c) {
    t.difficulty = this.algorithm.next_difficulty(
      s,
      E.Again
    );
    const l = this.algorithm.next_forget_stability(
      s,
      i,
      c
    );
    t.stability = Re(i, Oe, l), r.difficulty = this.algorithm.next_difficulty(
      s,
      E.Hard
    ), r.stability = this.algorithm.next_recall_stability(
      s,
      i,
      c,
      E.Hard
    ), n.difficulty = this.algorithm.next_difficulty(
      s,
      E.Good
    ), n.stability = this.algorithm.next_recall_stability(
      s,
      i,
      c,
      E.Good
    ), a.difficulty = this.algorithm.next_difficulty(
      s,
      E.Easy
    ), a.stability = this.algorithm.next_recall_stability(
      s,
      i,
      c,
      E.Easy
    );
  }
  /**
   * Review/New next_interval
   */
  next_interval(t, r, n, a, s) {
    let i, c, l, d;
    i = this.algorithm.next_interval(
      t.stability,
      s
    ), c = this.algorithm.next_interval(r.stability, s), l = this.algorithm.next_interval(n.stability, s), d = this.algorithm.next_interval(a.stability, s), i = Math.min(i, c), c = Math.max(c, i + 1), l = Math.max(l, c + 1), d = Math.max(d, l + 1), t.scheduled_days = i, t.due = We(this.review_time, i, !0), r.scheduled_days = c, r.due = We(this.review_time, c, !0), n.scheduled_days = l, n.due = We(this.review_time, l, !0), a.scheduled_days = d, a.due = We(this.review_time, d, !0);
  }
  /**
   * Review/New next_state
   */
  next_state(t, r, n, a) {
    t.state = I.Review, t.learning_steps = 0, r.state = I.Review, r.learning_steps = 0, n.state = I.Review, n.learning_steps = 0, a.state = I.Review, a.learning_steps = 0;
  }
  update_next(t, r, n, a) {
    const s = {
      card: t,
      log: this.buildLog(E.Again)
    }, i = {
      card: r,
      log: super.buildLog(E.Hard)
    }, c = {
      card: n,
      log: super.buildLog(E.Good)
    }, l = {
      card: a,
      log: super.buildLog(E.Easy)
    };
    this.next.set(E.Again, s), this.next.set(E.Hard, i), this.next.set(E.Good, c), this.next.set(E.Easy, l);
  }
}
class ls {
  /**
   * Creates an instance of the `Reschedule` class.
   * @param fsrs - An instance of the FSRS class used for scheduling.
   */
  constructor(t) {
    ce(this, "fsrs");
    this.fsrs = t;
  }
  /**
   * Replays a review for a card and determines the next review date based on the given rating.
   * @param card - The card being reviewed.
   * @param reviewed - The date the card was reviewed.
   * @param rating - The grade given to the card during the review.
   * @returns A `RecordLogItem` containing the updated card and review log.
   */
  replay(t, r, n) {
    return this.fsrs.next(t, r, n);
  }
  /**
   * Processes a manual review for a card, allowing for custom state, stability, difficulty, and due date.
   * @param card - The card being reviewed.
   * @param state - The state of the card after the review.
   * @param reviewed - The date the card was reviewed.
   * @param elapsed_days - The number of days since the last review.
   * @param stability - (Optional) The stability of the card.
   * @param difficulty - (Optional) The difficulty of the card.
   * @param due - (Optional) The due date for the next review.
   * @returns A `RecordLogItem` containing the updated card and review log.
   * @throws Will throw an error if the state or due date is not provided when required.
   */
  handleManualRating(t, r, n, a, s, i, c) {
    if (typeof r > "u")
      throw new Error("reschedule: state is required for manual rating");
    let l, d;
    if (r === I.New)
      l = {
        rating: E.Manual,
        state: r,
        due: c ?? n,
        stability: t.stability,
        difficulty: t.difficulty,
        elapsed_days: a,
        last_elapsed_days: t.elapsed_days,
        scheduled_days: t.scheduled_days,
        learning_steps: t.learning_steps,
        review: n
      }, d = Tt(n), d.last_review = n;
    else {
      if (typeof c > "u")
        throw new Error("reschedule: due is required for manual rating");
      const u = xt(c, n, "days");
      l = {
        rating: E.Manual,
        state: t.state,
        due: t.last_review || t.due,
        stability: t.stability,
        difficulty: t.difficulty,
        elapsed_days: a,
        last_elapsed_days: t.elapsed_days,
        scheduled_days: t.scheduled_days,
        learning_steps: t.learning_steps,
        review: n
      }, d = {
        ...t,
        state: r,
        due: c,
        last_review: n,
        stability: s || t.stability,
        difficulty: i || t.difficulty,
        elapsed_days: a,
        scheduled_days: u,
        reps: t.reps + 1
      };
    }
    return { card: d, log: l };
  }
  /**
   * Reschedules a card based on its review history.
   *
   * @param current_card - The card to be rescheduled.
   * @param reviews - An array of review history objects.
   * @returns An array of record log items representing the rescheduling process.
   */
  reschedule(t, r) {
    const n = [];
    let a = Tt(t.due);
    for (const s of r) {
      let i;
      if (s.review = K.time(s.review), s.rating === E.Manual) {
        let c = 0;
        a.state !== I.New && a.last_review && (c = xt(s.review, a.last_review, "days")), i = this.handleManualRating(
          a,
          s.state,
          s.review,
          c,
          s.stability,
          s.difficulty,
          s.due ? K.time(s.due) : void 0
        );
      } else
        i = this.replay(a, s.review, s.rating);
      n.push(i), a = i.card;
    }
    return n;
  }
  calculateManualRecord(t, r, n, a) {
    if (!n)
      return null;
    const { card: s, log: i } = n, c = K.card(t);
    return c.due.getTime() === s.due.getTime() ? null : (c.scheduled_days = xt(
      s.due,
      c.due,
      "days"
    ), this.handleManualRating(
      c,
      s.state,
      K.time(r),
      i.elapsed_days,
      a ? s.stability : void 0,
      a ? s.difficulty : void 0,
      s.due
    ));
  }
}
class cs extends is {
  constructor(r) {
    super(r);
    ce(this, "strategyHandler", /* @__PURE__ */ new Map());
    ce(this, "Scheduler");
    const { enable_short_term: n } = this.parameters;
    this.Scheduler = n ? Lo : Wo;
  }
  params_handler_proxy() {
    const r = this;
    return {
      set: function(n, a, s) {
        return a === "request_retention" && Number.isFinite(s) ? r.intervalModifier = r.calculate_interval_modifier(
          Number(s)
        ) : a === "enable_short_term" ? r.Scheduler = s === !0 ? Lo : Wo : a === "w" && (s = Xr(
          s,
          n.relearning_steps.length,
          n.enable_short_term
        ), r.forgetting_curve = Yr.bind(this, s), r.intervalModifier = r.calculate_interval_modifier(
          Number(n.request_retention)
        )), Reflect.set(n, a, s), !0;
      }
    };
  }
  useStrategy(r, n) {
    return this.strategyHandler.set(r, n), this;
  }
  clearStrategy(r) {
    return r ? this.strategyHandler.delete(r) : this.strategyHandler.clear(), this;
  }
  getScheduler(r, n) {
    const s = this.strategyHandler.get(
      dr.SCHEDULER
    ) || this.Scheduler;
    return new s(r, n, this, this.strategyHandler);
  }
  /**
   * Display the collection of cards and logs for the four scenarios after scheduling the card at the current time.
   * @param card Card to be processed
   * @param now Current time or scheduled time
   * @param afterHandler Convert the result to another type. (Optional)
   * @example
   * ```typescript
   * const card: Card = createEmptyCard(new Date());
   * const f = fsrs();
   * const recordLog = f.repeat(card, new Date());
   * ```
   * @example
   * ```typescript
   * interface RevLogUnchecked
   *   extends Omit<ReviewLog, "due" | "review" | "state" | "rating"> {
   *   cid: string;
   *   due: Date | number;
   *   state: StateType;
   *   review: Date | number;
   *   rating: RatingType;
   * }
   *
   * interface RepeatRecordLog {
   *   card: CardUnChecked; //see method: createEmptyCard
   *   log: RevLogUnchecked;
   * }
   *
   * function repeatAfterHandler(recordLog: RecordLog) {
   *     const record: { [key in Grade]: RepeatRecordLog } = {} as {
   *       [key in Grade]: RepeatRecordLog;
   *     };
   *     for (const grade of Grades) {
   *       record[grade] = {
   *         card: {
   *           ...(recordLog[grade].card as Card & { cid: string }),
   *           due: recordLog[grade].card.due.getTime(),
   *           state: State[recordLog[grade].card.state] as StateType,
   *           last_review: recordLog[grade].card.last_review
   *             ? recordLog[grade].card.last_review!.getTime()
   *             : null,
   *         },
   *         log: {
   *           ...recordLog[grade].log,
   *           cid: (recordLog[grade].card as Card & { cid: string }).cid,
   *           due: recordLog[grade].log.due.getTime(),
   *           review: recordLog[grade].log.review.getTime(),
   *           state: State[recordLog[grade].log.state] as StateType,
   *           rating: Rating[recordLog[grade].log.rating] as RatingType,
   *         },
   *       };
   *     }
   *     return record;
   * }
   * const card: Card = createEmptyCard(new Date(), cardAfterHandler); //see method:  createEmptyCard
   * const f = fsrs();
   * const recordLog = f.repeat(card, new Date(), repeatAfterHandler);
   * ```
   */
  repeat(r, n, a) {
    const i = this.getScheduler(r, n).preview();
    return a && typeof a == "function" ? a(i) : i;
  }
  /**
   * Display the collection of cards and logs for the card scheduled at the current time, after applying a specific grade rating.
   * @param card Card to be processed
   * @param now Current time or scheduled time
   * @param grade Rating of the review (Again, Hard, Good, Easy)
   * @param afterHandler Convert the result to another type. (Optional)
   * @example
   * ```typescript
   * const card: Card = createEmptyCard(new Date());
   * const f = fsrs();
   * const recordLogItem = f.next(card, new Date(), Rating.Again);
   * ```
   * @example
   * ```typescript
   * interface RevLogUnchecked
   *   extends Omit<ReviewLog, "due" | "review" | "state" | "rating"> {
   *   cid: string;
   *   due: Date | number;
   *   state: StateType;
   *   review: Date | number;
   *   rating: RatingType;
   * }
   *
   * interface NextRecordLog {
   *   card: CardUnChecked; //see method: createEmptyCard
   *   log: RevLogUnchecked;
   * }
   *
  function nextAfterHandler(recordLogItem: RecordLogItem) {
    const recordItem = {
      card: {
        ...(recordLogItem.card as Card & { cid: string }),
        due: recordLogItem.card.due.getTime(),
        state: State[recordLogItem.card.state] as StateType,
        last_review: recordLogItem.card.last_review
          ? recordLogItem.card.last_review!.getTime()
          : null,
      },
      log: {
        ...recordLogItem.log,
        cid: (recordLogItem.card as Card & { cid: string }).cid,
        due: recordLogItem.log.due.getTime(),
        review: recordLogItem.log.review.getTime(),
        state: State[recordLogItem.log.state] as StateType,
        rating: Rating[recordLogItem.log.rating] as RatingType,
      },
    };
    return recordItem
  }
   * const card: Card = createEmptyCard(new Date(), cardAfterHandler); //see method:  createEmptyCard
   * const f = fsrs();
   * const recordLogItem = f.repeat(card, new Date(), Rating.Again, nextAfterHandler);
   * ```
   */
  next(r, n, a, s) {
    const i = this.getScheduler(r, n), c = K.rating(a);
    if (c === E.Manual)
      throw new Error("Cannot review a manual rating");
    const l = i.review(c);
    return s && typeof s == "function" ? s(l) : l;
  }
  /**
   * Get the retrievability of the card
   * @param card  Card to be processed
   * @param now  Current time or scheduled time
   * @param format  default:true , Convert the result to another type. (Optional)
   * @returns  The retrievability of the card,if format is true, the result is a string, otherwise it is a number
   */
  get_retrievability(r, n, a = !0) {
    const s = K.card(r);
    n = n ? K.time(n) : /* @__PURE__ */ new Date();
    const i = s.state !== I.New ? Math.max(xt(n, s.last_review, "days"), 0) : 0, c = s.state !== I.New ? this.forgetting_curve(i, +s.stability.toFixed(8)) : 0;
    return a ? `${(c * 100).toFixed(2)}%` : c;
  }
  /**
   *
   * @param card Card to be processed
   * @param log last review log
   * @param afterHandler Convert the result to another type. (Optional)
   * @example
   * ```typescript
   * const now = new Date();
   * const f = fsrs();
   * const emptyCardFormAfterHandler = createEmptyCard(now);
   * const repeatFormAfterHandler = f.repeat(emptyCardFormAfterHandler, now);
   * const { card, log } = repeatFormAfterHandler[Rating.Hard];
   * const rollbackFromAfterHandler = f.rollback(card, log);
   * ```
   *
   * @example
   * ```typescript
   * const now = new Date();
   * const f = fsrs();
   * const emptyCardFormAfterHandler = createEmptyCard(now, cardAfterHandler);  //see method: createEmptyCard
   * const repeatFormAfterHandler = f.repeat(emptyCardFormAfterHandler, now, repeatAfterHandler); //see method: fsrs.repeat()
   * const { card, log } = repeatFormAfterHandler[Rating.Hard];
   * const rollbackFromAfterHandler = f.rollback(card, log, cardAfterHandler);
   * ```
   */
  rollback(r, n, a) {
    const s = K.card(r), i = K.review_log(n);
    if (i.rating === E.Manual)
      throw new Error("Cannot rollback a manual rating");
    let c, l, d;
    switch (i.state) {
      case I.New:
        c = i.due, l = void 0, d = 0;
        break;
      case I.Learning:
      case I.Relearning:
      case I.Review:
        c = i.review, l = i.due, d = s.lapses - (i.rating === E.Again && i.state === I.Review ? 1 : 0);
        break;
    }
    const u = {
      ...s,
      due: c,
      stability: i.stability,
      difficulty: i.difficulty,
      elapsed_days: i.last_elapsed_days,
      scheduled_days: i.scheduled_days,
      reps: Math.max(0, s.reps - 1),
      lapses: Math.max(0, d),
      learning_steps: i.learning_steps,
      state: i.state,
      last_review: l
    };
    return a && typeof a == "function" ? a(u) : u;
  }
  /**
   *
   * @param card Card to be processed
   * @param now Current time or scheduled time
   * @param reset_count Should the review count information(reps,lapses) be reset. (Optional)
   * @param afterHandler Convert the result to another type. (Optional)
   * @example
   * ```typescript
   * const now = new Date();
   * const f = fsrs();
   * const emptyCard = createEmptyCard(now);
   * const scheduling_cards = f.repeat(emptyCard, now);
   * const { card, log } = scheduling_cards[Rating.Hard];
   * const forgetCard = f.forget(card, new Date(), true);
   * ```
   *
   * @example
   * ```typescript
   * interface RepeatRecordLog {
   *   card: CardUnChecked; //see method: createEmptyCard
   *   log: RevLogUnchecked; //see method: fsrs.repeat()
   * }
   *
   * function forgetAfterHandler(recordLogItem: RecordLogItem): RepeatRecordLog {
   *     return {
   *       card: {
   *         ...(recordLogItem.card as Card & { cid: string }),
   *         due: recordLogItem.card.due.getTime(),
   *         state: State[recordLogItem.card.state] as StateType,
   *         last_review: recordLogItem.card.last_review
   *           ? recordLogItem.card.last_review!.getTime()
   *           : null,
   *       },
   *       log: {
   *         ...recordLogItem.log,
   *         cid: (recordLogItem.card as Card & { cid: string }).cid,
   *         due: recordLogItem.log.due.getTime(),
   *         review: recordLogItem.log.review.getTime(),
   *         state: State[recordLogItem.log.state] as StateType,
   *         rating: Rating[recordLogItem.log.rating] as RatingType,
   *       },
   *     };
   * }
   * const now = new Date();
   * const f = fsrs();
   * const emptyCardFormAfterHandler = createEmptyCard(now, cardAfterHandler); //see method:  createEmptyCard
   * const repeatFormAfterHandler = f.repeat(emptyCardFormAfterHandler, now, repeatAfterHandler); //see method: fsrs.repeat()
   * const { card } = repeatFormAfterHandler[Rating.Hard];
   * const forgetFromAfterHandler = f.forget(card, date_scheduler(now, 1, true), false, forgetAfterHandler);
   * ```
   */
  forget(r, n, a = !1, s) {
    const i = K.card(r);
    n = K.time(n);
    const c = i.state === I.New ? 0 : xt(n, i.due, "days"), l = {
      rating: E.Manual,
      state: i.state,
      due: i.due,
      stability: i.stability,
      difficulty: i.difficulty,
      elapsed_days: 0,
      last_elapsed_days: i.elapsed_days,
      scheduled_days: c,
      learning_steps: i.learning_steps,
      review: n
    }, u = { card: {
      ...i,
      due: n,
      stability: 0,
      difficulty: 0,
      elapsed_days: 0,
      scheduled_days: 0,
      reps: a ? 0 : i.reps,
      lapses: a ? 0 : i.lapses,
      learning_steps: 0,
      state: I.New,
      last_review: i.last_review
    }, log: l };
    return s && typeof s == "function" ? s(u) : u;
  }
  /**
   * Reschedules the current card and returns the rescheduled collections and reschedule item.
   *
   * @template T - The type of the record log item.
   * @param {CardInput | Card} current_card - The current card to be rescheduled.
   * @param {Array<FSRSHistory>} reviews - The array of FSRSHistory objects representing the reviews.
   * @param {Partial<RescheduleOptions<T>>} options - The optional reschedule options.
   * @returns {IReschedule<T>} - The rescheduled collections and reschedule item.
   *
   * @example
   * ```typescript
   * const f = fsrs()
   * const grades: Grade[] = [Rating.Good, Rating.Good, Rating.Good, Rating.Good]
   * const reviews_at = [
   *   new Date(2024, 8, 13),
   *   new Date(2024, 8, 13),
   *   new Date(2024, 8, 17),
   *   new Date(2024, 8, 28),
   * ]
   *
   * const reviews: FSRSHistory[] = []
   * for (let i = 0; i < grades.length; i++) {
   *   reviews.push({
   *     rating: grades[i],
   *     review: reviews_at[i],
   *   })
   * }
   *
   * const results_short = scheduler.reschedule(
   *   createEmptyCard(),
   *   reviews,
   *   {
   *     skipManual: false,
   *   }
   * )
   * console.log(results_short)
   * ```
   */
  reschedule(r, n = [], a = {}) {
    const {
      recordLogHandler: s,
      reviewsOrderBy: i,
      skipManual: c = !0,
      now: l = /* @__PURE__ */ new Date(),
      update_memory_state: d = !1
    } = a;
    i && typeof i == "function" && n.sort(i), c && (n = n.filter((g) => g.rating !== E.Manual));
    const u = new ls(this), f = u.reschedule(
      a.first_card || Tt(),
      n
    ), x = f.length, h = K.card(r), y = u.calculateManualRecord(
      h,
      l,
      x ? f[x - 1] : void 0,
      d
    );
    return s && typeof s == "function" ? {
      collections: f.map(s),
      reschedule_item: y ? s(y) : null
    } : {
      collections: f,
      reschedule_item: y
    };
  }
}
const Ft = "0.212, 1.2931, 2.3065, 8.2956, 6.4133, 0.8334, 3.0194, 0.001, 1.8722, 0.1666, 0.796, 1.4835, 0.0614, 0.2629, 1.6483, 0.6014, 1.8729, 0.5425, 0.0912, 0.0658, 0.1542", wn = 30, Sn = 200, yt = 0.9, mt = 36500, ds = {
  "review.disableNotifications": {
    label: "关闭通知提醒",
    type: "boolean",
    defaultValue: !1,
    description: "开启后不显示任何 SRS 相关的通知提醒（评分、创建卡片等）"
  },
  "review.newCardsPerDay": {
    label: "每日新卡上限",
    type: "number",
    defaultValue: wn,
    description: "每天最多学习的新卡数量"
  },
  "review.reviewCardsPerDay": {
    label: "每日复习卡上限",
    type: "number",
    defaultValue: Sn,
    description: "每天最多复习的旧卡数量"
  },
  "review.fsrsWeights": {
    label: "FSRS v6 算法权重",
    type: "string",
    defaultValue: Ft,
    description: "FSRS v6 算法权重参数（21个逗号分隔的数字）。默认值为 ts-fsrs 官方默认值，如需调整请使用 FSRS 优化器计算"
  },
  "review.fsrsRequestRetention": {
    label: "FSRS 目标记忆保留率",
    type: "number",
    defaultValue: yt,
    description: "期望的记忆保留率（0.7-0.99），值越高复习频率越高。推荐 0.9"
  },
  "review.fsrsMaximumInterval": {
    label: "FSRS 最大间隔天数",
    type: "number",
    defaultValue: mt,
    description: "卡片复习的最大间隔天数（默认 36500 天，约 100 年）"
  }
};
function us(e) {
  var r;
  const t = (r = orca.state.plugins[e]) == null ? void 0 : r.settings;
  return {
    disableNotifications: (t == null ? void 0 : t["review.disableNotifications"]) ?? !1,
    newCardsPerDay: (t == null ? void 0 : t["review.newCardsPerDay"]) ?? wn,
    reviewCardsPerDay: (t == null ? void 0 : t["review.reviewCardsPerDay"]) ?? Sn,
    fsrsWeights: (t == null ? void 0 : t["review.fsrsWeights"]) ?? Ft,
    fsrsRequestRetention: (t == null ? void 0 : t["review.fsrsRequestRetention"]) ?? yt,
    fsrsMaximumInterval: (t == null ? void 0 : t["review.fsrsMaximumInterval"]) ?? mt
  };
}
function Cn(e) {
  try {
    const t = e.split(",").map((r) => parseFloat(r.trim()));
    if (t.length < 19 || t.length > 21 || t.some((r) => isNaN(r))) {
      console.warn("[FSRS] 权重参数格式错误，需要 19-21 个有效数字");
      return;
    }
    return t;
  } catch {
    return;
  }
}
function rt(e, t, r, n) {
  us(e).disableNotifications || orca.notify(t, r, n);
}
let Nt = {
  weightsStr: Ft,
  requestRetention: yt,
  maximumInterval: mt
};
const jn = (e, t = yt, r = mt) => {
  const n = {
    request_retention: t,
    maximum_interval: r
  };
  return e && e.length >= 19 && (n.w = e), new cs(Nr(n));
}, fs = Cn(Ft);
let kn = jn(fs, yt, mt);
const ps = (e, t, r) => {
  if (e === Nt.weightsStr && t === Nt.requestRetention && r === Nt.maximumInterval)
    return;
  const n = Cn(e);
  kn = jn(n, t, r), Nt = { weightsStr: e, requestRetention: t, maximumInterval: r }, console.log("[FSRS] 已更新算法参数", { requestRetention: t, maximumInterval: r });
}, xs = (e) => {
  var t;
  if (e) {
    const r = (t = orca.state.plugins[e]) == null ? void 0 : t.settings, n = (r == null ? void 0 : r["review.fsrsWeights"]) ?? Ft, a = (r == null ? void 0 : r["review.fsrsRequestRetention"]) ?? yt, s = (r == null ? void 0 : r["review.fsrsMaximumInterval"]) ?? mt;
    ps(n, a, s);
  }
  return kn;
}, hs = {
  again: E.Again,
  hard: E.Hard,
  good: E.Good,
  easy: E.Easy
}, fr = () => /* @__PURE__ */ new Date(), gs = (e, t) => {
  const r = Tt(t);
  return e ? {
    ...r,
    stability: e.stability ?? r.stability,
    difficulty: e.difficulty ?? r.difficulty,
    due: e.due ?? r.due,
    last_review: e.lastReviewed ?? r.last_review,
    scheduled_days: e.interval ?? r.scheduled_days,
    reps: e.reps ?? r.reps,
    lapses: e.lapses ?? r.lapses,
    // 使用保存的 FSRS 状态，如果没有则根据 reps 推断
    // 注意：必须保留 Learning/Relearning 状态，否则间隔计算会出错
    state: e.state ?? (e.reps > 0 ? I.Review : I.New)
  } : r;
}, ys = (e, t, r) => ({
  stability: e.stability,
  // 记忆稳定度，越高遗忘越慢
  difficulty: e.difficulty,
  // 记忆难度，Again/Hard 提升，Easy 降低
  interval: e.scheduled_days,
  // 下次间隔天数（FSRS 计算的 scheduled_days）
  due: e.due,
  // 下次到期时间
  lastReviewed: (t == null ? void 0 : t.review) ?? e.last_review ?? null,
  // 最近复习时间
  reps: e.reps,
  // 累计复习次数
  lapses: e.lapses,
  // 遗忘次数（Again 增加）
  state: e.state,
  // FSRS 内部状态（New/Learning/Review/Relearning）
  resets: r ?? 0
  // 重置次数
}), Ze = (e = fr()) => {
  const t = Tt(e);
  return ys(t, null);
}, Pt = (e, t, r = fr(), n) => {
  const a = xs(n), s = gs(e, r), i = a.next(s, r, hs[t]);
  return { state: {
    stability: i.card.stability,
    // 记忆稳定度，评分越高增长越快
    difficulty: i.card.difficulty,
    // 记忆难度，Again/Hard 会调高，Easy 会降低
    interval: i.card.scheduled_days,
    // 下次间隔天数，已包含 FSRS 的遗忘曲线与 fuzz
    due: i.card.due,
    // 具体下次到期时间（now + interval）
    lastReviewed: i.log.review,
    // 本次复习时间
    reps: i.card.reps,
    // 总复习次数（每次评分 +1）
    lapses: i.card.lapses,
    // 遗忘次数（Again 会累计）
    state: i.card.state
    // 当前 FSRS 状态（New/Learning/Review/Relearning）
  }, log: i.log };
}, Zr = (e, t = fr(), r) => {
  const n = ["again", "hard", "good", "easy"], a = {};
  for (const s of n) {
    const { state: i } = Pt(e, s, t, r), c = i.due.getTime() - t.getTime();
    a[s] = Math.max(0, c);
  }
  return a;
}, Yt = (e) => {
  const t = e / 6e4, r = e / (1e3 * 60 * 60), n = e / (1e3 * 60 * 60 * 24);
  return t < 1 ? "<1m" : t < 60 ? `${Math.round(t)}m` : r < 24 ? `${Math.round(r)}h` : n < 30 ? `${Math.round(n)}d` : n < 365 ? `${Math.round(n / 30)}mo` : `${(n / 365).toFixed(1)}y`;
}, be = (e) => {
  const t = e / 6e4, r = e / (1e3 * 60 * 60), n = e / (1e3 * 60 * 60 * 24);
  return t < 1 ? "1分钟内" : t < 60 ? `${Math.round(t)}分钟后` : r < 24 ? `${Math.round(r)}小时后` : n < 30 ? `${Math.round(n)}天后` : n < 365 ? `${Math.round(n / 30)}个月后` : `${(n / 365).toFixed(1)}年后`;
}, Se = (e) => {
  const t = e.getMonth() + 1, r = e.getDate();
  return `${t}-${r}`;
}, eo = (e, t = fr(), r) => {
  const n = ["again", "hard", "good", "easy"], a = {};
  for (const s of n) {
    const { state: i } = Pt(e, s, t, r);
    a[s] = i.due;
  }
  return a;
}, Je = /* @__PURE__ */ new Map(), vt = async (e) => {
  if (Je.has(e))
    return Je.get(e) ?? void 0;
  const t = await orca.invokeBackend("get-block", e);
  return Je.set(e, t ?? null), t;
}, Rn = (e) => {
  Je.delete(e);
}, to = (e, t) => {
  var r;
  return !!((r = e == null ? void 0 : e.properties) != null && r.some((n) => n.name.startsWith(t)));
}, Ne = (e, t) => t !== void 0 ? `srs.c${t}.${e}` : `srs.${e}`, Ye = (e, t) => `srs.${t}.${e}`, $n = (e, t) => {
  var r, n;
  return (n = (r = e == null ? void 0 : e.properties) == null ? void 0 : r.find((a) => a.name === t)) == null ? void 0 : n.value;
}, ze = (e, t) => {
  if (typeof e == "number") return e;
  if (typeof e == "string") {
    const r = Number(e);
    if (Number.isFinite(r)) return r;
  }
  return t;
}, rr = (e, t) => {
  if (!e) return t;
  const r = new Date(e);
  return Number.isNaN(r.getTime()) ? t : r;
}, Dn = async (e, t) => {
  const n = Ze(/* @__PURE__ */ new Date()), a = await vt(e);
  if (!a)
    return n;
  const s = (i) => $n(a, Ne(i, t));
  return {
    stability: ze(s("stability"), n.stability),
    difficulty: ze(s("difficulty"), n.difficulty),
    interval: ze(s("interval"), n.interval),
    due: rr(s("due"), n.due) ?? n.due,
    lastReviewed: rr(s("lastReviewed"), n.lastReviewed),
    reps: ze(s("reps"), n.reps),
    lapses: ze(s("lapses"), n.lapses),
    // 读取保存的 FSRS 状态（0=New, 1=Learning, 2=Review, 3=Relearning）
    state: ze(s("state"), n.state ?? 0),
    resets: ze(s("resets"), 0)
  };
}, _n = async (e, t, r) => {
  const n = [
    { name: Ne("stability", r), value: t.stability, type: 3 },
    { name: Ne("difficulty", r), value: t.difficulty, type: 3 },
    { name: Ne("lastReviewed", r), value: t.lastReviewed ?? null, type: 5 },
    { name: Ne("interval", r), value: t.interval, type: 3 },
    { name: Ne("due", r), value: t.due, type: 5 },
    { name: Ne("reps", r), value: t.reps, type: 3 },
    { name: Ne("lapses", r), value: t.lapses, type: 3 },
    { name: Ne("resets", r), value: t.resets ?? 0, type: 3 },
    // 保存 FSRS 状态（0=New, 1=Learning, 2=Review, 3=Relearning）
    { name: Ne("state", r), value: t.state ?? 0, type: 3 }
  ];
  r === void 0 && n.unshift({ name: "srs.isCard", value: !0, type: 4 }), await orca.commands.invokeEditorCommand(
    "core.editor.setProperties",
    null,
    [e],
    n
  ), Je.delete(e);
}, pr = (e) => Dn(e), xr = (e, t) => _n(e, t), ro = async (e, t = /* @__PURE__ */ new Date()) => {
  const r = Ze(t);
  return await xr(e, r), r;
}, oo = async (e, t, r) => {
  const n = await pr(e), a = Pt(n, t, /* @__PURE__ */ new Date(), r);
  return await xr(e, a.state), a;
}, hr = (e, t) => Dn(e, t), gr = (e, t, r) => _n(e, r, t), no = async (e, t, r = 0) => {
  const n = /* @__PURE__ */ new Date(), a = new Date(n);
  a.setDate(a.getDate() + r), a.setHours(0, 0, 0, 0);
  const s = Ze(a);
  return await gr(e, t, s), s;
}, Tn = async (e, t, r, n) => {
  const a = await hr(e, t), s = Pt(a, r, /* @__PURE__ */ new Date(), n);
  return await gr(e, t, s.state), s;
}, yr = async (e, t) => {
  const n = Ze(/* @__PURE__ */ new Date()), a = await vt(e);
  if (!a)
    return n;
  const s = (i) => $n(a, Ye(i, t));
  return {
    stability: ze(s("stability"), n.stability),
    difficulty: ze(s("difficulty"), n.difficulty),
    interval: ze(s("interval"), n.interval),
    due: rr(s("due"), n.due) ?? n.due,
    lastReviewed: rr(s("lastReviewed"), n.lastReviewed),
    reps: ze(s("reps"), n.reps),
    lapses: ze(s("lapses"), n.lapses),
    // 读取保存的 FSRS 状态（0=New, 1=Learning, 2=Review, 3=Relearning）
    state: ze(s("state"), n.state ?? 0),
    resets: ze(s("resets"), 0)
  };
}, mr = async (e, t, r) => {
  const n = [
    { name: Ye("stability", t), value: r.stability, type: 3 },
    { name: Ye("difficulty", t), value: r.difficulty, type: 3 },
    { name: Ye("interval", t), value: r.interval, type: 3 },
    { name: Ye("due", t), value: r.due, type: 5 },
    { name: Ye("lastReviewed", t), value: r.lastReviewed ?? null, type: 5 },
    { name: Ye("reps", t), value: r.reps, type: 3 },
    { name: Ye("lapses", t), value: r.lapses, type: 3 },
    { name: Ye("resets", t), value: r.resets ?? 0, type: 3 },
    // 保存 FSRS 状态（0=New, 1=Learning, 2=Review, 3=Relearning）
    { name: Ye("state", t), value: r.state ?? 0, type: 3 }
  ];
  await orca.commands.invokeEditorCommand(
    "core.editor.setProperties",
    null,
    [e],
    n
  ), Je.delete(e);
}, ht = async (e, t, r = 0) => {
  const n = /* @__PURE__ */ new Date(), a = new Date(n);
  a.setDate(a.getDate() + r), a.setHours(0, 0, 0, 0);
  const s = Ze(a);
  return await mr(e, t, s), s;
}, zn = async (e, t, r, n) => {
  const a = await yr(e, t), s = Pt(a, r, /* @__PURE__ */ new Date(), n);
  return await mr(e, t, s.state), s;
}, Ue = async (e, t = /* @__PURE__ */ new Date()) => {
  const r = await vt(e);
  return to(r, "srs.") ? await pr(e) : await ro(e, t);
}, ao = async (e, t, r = 0) => {
  const n = await vt(e), a = `srs.c${t}.`;
  return to(n, a) ? await hr(e, t) : await no(e, t, r);
}, so = async (e, t, r = 0) => {
  const n = await vt(e), a = `srs.${t}.`;
  return to(n, a) ? await yr(e, t) : await ht(e, t, r);
}, ms = async (e) => {
  const t = await pr(e), a = {
    ...Ze(/* @__PURE__ */ new Date()),
    resets: (t.resets ?? 0) + 1
  };
  return await xr(e, a), a;
}, vs = async (e, t) => {
  const r = await hr(e, t), s = {
    ...Ze(/* @__PURE__ */ new Date()),
    resets: (r.resets ?? 0) + 1
  };
  return await gr(e, t, s), s;
}, bs = async (e, t) => {
  const r = await yr(e, t), s = {
    ...Ze(/* @__PURE__ */ new Date()),
    resets: (r.resets ?? 0) + 1
  };
  return await mr(e, t, s), s;
}, io = async (e, t = "srs.") => {
  const r = await vt(e);
  return r != null && r.properties ? r.properties.filter((n) => n.name.startsWith(t)).map((n) => n.name) : [];
}, ws = async (e) => {
  const t = await io(e, "srs.");
  t.length !== 0 && (await orca.commands.invokeEditorCommand(
    "core.editor.deleteProperties",
    null,
    [e],
    t
  ), Je.delete(e));
}, Ss = async (e, t) => {
  const r = `srs.c${t}.`, n = await io(e, r);
  n.length !== 0 && (await orca.commands.invokeEditorCommand(
    "core.editor.deleteProperties",
    null,
    [e],
    n
  ), Je.delete(e));
}, Cs = async (e, t) => {
  const r = `srs.${t}.`, n = await io(e, r);
  n.length !== 0 && (await orca.commands.invokeEditorCommand(
    "core.editor.deleteProperties",
    null,
    [e],
    n
  ), Je.delete(e));
}, Oo = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  deleteCardSrsData: ws,
  deleteClozeCardSrsData: Ss,
  deleteDirectionCardSrsData: Cs,
  ensureCardSrsState: Ue,
  ensureClozeSrsState: ao,
  ensureDirectionSrsState: so,
  invalidateBlockCache: Rn,
  loadCardSrsState: pr,
  loadClozeSrsState: hr,
  loadDirectionSrsState: yr,
  resetCardSrsState: ms,
  resetClozeSrsState: vs,
  resetDirectionSrsState: bs,
  saveCardSrsState: xr,
  saveClozeSrsState: gr,
  saveDirectionSrsState: mr,
  updateClozeSrsState: Tn,
  updateDirectionSrsState: zn,
  updateSrsState: oo,
  writeInitialClozeSrsState: no,
  writeInitialDirectionSrsState: ht,
  writeInitialSrsState: ro
}, Symbol.toStringTag, { value: "Module" }));
function En(e) {
  if (!e.refs || e.refs.length === 0)
    return "normal";
  const t = e.refs.find(
    (a) => a.type === 2 && // RefType.Property（标签引用）
    Me(a.alias)
    // 标签名称为 "card"（大小写不敏感）
  );
  if (!t || !t.data || t.data.length === 0)
    return "normal";
  const r = t.data.find((a) => a.name === "status");
  if (!r)
    return "normal";
  const n = r.value;
  return Array.isArray(n) ? n.length === 0 || !n[0] || typeof n[0] != "string" ? "normal" : n[0].trim().toLowerCase() === "suspend" ? "suspend" : "normal" : typeof n == "string" && n.trim().toLowerCase() === "suspend" ? "suspend" : "normal";
}
async function js(e) {
  var t;
  console.log(`[SRS] 暂停卡片 #${e}`);
  try {
    const r = orca.state.blocks[e];
    if (!r)
      throw new Error(`找不到块 #${e}`);
    const n = (t = r.refs) == null ? void 0 : t.find(
      (a) => a.type === 2 && Me(a.alias)
    );
    if (!n)
      throw new Error(`块 #${e} 没有 #card 标签`);
    await orca.commands.invokeEditorCommand(
      "core.editor.setRefData",
      null,
      n,
      [{ name: "status", value: "suspend" }]
    ), console.log(`[SRS] 卡片 #${e} 已暂停`);
  } catch (r) {
    throw console.error("[SRS] 暂停卡片失败:", r), r;
  }
}
function ks() {
  const e = /* @__PURE__ */ new Date();
  return e.setDate(e.getDate() + 1), e.setHours(0, 0, 0, 0), e;
}
function Rs(e, t) {
  return e !== void 0 ? `srs.c${e}.due` : t !== void 0 ? `srs.${t}.due` : "srs.due";
}
async function $s(e, t, r) {
  const n = t ? `Cloze c${t}` : r ? `Direction ${r}` : "Basic";
  console.log(`[SRS] 推迟 ${n} 卡片 #${e}`);
  try {
    const a = ks(), s = Rs(t, r);
    await orca.commands.invokeEditorCommand(
      "core.editor.setProperties",
      null,
      [e],
      [{ name: s, type: 5, value: a }]
    ), Rn(e), console.log(`[SRS] 卡片 #${e} 已推迟，明天 ${a.toLocaleDateString()} 再复习`);
  } catch (a) {
    throw console.error("[SRS] 推迟卡片失败:", a), a;
  }
}
const _r = {
  Text: 1,
  BlockRefs: 2
}, Ds = [
  {
    name: "type",
    type: _r.Text,
    // 文本类型
    value: ""
    // 留空
  },
  {
    name: "牌组",
    type: _r.BlockRefs,
    // 块引用类型
    // 尝试使用 undefined 代替空数组，因为空数组被 Orca 静默忽略
    value: void 0
  },
  {
    name: "status",
    type: _r.Text,
    // 文本类型
    value: ""
    // 留空
  }
];
let Tr = !1, wt = !1;
async function vr(e) {
  var t;
  if (!Tr && !wt) {
    wt = !0;
    try {
      const r = await orca.invokeBackend("get-block-by-alias", "card");
      if (!r) {
        wt = !1;
        return;
      }
      const n = new Set(((t = r.properties) == null ? void 0 : t.map((s) => s.name)) || []), a = Ds.filter(
        (s) => !n.has(s.name)
      );
      if (a.length === 0) {
        Tr = !0, wt = !1;
        return;
      }
      for (const s of a)
        try {
          await orca.commands.invokeEditorCommand(
            "core.editor.setProperties",
            null,
            [r.id],
            [s]
          );
        } catch (i) {
          console.error(`[${e}] [tagPropertyInit] 属性 "${s.name}" 添加失败:`, i);
        }
      Tr = !0;
    } catch (r) {
      console.error(`[${e}] [tagPropertyInit] 初始化失败:`, r);
    } finally {
      wt = !1;
    }
  }
}
function _s(e, t) {
  if (!e || e.length === 0)
    return 0;
  let r = 0;
  for (const n of e)
    n.t === `${t}.cloze` && typeof n.clozeNumber == "number" && n.clozeNumber > r && (r = n.clozeNumber);
  return r;
}
function lo(e, t) {
  if (!e || e.length === 0)
    return [];
  const r = /* @__PURE__ */ new Set();
  for (const n of e)
    (n.t === `${t}.cloze` || typeof n.t == "string" && n.t.endsWith(".cloze")) && typeof n.clozeNumber == "number" && r.add(n.clozeNumber);
  return Array.from(r).sort((n, a) => n - a);
}
function Ts(e, t, r, n, a) {
  const s = Math.min(t.anchor.index, t.focus.index);
  let i, c;
  if (t.anchor.index === t.focus.index)
    i = Math.min(t.anchor.offset, t.focus.offset), c = Math.max(t.anchor.offset, t.focus.offset);
  else
    return console.warn(`[${a}] 不支持跨 fragment 的选区`), e;
  const l = [];
  for (let d = 0; d < e.length; d++) {
    const u = e[d];
    if (d === s) {
      const f = u.v || "";
      if (i > 0) {
        const x = f.substring(0, i);
        l.push({
          ...u,
          v: x
        });
      }
      if (l.push({
        t: `${a}.cloze`,
        v: r,
        clozeNumber: n
      }), c < f.length) {
        const x = f.substring(c);
        l.push({
          ...u,
          v: x
        });
      }
    } else
      l.push(u);
  }
  return l;
}
async function zs(e, t) {
  var x, h, y;
  if (!e || !e.anchor || !e.anchor.blockId)
    return orca.notify("error", "无法获取光标位置"), console.error(`[${t}] 错误：无法获取光标位置`), null;
  const r = e.anchor.blockId, n = orca.state.blocks[r];
  if (!n)
    return orca.notify("error", "未找到当前块"), console.error(`[${t}] 错误：未找到块 #${r}`), null;
  if (e.anchor.blockId !== e.focus.blockId)
    return orca.notify("warn", "请在同一块内选择文本"), null;
  if (e.anchor.offset === e.focus.offset && e.anchor.index === e.focus.index)
    return orca.notify("warn", "请先选择要填空的文本"), null;
  if (e.anchor.index !== e.focus.index)
    return orca.notify("warn", "请在同一段文本内选择（不支持跨样式选区）"), null;
  if (!n.content || n.content.length === 0)
    return orca.notify("warn", "块内容为空"), null;
  const a = e.anchor.index, s = n.content[a];
  if (!s || !s.v)
    return orca.notify("warn", "无法获取选中的文本片段"), null;
  const i = Math.min(e.anchor.offset, e.focus.offset), c = Math.max(e.anchor.offset, e.focus.offset), l = s.v.substring(i, c);
  if (!l || l.trim() === "")
    return orca.notify("warn", "请先选择要填空的文本"), null;
  const u = _s(n.content, t) + 1, f = !!((x = n.refs) != null && x.some(
    (g) => g.type === 2 && Me(g.alias)
  ));
  try {
    const g = Ts(
      n.content,
      e,
      l,
      u,
      t
    );
    await orca.commands.invokeEditorCommand(
      "core.editor.setBlocksContent",
      e,
      [
        {
          id: r,
          content: g
        }
      ],
      !1
    );
    const S = orca.state.blocks[r];
    if ((h = S.refs) == null ? void 0 : h.some(
      (v) => v.type === 2 && Me(v.alias)
    )) {
      if (!f)
        try {
          const v = (y = S.refs) == null ? void 0 : y.find(
            (C) => C.type === 2 && Me(C.alias)
          );
          v && (await orca.commands.invokeEditorCommand(
            "core.editor.setRefData",
            null,
            v,
            [{ name: "type", value: "cloze" }]
          ), console.log(`[${t}] 已更新 #card 标签的 type=cloze`));
        } catch (v) {
          console.error(`[${t}] 更新 #card 标签属性失败:`, v);
        }
    } else try {
      await orca.commands.invokeEditorCommand(
        "core.editor.insertTag",
        null,
        r,
        "card",
        [
          { name: "type", value: "cloze" },
          { name: "牌组", value: [] },
          // 空数组表示未设置牌组
          { name: "status", value: "" }
          // 空字符串表示正常状态
        ]
      ), console.log(`[${t}] 已添加 #card 标签并设置 type=cloze`), await vr(t);
    } catch (v) {
      console.error(`[${t}] 添加 #card 标签失败:`, v);
    }
    try {
      const v = orca.state.blocks[r];
      v._repr = {
        type: "srs.cloze-card",
        front: n.text || "",
        back: "（填空卡）",
        cardType: "cloze"
      };
      const C = lo(v.content, t);
      await orca.commands.invokeEditorCommand(
        "core.editor.setProperties",
        null,
        [r],
        [{ name: "srs.isCard", value: !0, type: 4 }]
      );
      for (let M = 0; M < C.length; M++) {
        const b = C[M], P = b - 1;
        await no(r, b, P);
      }
    } catch (v) {
      console.error(`[${t}] 自动加入复习队列失败:`, v);
    }
    return orca.notify(
      "success",
      `已创建填空 c${u}: "${l}"`,
      { title: "Cloze" }
    ), { blockId: r, clozeNumber: u };
  } catch (g) {
    return console.error(`[${t}] 创建 cloze 失败:`, g), orca.notify("error", `创建 cloze 失败: ${g}`, { title: "Cloze" }), null;
  }
}
const Mn = {
  forward: "→",
  backward: "←",
  bidirectional: "↔"
};
async function Ho(e, t, r) {
  var y, g, S, m, v;
  if (!((y = e == null ? void 0 : e.anchor) != null && y.blockId))
    return orca.notify("error", "无法获取光标位置"), null;
  const n = e.anchor.blockId, a = orca.state.blocks[n];
  if (!a)
    return orca.notify("error", "未找到当前块"), null;
  if ((g = a.content) == null ? void 0 : g.some(
    (C) => C.t === `${r}.direction`
  ))
    return orca.notify("warn", "当前块已有方向标记，请点击箭头切换方向"), null;
  if ((S = a.content) == null ? void 0 : S.some((C) => C.t === `${r}.cloze`))
    return orca.notify("warn", "方向卡暂不支持与填空卡混用"), null;
  const c = e.anchor.offset, l = a.text || "", d = l.substring(0, c).trim(), u = l.substring(c).trim();
  if (!d)
    return orca.notify("warn", "方向标记左侧需要有内容"), null;
  const f = Mn[t], x = [
    { t: "t", v: d + " " },
    {
      t: `${r}.direction`,
      v: f,
      direction: t
    },
    { t: "t", v: " " + u }
  ], h = a.content ? [...a.content] : void 0;
  try {
    if (await orca.commands.invokeEditorCommand(
      "core.editor.setBlocksContent",
      e,
      [{ id: n, content: x }],
      !1
    ), !((m = a.refs) == null ? void 0 : m.some(
      (b) => b.type === 2 && Me(b.alias)
    )))
      await orca.commands.invokeEditorCommand(
        "core.editor.insertTag",
        e,
        n,
        "card",
        [
          { name: "type", value: "direction" },
          { name: "牌组", value: [] },
          // 空数组表示未设置牌组
          { name: "status", value: "" }
          // 空字符串表示正常状态
        ]
      ), await vr(r);
    else {
      const b = (v = a.refs) == null ? void 0 : v.find(
        (P) => P.type === 2 && Me(P.alias)
      );
      b && await orca.commands.invokeEditorCommand(
        "core.editor.setRefData",
        null,
        b,
        [{ name: "type", value: "direction" }]
      );
    }
    await orca.commands.invokeEditorCommand(
      "core.editor.setProperties",
      null,
      [n],
      [{ name: "srs.isCard", value: !0, type: 4 }]
    ), t === "bidirectional" ? (await ht(n, "forward", 0), await ht(n, "backward", 1)) : await ht(n, t, 0);
    try {
      const b = {
        ...e,
        isForward: !0,
        anchor: {
          ...e.anchor,
          blockId: n,
          isInline: !0,
          index: 2,
          offset: 1
        },
        focus: {
          ...e.focus,
          blockId: n,
          isInline: !0,
          index: 2,
          offset: 1
        }
      };
      await orca.utils.setSelectionFromCursorData(b);
    } catch (b) {
      console.warn(`[${r}] 设置光标位置失败:`, b);
    }
    const M = t === "forward" ? "正向" : t === "backward" ? "反向" : "双向";
    return orca.notify("success", `已创建${M}卡片`, { title: "方向卡" }), { blockId: n, originalContent: h };
  } catch (C) {
    return console.error(`[${r}] 创建方向卡失败:`, C), orca.notify("error", `创建方向卡失败: ${C}`), null;
  }
}
function Es(e) {
  const t = ["forward", "backward", "bidirectional"], r = t.indexOf(e);
  return t[(r + 1) % t.length];
}
async function Ms(e, t, r) {
  var i;
  const n = orca.state.blocks[e];
  if (!(n != null && n.content)) return;
  const a = n.content.map((c) => c.t === `${r}.direction` ? {
    ...c,
    v: Mn[t],
    direction: t
  } : c);
  await orca.commands.invokeEditorCommand(
    "core.editor.setBlocksContent",
    null,
    [{ id: e, content: a }],
    !1
  );
  const s = n;
  s._repr && (s._repr = {
    ...s._repr,
    direction: t
  }), t === "bidirectional" && ((i = n.properties) != null && i.some(
    (l) => l.name.startsWith("srs.backward.")
  ) || await ht(e, "backward", 1));
}
function co(e, t) {
  if (!e || e.length === 0) return null;
  const r = e.findIndex((l) => l.t === `${t}.direction`);
  if (r === -1) return null;
  const n = e[r], a = e.slice(0, r), s = e.slice(r + 1), i = a.map((l) => l.v || "").join("").trim(), c = s.map((l) => l.v || "").join("").trim();
  return {
    direction: n.direction || "forward",
    leftText: i,
    rightText: c
  };
}
function An(e) {
  return e === "bidirectional" ? ["forward", "backward"] : [e];
}
function St(e) {
  const t = e.refs || [];
  if (t.length === 0) return [];
  const r = [], n = /* @__PURE__ */ new Set();
  for (const a of t) {
    if (a.type !== 2) continue;
    const s = (a.alias || "").trim();
    if (!s) continue;
    const i = s.toLowerCase();
    i === "card" || i.startsWith("card/") || n.has(a.to) || (n.add(a.to), r.push({
      name: s,
      blockId: a.to
    }));
  }
  return r;
}
async function Bn(e = "srs-plugin") {
  const t = ["card", "Card"];
  let r = [];
  for (const i of t)
    try {
      const c = await orca.invokeBackend("get-blocks-with-tags", [i]);
      c && c.length > 0 && (r = [...r, ...c]);
    } catch (c) {
      console.log(`[${e}] collectSrsBlocks: 查询标签 "${i}" 失败:`, c);
    }
  const n = /* @__PURE__ */ new Map();
  for (const i of r)
    n.set(i.id, i);
  if (r = Array.from(n.values()), r.length === 0) {
    console.log(`[${e}] collectSrsBlocks: 直接查询无结果，使用备用方案`);
    try {
      const i = await orca.invokeBackend("get-all-blocks") || [];
      console.log(`[${e}] collectSrsBlocks: get-all-blocks 返回了 ${i.length} 个块`), r = i.filter((c) => !c.refs || c.refs.length === 0 ? !1 : c.refs.some((d) => d.type !== 2 ? !1 : Me(d.alias))), console.log(`[${e}] collectSrsBlocks: 手动过滤找到 ${r.length} 个带 #card 标签的块`);
    } catch (i) {
      console.error(`[${e}] collectSrsBlocks 备用方案失败:`, i), r = [];
    }
  }
  const a = Object.values(orca.state.blocks || {}).filter((i) => {
    var l;
    if (!i) return !1;
    const c = (l = i._repr) == null ? void 0 : l.type;
    return c === "srs.card" || c === "srs.cloze-card" || c === "srs.direction-card";
  }), s = /* @__PURE__ */ new Map();
  for (const i of [...r || [], ...a])
    i && s.set(i.id, i);
  return Array.from(s.values());
}
async function st(e = "srs-plugin") {
  var a;
  const t = await Bn(e), r = /* @__PURE__ */ new Date(), n = [];
  for (const s of t) {
    if (!Qr(s)) continue;
    if (En(s) === "suspend") {
      console.log(`[${e}] collectReviewCards: 跳过已暂停的卡片 #${s.id}`);
      continue;
    }
    const c = gt(s), l = await Bt(s);
    if (c === "cloze") {
      const d = lo(s.content, e);
      if (console.log(`[${e}] collectReviewCards: 发现 cloze 卡片 #${s.id}`), console.log(`  - block.content 长度: ${((a = s.content) == null ? void 0 : a.length) || 0}`), console.log(`  - 找到 cloze 编号: ${JSON.stringify(d)}`), s.content && s.content.length > 0) {
        const u = s.content.map((f) => f.t);
        console.log(`  - fragment 类型: ${JSON.stringify(u)}`);
      }
      if (d.length === 0) {
        console.log("  - 跳过：没有找到 cloze 编号");
        continue;
      }
      for (const u of d) {
        const f = await ao(s.id, u, u - 1), x = s.text || "";
        n.push({
          id: s.id,
          front: x,
          back: `（填空 c${u}）`,
          // 填空卡不需要独立的 back
          srs: f,
          isNew: !f.lastReviewed || f.reps === 0,
          deck: l,
          tags: St(s),
          clozeNumber: u,
          // 关键：标记当前复习的填空编号
          content: s.content
          // 保存块内容用于渲染填空
        });
      }
    } else if (c === "direction") {
      const d = co(s.content, e);
      if (!d) {
        console.log(`[${e}] collectReviewCards: 块 ${s.id} 无法解析方向卡内容`);
        continue;
      }
      if (!d.leftText || !d.rightText) {
        console.log(
          `[${e}] collectReviewCards: 跳过未完成的方向卡 #${s.id}（left/right 为空）`
        );
        continue;
      }
      const u = An(d.direction);
      for (let f = 0; f < u.length; f++) {
        const x = u[f], h = await so(s.id, x, f), y = x === "forward" ? d.leftText : d.rightText, g = x === "forward" ? d.rightText : d.leftText;
        n.push({
          id: s.id,
          front: y,
          back: g,
          srs: h,
          isNew: !h.lastReviewed || h.reps === 0,
          deck: l,
          tags: St(s),
          directionType: x
          // 关键：标记当前复习的方向类型
        });
      }
    } else if (c === "excerpt") {
      const d = s.text || "", u = await Ue(s.id, r);
      n.push({
        id: s.id,
        front: d,
        // 摘录内容作为 front
        back: "",
        // 无 back
        srs: u,
        isNew: !u.lastReviewed || u.reps === 0,
        deck: l,
        tags: St(s)
      });
    } else if (s.children && s.children.length > 0) {
      const { front: u, back: f } = cr(s), x = await Ue(s.id, r);
      n.push({
        id: s.id,
        front: u,
        back: f,
        srs: x,
        isNew: !x.lastReviewed || x.reps === 0,
        deck: l,
        tags: St(s)
        // clozeNumber 和 directionType 都为 undefined（非特殊卡片）
      });
    } else {
      const u = s.text || "", f = await Ue(s.id, r);
      n.push({
        id: s.id,
        front: u,
        // 摘录内容作为 front
        back: "",
        // 无 back
        srs: f,
        isNew: !f.lastReviewed || f.reps === 0,
        deck: l,
        tags: St(s)
      });
    }
  }
  return n;
}
function uo(e) {
  const r = (/* @__PURE__ */ new Date()).getTime(), n = e.filter((l) => l.isNew ? !1 : l.srs.due.getTime() <= r), a = e.filter((l) => l.isNew ? l.srs.due.getTime() <= r : !1), s = [];
  let i = 0, c = 0;
  for (; i < n.length || c < a.length; ) {
    for (let l = 0; l < 2 && i < n.length; l++)
      s.push(n[i++]);
    c < a.length && s.push(a[c++]);
  }
  return s;
}
async function Fn(e, t = "srs-plugin") {
  const r = uo(e), { collectChildCards: n } = await Promise.resolve().then(() => pi), a = [], s = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set();
  async function c(l, d) {
    const u = `${l.id}-${l.clozeNumber || 0}-${l.directionType || "basic"}`;
    if (d.has(u))
      return;
    d.add(u), a.push(l), i.add(u);
    const f = await n(l.id, t);
    for (const x of f)
      await c(x, d);
  }
  for (const l of r) {
    const d = `${l.id}-${l.clozeNumber || 0}-${l.directionType || "basic"}`;
    if (i.has(d)) {
      console.log(`[${t}] 跳过根卡片 #${l.id}，已作为子卡片出现`);
      continue;
    }
    s.add(d), await c(l, /* @__PURE__ */ new Set());
  }
  return console.log(`[${t}] buildReviewQueueWithChildren: 基础队列 ${r.length} 张，展开后 ${a.length} 张`), a;
}
const Io = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  buildReviewQueue: uo,
  buildReviewQueueWithChildren: Fn,
  collectReviewCards: st,
  collectSrsBlocks: Bn
}, Symbol.toStringTag, { value: "Module" }));
async function As(e) {
  const t = await orca.invokeBackend("get-block", e);
  return t != null && t.properties ? t.properties.filter((r) => r.name.startsWith("srs.")).map((r) => r.name) : [];
}
async function Bs(e, t) {
  const r = await As(e);
  r.length !== 0 && (console.log(`[${t}] 清理块 #${e} 的 ${r.length} 个 SRS 属性`), await orca.commands.invokeEditorCommand(
    "core.editor.deleteProperties",
    null,
    [e],
    r
  ));
}
async function Fs(e) {
  var t;
  console.log(`[${e}] 开始扫描带 #card 标签的块...`);
  try {
    const r = await orca.invokeBackend("get-blocks-with-tags", ["card"]);
    let n = r;
    if (!r || r.length === 0) {
      console.log(`[${e}] 直接查询 #card 标签无结果，尝试获取所有块并过滤`);
      try {
        const c = await orca.invokeBackend("get-all-blocks") || [];
        console.log(`[${e}] get-all-blocks 返回了 ${c.length} 个块`);
        const l = ["card"];
        let d = [];
        for (const u of l)
          try {
            const f = await orca.invokeBackend("get-blocks-with-tags", [u]) || [];
            console.log(`[${e}] 标签 "${u}" 找到 ${f.length} 个块`), d = [...d, ...f];
          } catch (f) {
            console.log(`[${e}] 查询标签 "${u}" 失败:`, f);
          }
        d.length > 0 ? (n = d, console.log(`[${e}] 多标签查询找到 ${n.length} 个带 #card 标签的块`)) : (n = c.filter((u) => !u.refs || u.refs.length === 0 ? !1 : u.refs.some((x) => {
          if (x.type !== 2)
            return !1;
          const h = x.alias || "";
          return Me(h);
        })), console.log(`[${e}] 手动过滤找到 ${n.length} 个带 #card 标签的块`));
      } catch (c) {
        console.error(`[${e}] 备用方案失败:`, c), n = [];
      }
    }
    if (!r || r.length === 0) {
      orca.notify("info", "没有找到带 #card 标签的块", { title: "SRS 扫描" }), console.log(`[${e}] 未找到任何带 #card 标签的块`);
      return;
    }
    console.log(`[${e}] 找到 ${n.length} 个带 #card 标签的块`);
    let a = 0, s = 0;
    for (const c of n) {
      const l = c, d = gt(c);
      if (d === "direction") {
        console.log(`[${e}] 跳过：块 #${c.id} 是 direction 卡片（不转换 _repr）`), s++;
        continue;
      }
      const u = d === "cloze" ? "srs.cloze-card" : "srs.card";
      if (((t = l._repr) == null ? void 0 : t.type) === u) {
        console.log(`[${e}] 跳过：块 #${c.id} 已经是 ${d} 卡片`), s++;
        continue;
      }
      const { front: f, back: x } = cr(l), h = await Bt(c);
      l._repr = {
        type: u,
        front: f,
        back: x,
        deck: h,
        cardType: d
        // 添加 cardType 字段，方便后续使用
      }, await Ue(c.id), console.log(`[${e}] 已转换：块 #${c.id}`), console.log(`  卡片类型: ${d}`), console.log(`  题目: ${f}`), console.log(`  答案: ${x}`), h && console.log(`  Deck: ${h}`), a++;
    }
    const i = `转换了 ${a} 张卡片${s > 0 ? `，跳过 ${s} 张已有卡片` : ""}`;
    orca.notify("success", i, { title: "SRS 扫描完成" }), console.log(`[${e}] 扫描完成：${i}`);
  } catch (r) {
    console.error(`[${e}] 扫描失败:`, r), orca.notify("error", `扫描失败: ${r}`, { title: "SRS 扫描" });
  }
}
async function Ps(e, t) {
  var h;
  if (!e || !e.anchor || !e.anchor.blockId)
    return orca.notify("error", "无法获取光标位置"), null;
  const r = e.anchor.blockId, n = orca.state.blocks[r];
  if (!n)
    return orca.notify("error", "未找到当前块"), null;
  const a = n._repr ? { ...n._repr } : { type: "text" }, s = n.text || "", i = (h = n.refs) == null ? void 0 : h.some(
    (y) => y.type === 2 && // RefType.Property（标签引用）
    Me(y.alias)
  );
  if (!i)
    try {
      await orca.commands.invokeEditorCommand(
        "core.editor.insertTag",
        e,
        r,
        "card",
        [
          { name: "type", value: "basic" },
          { name: "牌组", value: [] },
          // 空数组表示未设置牌组
          { name: "status", value: "" }
          // 空字符串表示正常状态
        ]
      ), await vr(t);
    } catch (y) {
      return console.error(`[${t}] 添加标签失败:`, y), orca.notify("error", `添加标签失败: ${y}`, { title: "SRS" }), null;
    }
  const { front: c, back: l } = cr(n), d = orca.state.blocks[r], u = gt(d), f = u === "cloze" ? "srs.cloze-card" : "srs.card";
  n._repr = {
    type: f,
    front: c,
    back: l,
    cardType: u
  }, i ? await Ue(r) : (await Bs(r, t), await ro(r));
  const x = u === "cloze" ? "填空卡片" : "记忆卡片";
  return orca.notify(
    "success",
    `已添加 #card 标签并转换为 SRS ${x}`,
    { title: "SRS" }
  ), { blockId: r, originalRepr: a, originalText: s };
}
const Pn = {
  "ai.apiKey": {
    label: "API Key",
    type: "string",
    defaultValue: "",
    description: "OpenAI 兼容的 API Key（请妥善保管，不要泄露）"
  },
  "ai.apiUrl": {
    label: "API URL",
    type: "string",
    defaultValue: "https://api.openai.com/v1/chat/completions",
    description: "API 端点地址，支持 OpenAI 兼容的第三方服务（如 DeepSeek、Ollama 等）"
  },
  "ai.model": {
    label: "AI Model",
    type: "string",
    defaultValue: "gpt-3.5-turbo",
    description: "使用的模型名称（如 gpt-4、deepseek-chat、llama2 等）"
  },
  "ai.language": {
    label: "生成语言",
    type: "string",
    defaultValue: "中文",
    description: "AI 生成内容的语言"
  },
  "ai.difficulty": {
    label: "难度级别",
    type: "string",
    defaultValue: "普通",
    description: "生成卡片的难度级别（简单/普通/困难）"
  },
  "ai.promptTemplate": {
    label: "提示词模板",
    type: "string",
    defaultValue: `你是一个闪卡制作助手。根据用户提供的内容，生成一个问答对。

输入内容：{{content}}
语言要求：{{language}}
难度级别：{{difficulty}}

要求：
1. 根据内容生成一个问题和对应的答案
2. 问题应该清晰简洁，符合指定的难度级别
3. 答案应该准确但简短
4. 使用指定的语言输出

请严格以 JSON 格式返回，不要包含其他内容：
{"question": "问题内容", "answer": "答案内容"}`,
    description: "AI 生成卡片的提示词模板。支持变量：{{content}}（用户输入）、{{language}}（语言）、{{difficulty}}（难度）。使用命令面板搜索「SRS: 测试 AI 连接」来验证配置。"
  }
};
function Ln(e) {
  var r;
  const t = (r = orca.state.plugins[e]) == null ? void 0 : r.settings;
  return {
    apiKey: (t == null ? void 0 : t["ai.apiKey"]) || "",
    apiUrl: (t == null ? void 0 : t["ai.apiUrl"]) || "https://api.openai.com/v1/chat/completions",
    model: (t == null ? void 0 : t["ai.model"]) || "gpt-3.5-turbo",
    language: (t == null ? void 0 : t["ai.language"]) || "中文",
    difficulty: (t == null ? void 0 : t["ai.difficulty"]) || "普通",
    promptTemplate: (t == null ? void 0 : t["ai.promptTemplate"]) || Pn["ai.promptTemplate"].defaultValue
  };
}
function Ls(e, t, r) {
  return e.replace(/\{\{content\}\}/g, t).replace(/\{\{language\}\}/g, r.language).replace(/\{\{difficulty\}\}/g, r.difficulty);
}
function Ws(e) {
  try {
    const t = JSON.parse(e);
    if (t.question && t.answer)
      return {
        success: !0,
        data: {
          question: String(t.question).trim(),
          answer: String(t.answer).trim()
        }
      };
  } catch {
    const t = e.match(/\{[\s\S]*"question"[\s\S]*"answer"[\s\S]*\}/);
    if (t)
      try {
        const r = JSON.parse(t[0]);
        if (r.question && r.answer)
          return {
            success: !0,
            data: {
              question: String(r.question).trim(),
              answer: String(r.answer).trim()
            }
          };
      } catch {
      }
  }
  return {
    success: !1,
    error: {
      code: "PARSE_ERROR",
      message: "无法解析 AI 响应格式，请检查提示词模板"
    }
  };
}
async function Os(e, t) {
  var a, s, i, c;
  const r = Ln(e);
  if (!r.apiKey)
    return {
      success: !1,
      error: { code: "NO_API_KEY", message: "请先在设置中配置 API Key" }
    };
  const n = Ls(r.promptTemplate, t, r);
  console.log("[AI Service] 调用 AI 生成卡片"), console.log(`[AI Service] API URL: ${r.apiUrl}`), console.log(`[AI Service] Model: ${r.model}`), console.log(`[AI Service] 提示词长度: ${n.length}`);
  try {
    const l = await fetch(r.apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${r.apiKey}`
      },
      body: JSON.stringify({
        model: r.model,
        messages: [
          {
            role: "system",
            content: "你是一个闪卡制作助手。你的任务是根据用户输入生成问答卡片。请严格以 JSON 格式返回结果。"
          },
          { role: "user", content: n }
        ],
        temperature: 0.7,
        max_tokens: 1e3
      })
    });
    if (!l.ok) {
      let f = `请求失败: ${l.status}`;
      try {
        f = ((a = (await l.json()).error) == null ? void 0 : a.message) || f;
      } catch {
      }
      return console.error(`[AI Service] API 错误: ${f}`), {
        success: !1,
        error: {
          code: `HTTP_${l.status}`,
          message: f
        }
      };
    }
    const u = (c = (i = (s = (await l.json()).choices) == null ? void 0 : s[0]) == null ? void 0 : i.message) == null ? void 0 : c.content;
    return u ? (console.log(`[AI Service] AI 响应: ${u}`), Ws(u)) : (console.error("[AI Service] AI 返回内容为空"), {
      success: !1,
      error: { code: "EMPTY_RESPONSE", message: "AI 返回内容为空" }
    });
  } catch (l) {
    const d = l instanceof Error ? l.message : "网络错误";
    return console.error(`[AI Service] 网络错误: ${d}`), {
      success: !1,
      error: {
        code: "NETWORK_ERROR",
        message: d
      }
    };
  }
}
async function Hs(e) {
  var r;
  const t = Ln(e);
  if (!t.apiKey)
    return { success: !1, message: "请先配置 API Key" };
  console.log(`[AI Service] 测试连接 - URL: ${t.apiUrl}, Model: ${t.model}`);
  try {
    const n = await fetch(t.apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${t.apiKey}`
      },
      body: JSON.stringify({
        model: t.model,
        messages: [{ role: "user", content: "Hi" }],
        max_tokens: 5
      })
    });
    if (n.ok) {
      const s = (await n.json()).model || t.model;
      return console.log(`[AI Service] 连接成功 - 使用模型: ${s}`), { success: !0, message: `连接成功！使用模型: ${s}` };
    } else {
      let a = `连接失败: ${n.status}`;
      try {
        a = ((r = (await n.json()).error) == null ? void 0 : r.message) || a;
      } catch {
      }
      return console.error(`[AI Service] 连接失败: ${a}`), { success: !1, message: a };
    }
  } catch (n) {
    const a = n instanceof Error ? n.message : "网络错误";
    return console.error(`[AI Service] 连接错误: ${a}`), { success: !1, message: a };
  }
}
async function Is(e, t) {
  var l;
  if (console.log(`[${t}] ========== makeAICardFromBlock 开始执行 ==========`), !e || !e.anchor || !e.anchor.blockId)
    return orca.notify("error", "无法获取光标位置"), console.error(`[${t}] 错误：无法获取光标位置`), null;
  const r = e.anchor.blockId, n = orca.state.blocks[r];
  if (!n)
    return orca.notify("error", "未找到当前块"), console.error(`[${t}] 错误：未找到块 #${r}`), null;
  const a = (l = n.text) == null ? void 0 : l.trim();
  if (!a)
    return orca.notify("warn", "当前块内容为空，无法生成卡片", { title: "AI 卡片" }), console.warn(`[${t}] 警告：块 #${r} 内容为空`), null;
  console.log(`[${t}] 原始块 ID: ${r}`), console.log(`[${t}] 原始内容: "${a}"`), orca.notify("info", "正在调用 AI 生成卡片...", { title: "AI 卡片" });
  const s = await Os(t, a);
  if (!s.success)
    return orca.notify("error", s.error.message, { title: "AI 卡片生成失败" }), console.error(`[${t}] AI 生成失败: ${s.error.message}`), null;
  const { question: i, answer: c } = s.data;
  console.log(`[${t}] AI 生成成功`), console.log(`[${t}]   问题: "${i}"`), console.log(`[${t}]   答案: "${c}"`);
  try {
    console.log(`[${t}] 创建子块（问题）...`);
    const d = await orca.commands.invokeEditorCommand(
      "core.editor.insertBlock",
      null,
      n,
      "lastChild",
      [{ t: "t", v: i }]
    );
    if (!d)
      return orca.notify("error", "创建子块失败", { title: "AI 卡片" }), console.error(`[${t}] 创建子块失败`), null;
    console.log(`[${t}] 子块创建成功: #${d}`);
    const u = orca.state.blocks[d];
    if (!u)
      return orca.notify("error", "无法获取子块", { title: "AI 卡片" }), console.error(`[${t}] 无法获取子块 #${d}`), null;
    console.log(`[${t}] 创建孙子块（答案）...`);
    const f = await orca.commands.invokeEditorCommand(
      "core.editor.insertBlock",
      null,
      u,
      "lastChild",
      [{ t: "t", v: c }]
    );
    if (!f)
      return orca.notify("error", "创建孙子块失败", { title: "AI 卡片" }), console.error(`[${t}] 创建孙子块失败`), await orca.commands.invokeEditorCommand(
        "core.editor.deleteBlocks",
        null,
        [d]
      ), null;
    console.log(`[${t}] 孙子块创建成功: #${f}`), console.log(`[${t}] 添加 #card 标签到子块...`), await orca.commands.invokeEditorCommand(
      "core.editor.insertTag",
      e,
      d,
      "card",
      [
        { name: "type", value: "basic" },
        { name: "牌组", value: [] },
        // 空数组表示未设置牌组
        { name: "status", value: "" }
        // 空字符串表示正常状态
      ]
    ), console.log(`[${t}] #card 标签添加成功`), await vr(t);
    const x = orca.state.blocks[d];
    return x && (x._repr = {
      type: "srs.card",
      front: i,
      back: c,
      cardType: "basic"
    }, console.log(`[${t}] 子块 _repr 已设置为 srs.card`)), console.log(`[${t}] 初始化 SRS 状态...`), await Ue(d), console.log(`[${t}] ========== AI 卡片创建完成 ==========`), console.log(`[${t}] 结构：`), console.log(`[${t}]   原始块 #${r}: "${a}"`), console.log(`[${t}]     └─ 子块 #${d} [#card]: "${i}"`), console.log(`[${t}]         └─ 孙子块 #${f}: "${c}"`), orca.notify(
      "success",
      `已生成卡片
问题: ${i}
答案: ${c}`,
      { title: "AI 卡片创建成功" }
    ), {
      blockId: d,
      question: i,
      answer: c
    };
  } catch (d) {
    const u = d instanceof Error ? d.message : String(d);
    return console.error(`[${t}] AI 卡片创建异常:`, d), orca.notify("error", `创建失败: ${u}`, { title: "AI 卡片" }), null;
  }
}
function Ns(e) {
  const t = e;
  orca.commands.registerCommand(
    `${e}.scanCardsFromTags`,
    () => {
      console.log(`[${t}] 执行标签扫描`), Fs(t);
    },
    "SRS: 扫描带标签的卡片"
  ), orca.commands.registerEditorCommand(
    `${e}.makeCardFromBlock`,
    async (r, ...n) => {
      const [a, s, i] = r;
      if (!i)
        return orca.notify("error", "无法获取光标位置"), null;
      const c = await Ps(i, t);
      return c ? { ret: c, undoArgs: c } : null;
    },
    async (r) => {
      if (!r || !r.blockId) return;
      const n = orca.state.blocks[r.blockId];
      n && (n._repr = r.originalRepr || { type: "text" }, r.originalText !== void 0 && (n.text = r.originalText), console.log(`[${t}] 已撤销：块 #${r.blockId} 已恢复`));
    },
    {
      label: "SRS: 将块转换为记忆卡片",
      hasArgs: !1
    }
  ), orca.commands.registerEditorCommand(
    `${e}.createCloze`,
    async (r, ...n) => {
      const [a, s, i] = r;
      if (!i)
        return orca.notify("error", "无法获取光标位置"), null;
      const c = await zs(i, t);
      return c ? { ret: c, undoArgs: c } : null;
    },
    async (r) => {
      !r || !r.blockId || console.log(`[${t}] Cloze 撤销：块 #${r.blockId}，编号 c${r.clozeNumber}`);
    },
    {
      label: "SRS: 创建 Cloze 填空",
      hasArgs: !1
    }
  ), orca.commands.registerEditorCommand(
    `${e}.createDirectionForward`,
    async (r, ...n) => {
      const [a, s, i] = r;
      if (!i)
        return orca.notify("error", "无法获取光标位置"), null;
      const c = await Ho(i, "forward", t);
      return c ? { ret: c, undoArgs: c } : null;
    },
    async (r) => {
      !r || !r.blockId || !orca.state.blocks[r.blockId] || r.originalContent && await orca.commands.invokeEditorCommand(
        "core.editor.setBlocksContent",
        null,
        [
          {
            id: r.blockId,
            content: r.originalContent
          }
        ],
        !1
      );
    },
    {
      label: "SRS: 创建正向方向卡 →",
      hasArgs: !1
    }
  ), orca.commands.registerEditorCommand(
    `${e}.createDirectionBackward`,
    async (r, ...n) => {
      const [a, s, i] = r;
      if (!i)
        return orca.notify("error", "无法获取光标位置"), null;
      const c = await Ho(i, "backward", t);
      return c ? { ret: c, undoArgs: c } : null;
    },
    async (r) => {
      !r || !r.blockId || !orca.state.blocks[r.blockId] || r.originalContent && await orca.commands.invokeEditorCommand(
        "core.editor.setBlocksContent",
        null,
        [
          {
            id: r.blockId,
            content: r.originalContent
          }
        ],
        !1
      );
    },
    {
      label: "SRS: 创建反向方向卡 ←",
      hasArgs: !1
    }
  ), orca.commands.registerEditorCommand(
    `${e}.makeAICard`,
    async (r, ...n) => {
      const [a, s, i] = r;
      if (!i)
        return orca.notify("error", "无法获取光标位置"), null;
      const c = await Is(i, t);
      return c ? { ret: c, undoArgs: c } : null;
    },
    async (r) => {
      if (!(!r || !r.blockId))
        try {
          await orca.commands.invokeEditorCommand(
            "core.editor.deleteBlocks",
            null,
            [r.blockId]
          ), console.log(`[${t}] 已撤销 AI 卡片：删除块 #${r.blockId}`);
        } catch (n) {
          console.error(`[${t}] 撤销 AI 卡片失败:`, n);
        }
    },
    {
      label: "SRS: AI 生成记忆卡片",
      hasArgs: !1
    }
  ), orca.commands.registerCommand(
    `${e}.testAIConnection`,
    async () => {
      console.log(`[${t}] 测试 AI 连接`), orca.notify("info", "正在测试 AI 连接...", { title: "AI 连接测试" });
      const r = await Hs(t);
      r.success ? orca.notify("success", r.message, { title: "AI 连接测试" }) : orca.notify("error", r.message, { title: "AI 连接测试" });
    },
    "SRS: 测试 AI 连接"
  ), orca.commands.registerCommand(
    `${e}.openOldReviewPanel`,
    async () => {
      console.log(`[${t}] 打开旧复习面板`);
      const { startReviewSession: r } = await Promise.resolve().then(() => He);
      await r();
    },
    "SRS: 打开旧复习面板"
  ), orca.commands.registerCommand(
    `${e}.openFlashcardHome`,
    async () => {
      console.log(`[${t}] 打开 Flash Home`);
      const { openFlashcardHome: r } = await Promise.resolve().then(() => He);
      await r();
    },
    "SRS: 打开 Flash Home"
  );
}
function Ys(e) {
  orca.commands.unregisterCommand(`${e}.scanCardsFromTags`), orca.commands.unregisterEditorCommand(`${e}.makeCardFromBlock`), orca.commands.unregisterEditorCommand(`${e}.createCloze`), orca.commands.unregisterEditorCommand(`${e}.createDirectionForward`), orca.commands.unregisterEditorCommand(`${e}.createDirectionBackward`), orca.commands.unregisterEditorCommand(`${e}.makeAICard`), orca.commands.unregisterCommand(`${e}.testAIConnection`), orca.commands.unregisterCommand(`${e}.openOldReviewPanel`), orca.commands.unregisterCommand(`${e}.openFlashcardHome`);
}
var Wn = { exports: {} };
const Us = React;
var Ct = {}, No;
function qs() {
  if (No) return Ct;
  No = 1;
  /**
   * @license React
   * react-jsx-runtime.development.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  return function() {
    var e = Us, t = Symbol.for("react.element"), r = Symbol.for("react.portal"), n = Symbol.for("react.fragment"), a = Symbol.for("react.strict_mode"), s = Symbol.for("react.profiler"), i = Symbol.for("react.provider"), c = Symbol.for("react.context"), l = Symbol.for("react.forward_ref"), d = Symbol.for("react.suspense"), u = Symbol.for("react.suspense_list"), f = Symbol.for("react.memo"), x = Symbol.for("react.lazy"), h = Symbol.for("react.offscreen"), y = Symbol.iterator, g = "@@iterator";
    function S(p) {
      if (p === null || typeof p != "object")
        return null;
      var $ = y && p[y] || p[g];
      return typeof $ == "function" ? $ : null;
    }
    var m = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    function v(p) {
      {
        for (var $ = arguments.length, F = new Array($ > 1 ? $ - 1 : 0), V = 1; V < $; V++)
          F[V - 1] = arguments[V];
        C("error", p, F);
      }
    }
    function C(p, $, F) {
      {
        var V = m.ReactDebugCurrentFrame, ae = V.getStackAddendum();
        ae !== "" && ($ += "%s", F = F.concat([ae]));
        var le = F.map(function(te) {
          return String(te);
        });
        le.unshift("Warning: " + $), Function.prototype.apply.call(console[p], console, le);
      }
    }
    var M = !1, b = !1, P = !1, N = !1, T = !1, O;
    O = Symbol.for("react.module.reference");
    function H(p) {
      return !!(typeof p == "string" || typeof p == "function" || p === n || p === s || T || p === a || p === d || p === u || N || p === h || M || b || P || typeof p == "object" && p !== null && (p.$$typeof === x || p.$$typeof === f || p.$$typeof === i || p.$$typeof === c || p.$$typeof === l || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      p.$$typeof === O || p.getModuleId !== void 0));
    }
    function z(p, $, F) {
      var V = p.displayName;
      if (V)
        return V;
      var ae = $.displayName || $.name || "";
      return ae !== "" ? F + "(" + ae + ")" : F;
    }
    function D(p) {
      return p.displayName || "Context";
    }
    function _(p) {
      if (p == null)
        return null;
      if (typeof p.tag == "number" && v("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof p == "function")
        return p.displayName || p.name || null;
      if (typeof p == "string")
        return p;
      switch (p) {
        case n:
          return "Fragment";
        case r:
          return "Portal";
        case s:
          return "Profiler";
        case a:
          return "StrictMode";
        case d:
          return "Suspense";
        case u:
          return "SuspenseList";
      }
      if (typeof p == "object")
        switch (p.$$typeof) {
          case c:
            var $ = p;
            return D($) + ".Consumer";
          case i:
            var F = p;
            return D(F._context) + ".Provider";
          case l:
            return z(p, p.render, "ForwardRef");
          case f:
            var V = p.displayName || null;
            return V !== null ? V : _(p.type) || "Memo";
          case x: {
            var ae = p, le = ae._payload, te = ae._init;
            try {
              return _(te(le));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var j = Object.assign, w = 0, B, J, G, pe, se, k, ue;
    function Ce() {
    }
    Ce.__reactDisabledLog = !0;
    function $e() {
      {
        if (w === 0) {
          B = console.log, J = console.info, G = console.warn, pe = console.error, se = console.group, k = console.groupCollapsed, ue = console.groupEnd;
          var p = {
            configurable: !0,
            enumerable: !0,
            value: Ce,
            writable: !0
          };
          Object.defineProperties(console, {
            info: p,
            log: p,
            warn: p,
            error: p,
            group: p,
            groupCollapsed: p,
            groupEnd: p
          });
        }
        w++;
      }
    }
    function Ae() {
      {
        if (w--, w === 0) {
          var p = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: j({}, p, {
              value: B
            }),
            info: j({}, p, {
              value: J
            }),
            warn: j({}, p, {
              value: G
            }),
            error: j({}, p, {
              value: pe
            }),
            group: j({}, p, {
              value: se
            }),
            groupCollapsed: j({}, p, {
              value: k
            }),
            groupEnd: j({}, p, {
              value: ue
            })
          });
        }
        w < 0 && v("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var Ee = m.ReactCurrentDispatcher, A;
    function L(p, $, F) {
      {
        if (A === void 0)
          try {
            throw Error();
          } catch (ae) {
            var V = ae.stack.trim().match(/\n( *(at )?)/);
            A = V && V[1] || "";
          }
        return `
` + A + p;
      }
    }
    var Y = !1, ee;
    {
      var xe = typeof WeakMap == "function" ? WeakMap : Map;
      ee = new xe();
    }
    function ge(p, $) {
      if (!p || Y)
        return "";
      {
        var F = ee.get(p);
        if (F !== void 0)
          return F;
      }
      var V;
      Y = !0;
      var ae = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var le;
      le = Ee.current, Ee.current = null, $e();
      try {
        if ($) {
          var te = function() {
            throw Error();
          };
          if (Object.defineProperty(te.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(te, []);
            } catch (_e) {
              V = _e;
            }
            Reflect.construct(p, [], te);
          } else {
            try {
              te.call();
            } catch (_e) {
              V = _e;
            }
            p.call(te.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (_e) {
            V = _e;
          }
          p();
        }
      } catch (_e) {
        if (_e && V && typeof _e.stack == "string") {
          for (var Z = _e.stack.split(`
`), je = V.stack.split(`
`), he = Z.length - 1, ye = je.length - 1; he >= 1 && ye >= 0 && Z[he] !== je[ye]; )
            ye--;
          for (; he >= 1 && ye >= 0; he--, ye--)
            if (Z[he] !== je[ye]) {
              if (he !== 1 || ye !== 1)
                do
                  if (he--, ye--, ye < 0 || Z[he] !== je[ye]) {
                    var Be = `
` + Z[he].replace(" at new ", " at ");
                    return p.displayName && Be.includes("<anonymous>") && (Be = Be.replace("<anonymous>", p.displayName)), typeof p == "function" && ee.set(p, Be), Be;
                  }
                while (he >= 1 && ye >= 0);
              break;
            }
        }
      } finally {
        Y = !1, Ee.current = le, Ae(), Error.prepareStackTrace = ae;
      }
      var ct = p ? p.displayName || p.name : "", et = ct ? L(ct) : "";
      return typeof p == "function" && ee.set(p, et), et;
    }
    function R(p, $, F) {
      return ge(p, !1);
    }
    function W(p) {
      var $ = p.prototype;
      return !!($ && $.isReactComponent);
    }
    function Q(p, $, F) {
      if (p == null)
        return "";
      if (typeof p == "function")
        return ge(p, W(p));
      if (typeof p == "string")
        return L(p);
      switch (p) {
        case d:
          return L("Suspense");
        case u:
          return L("SuspenseList");
      }
      if (typeof p == "object")
        switch (p.$$typeof) {
          case l:
            return R(p.render);
          case f:
            return Q(p.type, $, F);
          case x: {
            var V = p, ae = V._payload, le = V._init;
            try {
              return Q(le(ae), $, F);
            } catch {
            }
          }
        }
      return "";
    }
    var U = Object.prototype.hasOwnProperty, oe = {}, X = m.ReactDebugCurrentFrame;
    function q(p) {
      if (p) {
        var $ = p._owner, F = Q(p.type, p._source, $ ? $.type : null);
        X.setExtraStackFrame(F);
      } else
        X.setExtraStackFrame(null);
    }
    function de(p, $, F, V, ae) {
      {
        var le = Function.call.bind(U);
        for (var te in p)
          if (le(p, te)) {
            var Z = void 0;
            try {
              if (typeof p[te] != "function") {
                var je = Error((V || "React class") + ": " + F + " type `" + te + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof p[te] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw je.name = "Invariant Violation", je;
              }
              Z = p[te]($, te, V, F, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (he) {
              Z = he;
            }
            Z && !(Z instanceof Error) && (q(ae), v("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", V || "React class", F, te, typeof Z), q(null)), Z instanceof Error && !(Z.message in oe) && (oe[Z.message] = !0, q(ae), v("Failed %s type: %s", F, Z.message), q(null));
          }
      }
    }
    var ne = Array.isArray;
    function ve(p) {
      return ne(p);
    }
    function it(p) {
      {
        var $ = typeof Symbol == "function" && Symbol.toStringTag, F = $ && p[Symbol.toStringTag] || p.constructor.name || "Object";
        return F;
      }
    }
    function ie(p) {
      try {
        return Ht(p), !1;
      } catch {
        return !0;
      }
    }
    function Ht(p) {
      return "" + p;
    }
    function De(p) {
      if (ie(p))
        return v("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", it(p)), Ht(p);
    }
    var jo = m.ReactCurrentOwner, ga = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, ko, Ro;
    function ya(p) {
      if (U.call(p, "ref")) {
        var $ = Object.getOwnPropertyDescriptor(p, "ref").get;
        if ($ && $.isReactWarning)
          return !1;
      }
      return p.ref !== void 0;
    }
    function ma(p) {
      if (U.call(p, "key")) {
        var $ = Object.getOwnPropertyDescriptor(p, "key").get;
        if ($ && $.isReactWarning)
          return !1;
      }
      return p.key !== void 0;
    }
    function va(p, $) {
      typeof p.ref == "string" && jo.current;
    }
    function ba(p, $) {
      {
        var F = function() {
          ko || (ko = !0, v("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", $));
        };
        F.isReactWarning = !0, Object.defineProperty(p, "key", {
          get: F,
          configurable: !0
        });
      }
    }
    function wa(p, $) {
      {
        var F = function() {
          Ro || (Ro = !0, v("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", $));
        };
        F.isReactWarning = !0, Object.defineProperty(p, "ref", {
          get: F,
          configurable: !0
        });
      }
    }
    var Sa = function(p, $, F, V, ae, le, te) {
      var Z = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: t,
        // Built-in properties that belong on the element
        type: p,
        key: $,
        ref: F,
        props: te,
        // Record the component responsible for creating this element.
        _owner: le
      };
      return Z._store = {}, Object.defineProperty(Z._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(Z, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: V
      }), Object.defineProperty(Z, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: ae
      }), Object.freeze && (Object.freeze(Z.props), Object.freeze(Z)), Z;
    };
    function Ca(p, $, F, V, ae) {
      {
        var le, te = {}, Z = null, je = null;
        F !== void 0 && (De(F), Z = "" + F), ma($) && (De($.key), Z = "" + $.key), ya($) && (je = $.ref, va($, ae));
        for (le in $)
          U.call($, le) && !ga.hasOwnProperty(le) && (te[le] = $[le]);
        if (p && p.defaultProps) {
          var he = p.defaultProps;
          for (le in he)
            te[le] === void 0 && (te[le] = he[le]);
        }
        if (Z || je) {
          var ye = typeof p == "function" ? p.displayName || p.name || "Unknown" : p;
          Z && ba(te, ye), je && wa(te, ye);
        }
        return Sa(p, Z, je, ae, V, jo.current, te);
      }
    }
    var wr = m.ReactCurrentOwner, $o = m.ReactDebugCurrentFrame;
    function lt(p) {
      if (p) {
        var $ = p._owner, F = Q(p.type, p._source, $ ? $.type : null);
        $o.setExtraStackFrame(F);
      } else
        $o.setExtraStackFrame(null);
    }
    var Sr;
    Sr = !1;
    function Cr(p) {
      return typeof p == "object" && p !== null && p.$$typeof === t;
    }
    function Do() {
      {
        if (wr.current) {
          var p = _(wr.current.type);
          if (p)
            return `

Check the render method of \`` + p + "`.";
        }
        return "";
      }
    }
    function ja(p) {
      return "";
    }
    var _o = {};
    function ka(p) {
      {
        var $ = Do();
        if (!$) {
          var F = typeof p == "string" ? p : p.displayName || p.name;
          F && ($ = `

Check the top-level render call using <` + F + ">.");
        }
        return $;
      }
    }
    function To(p, $) {
      {
        if (!p._store || p._store.validated || p.key != null)
          return;
        p._store.validated = !0;
        var F = ka($);
        if (_o[F])
          return;
        _o[F] = !0;
        var V = "";
        p && p._owner && p._owner !== wr.current && (V = " It was passed a child from " + _(p._owner.type) + "."), lt(p), v('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', F, V), lt(null);
      }
    }
    function zo(p, $) {
      {
        if (typeof p != "object")
          return;
        if (ve(p))
          for (var F = 0; F < p.length; F++) {
            var V = p[F];
            Cr(V) && To(V, $);
          }
        else if (Cr(p))
          p._store && (p._store.validated = !0);
        else if (p) {
          var ae = S(p);
          if (typeof ae == "function" && ae !== p.entries)
            for (var le = ae.call(p), te; !(te = le.next()).done; )
              Cr(te.value) && To(te.value, $);
        }
      }
    }
    function Ra(p) {
      {
        var $ = p.type;
        if ($ == null || typeof $ == "string")
          return;
        var F;
        if (typeof $ == "function")
          F = $.propTypes;
        else if (typeof $ == "object" && ($.$$typeof === l || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        $.$$typeof === f))
          F = $.propTypes;
        else
          return;
        if (F) {
          var V = _($);
          de(F, p.props, "prop", V, p);
        } else if ($.PropTypes !== void 0 && !Sr) {
          Sr = !0;
          var ae = _($);
          v("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", ae || "Unknown");
        }
        typeof $.getDefaultProps == "function" && !$.getDefaultProps.isReactClassApproved && v("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function $a(p) {
      {
        for (var $ = Object.keys(p.props), F = 0; F < $.length; F++) {
          var V = $[F];
          if (V !== "children" && V !== "key") {
            lt(p), v("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", V), lt(null);
            break;
          }
        }
        p.ref !== null && (lt(p), v("Invalid attribute `ref` supplied to `React.Fragment`."), lt(null));
      }
    }
    var Eo = {};
    function Mo(p, $, F, V, ae, le) {
      {
        var te = H(p);
        if (!te) {
          var Z = "";
          (p === void 0 || typeof p == "object" && p !== null && Object.keys(p).length === 0) && (Z += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var je = ja();
          je ? Z += je : Z += Do();
          var he;
          p === null ? he = "null" : ve(p) ? he = "array" : p !== void 0 && p.$$typeof === t ? (he = "<" + (_(p.type) || "Unknown") + " />", Z = " Did you accidentally export a JSX literal instead of a component?") : he = typeof p, v("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", he, Z);
        }
        var ye = Ca(p, $, F, ae, le);
        if (ye == null)
          return ye;
        if (te) {
          var Be = $.children;
          if (Be !== void 0)
            if (V)
              if (ve(Be)) {
                for (var ct = 0; ct < Be.length; ct++)
                  zo(Be[ct], p);
                Object.freeze && Object.freeze(Be);
              } else
                v("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else
              zo(Be, p);
        }
        if (U.call($, "key")) {
          var et = _(p), _e = Object.keys($).filter(function(Ma) {
            return Ma !== "key";
          }), jr = _e.length > 0 ? "{key: someKey, " + _e.join(": ..., ") + ": ...}" : "{key: someKey}";
          if (!Eo[et + jr]) {
            var Ea = _e.length > 0 ? "{" + _e.join(": ..., ") + ": ...}" : "{}";
            v(`A props object containing a "key" prop is being spread into JSX:
  let props = %s;
  <%s {...props} />
React keys must be passed directly to JSX without using spread:
  let props = %s;
  <%s key={someKey} {...props} />`, jr, et, Ea, et), Eo[et + jr] = !0;
          }
        }
        return p === n ? $a(ye) : Ra(ye), ye;
      }
    }
    function Da(p, $, F) {
      return Mo(p, $, F, !0);
    }
    function _a(p, $, F) {
      return Mo(p, $, F, !1);
    }
    var Ta = _a, za = Da;
    Ct.Fragment = n, Ct.jsx = Ta, Ct.jsxs = za;
  }(), Ct;
}
Wn.exports = qs();
var o = Wn.exports;
function Vs(e) {
  orca.headbar.registerHeadbarButton(`${e}.reviewButton`, () => /* @__PURE__ */ o.jsx(
    orca.components.Button,
    {
      variant: "plain",
      tabIndex: -1,
      onClick: () => orca.commands.invokeCommand(`${e}.openOldReviewPanel`),
      title: "开始闪卡复习",
      children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-brain orca-headbar-icon" })
    }
  )), orca.headbar.registerHeadbarButton(`${e}.flashHomeButton`, () => /* @__PURE__ */ o.jsx(
    orca.components.Button,
    {
      variant: "plain",
      tabIndex: -1,
      onClick: () => orca.commands.invokeCommand(`${e}.openFlashcardHome`),
      title: "打开 Flash Home",
      children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-home orca-headbar-icon" })
    }
  )), orca.toolbar.registerToolbarButton(`${e}.clozeButton`, {
    icon: "ti ti-braces",
    tooltip: "创建 Cloze 填空",
    command: `${e}.createCloze`
  }), orca.slashCommands.registerSlashCommand(`${e}.makeCard`, {
    icon: "ti ti-card-plus",
    group: "SRS",
    title: "转换为记忆卡片",
    command: `${e}.makeCardFromBlock`
  }), orca.slashCommands.registerSlashCommand(`${e}.directionForward`, {
    icon: "ti ti-arrow-right",
    group: "SRS",
    title: "创建正向方向卡 → (光标位置分隔问答)",
    command: `${e}.createDirectionForward`
  }), orca.slashCommands.registerSlashCommand(`${e}.directionBackward`, {
    icon: "ti ti-arrow-left",
    group: "SRS",
    title: "创建反向方向卡 ← (光标位置分隔问答)",
    command: `${e}.createDirectionBackward`
  }), orca.slashCommands.registerSlashCommand(`${e}.aiCard`, {
    icon: "ti ti-robot",
    group: "SRS",
    title: "AI 生成记忆卡片",
    command: `${e}.makeAICard`
  });
}
function Ks(e) {
  orca.headbar.unregisterHeadbarButton(`${e}.reviewButton`), orca.headbar.unregisterHeadbarButton(`${e}.flashHomeButton`), orca.toolbar.unregisterToolbarButton(`${e}.clozeButton`), orca.slashCommands.unregisterSlashCommand(`${e}.makeCard`), orca.slashCommands.unregisterSlashCommand(`${e}.directionForward`), orca.slashCommands.unregisterSlashCommand(`${e}.directionBackward`), orca.slashCommands.unregisterSlashCommand(`${e}.aiCard`);
}
const { Component: Gs } = window.React, { Button: Yo } = orca.components;
class ot extends Gs {
  constructor(r) {
    super(r);
    ce(this, "_isMounted", !1);
    /**
     * 重置错误状态，尝试重新渲染子组件
     */
    ce(this, "handleRetry", () => {
      this._isMounted && this.setState({
        hasError: !1,
        error: null,
        errorInfo: null
      });
    });
    /**
     * 复制错误信息到剪贴板
     */
    ce(this, "handleCopyError", async () => {
      const { error: r, errorInfo: n } = this.state, { componentName: a } = this.props, s = [
        "=== SRS 错误报告 ===",
        `组件: ${a || "未知"}`,
        `时间: ${(/* @__PURE__ */ new Date()).toISOString()}`,
        "",
        `错误信息: ${(r == null ? void 0 : r.message) || "未知错误"}`,
        "",
        "错误堆栈:",
        (r == null ? void 0 : r.stack) || "无堆栈信息",
        "",
        "组件堆栈:",
        (n == null ? void 0 : n.componentStack) || "无组件堆栈信息"
      ].join(`
`);
      try {
        await navigator.clipboard.writeText(s), orca.notify("success", "错误信息已复制到剪贴板", { title: "复制成功" });
      } catch (i) {
        console.warn("[SRS Error Boundary] 复制到剪贴板失败:", i), orca.notify("warn", "复制失败，请查看控制台日志", { title: "复制失败" });
      }
    });
    this.state = {
      hasError: !1,
      error: null,
      errorInfo: null
    };
  }
  componentDidMount() {
    this._isMounted = !0;
  }
  componentWillUnmount() {
    this._isMounted = !1;
  }
  static getDerivedStateFromError(r) {
    return { hasError: !0, error: r };
  }
  componentDidCatch(r, n) {
    const { componentName: a, onError: s } = this.props, i = a ? `[SRS Error Boundary - ${a}]` : "[SRS Error Boundary]";
    if (console.error(i, "捕获到运行时错误:"), console.error(i, "错误信息:", r.message), console.error(i, "错误堆栈:", r.stack), console.error(i, "组件堆栈:", n.componentStack), this._isMounted && this.setState({ errorInfo: n }), s)
      try {
        s(r, n);
      } catch (c) {
        console.error(i, "错误回调执行失败:", c);
      }
    try {
      orca.notify("error", `组件运行时错误：${r.message}`, {
        title: a ? `${a} 错误` : "SRS 错误"
      });
    } catch (c) {
      console.warn(i, "发送错误通知失败:", c);
    }
  }
  render() {
    const { hasError: r, error: n } = this.state, { children: a, errorTitle: s, renderError: i } = this.props;
    return r ? i ? i(n, this.handleRetry) : /* @__PURE__ */ o.jsxs(
      "div",
      {
        style: {
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "24px",
          minHeight: "120px",
          backgroundColor: "var(--orca-color-bg-1)",
          border: "1px solid var(--orca-color-danger-6)",
          borderRadius: "12px",
          gap: "16px"
        },
        children: [
          /* @__PURE__ */ o.jsx(
            "div",
            {
              style: {
                width: "48px",
                height: "48px",
                borderRadius: "50%",
                backgroundColor: "var(--orca-color-danger-1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "24px"
              },
              children: "⚠️"
            }
          ),
          /* @__PURE__ */ o.jsx(
            "div",
            {
              style: {
                fontSize: "16px",
                fontWeight: 600,
                color: "var(--orca-color-text-1)"
              },
              children: s || "组件加载出错"
            }
          ),
          /* @__PURE__ */ o.jsx(
            "div",
            {
              style: {
                fontSize: "13px",
                color: "var(--orca-color-text-3)",
                textAlign: "center",
                maxWidth: "400px",
                wordBreak: "break-word"
              },
              children: (n == null ? void 0 : n.message) || "发生未知错误，请刷新重试"
            }
          ),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "12px", marginTop: "8px" }, children: [
            /* @__PURE__ */ o.jsx(Yo, { variant: "solid", onClick: this.handleRetry, children: "重试" }),
            /* @__PURE__ */ o.jsx(Yo, { variant: "plain", onClick: this.handleCopyError, children: "复制错误信息" })
          ] })
        ]
      }
    ) : a;
  }
}
const { useState: Ve, useMemo: Ut, useEffect: zr, useCallback: Ke } = window.React, { useSnapshot: Js } = window.Valtio, { BlockShell: Qs, BlockChildren: Xs, Button: ke, BlockBreadcrumb: Zs } = orca.components;
function Er({
  panelId: e,
  blockId: t,
  rndId: r,
  blockLevel: n,
  indentLevel: a,
  mirrorId: s,
  initiallyCollapsed: i,
  renderingMode: c,
  front: l,
  back: d
}) {
  const u = Js(orca.state), f = s ?? t, x = Ut(() => {
    var L;
    return (L = u == null ? void 0 : u.blocks) == null ? void 0 : L[f];
  }, [u == null ? void 0 : u.blocks, f]), [h, y] = Ve(!1), [g, S] = Ve(!1), [m, v] = Ve(!1), [C, M] = Ve(l), [b, P] = Ve(d), [N, T] = Ve(l), [O, H] = Ve(d), [z, D] = Ve(!1), [_, j] = Ve(!1), w = (L) => [{ t: "t", v: L ?? "" }];
  zr(() => {
    y(!1), S(!1), v(!1), T(l), H(d), M(l), P(d);
  }, [t, l, d]), zr(() => {
    T(l), M(l), S(!1);
  }, [l]), zr(() => {
    H(d), P(d), v(!1);
  }, [d]);
  const B = Ke(async (L) => {
    console.log(`[SRS Card Block Renderer] 卡片 #${t} 评分: ${L}`);
    const Y = await oo(t, L, "orca-srs");
    y(!1), rt(
      "orca-srs",
      "success",
      `评分已记录：${L}，下次 ${((xe) => {
        const ge = xe.getMonth() + 1, R = xe.getDate();
        return `${ge}-${R}`;
      })(Y.state.due)}（间隔 ${Y.state.interval} 天）`,
      { title: "SRS 复习" }
    );
  }, [t]), J = Ke(async () => {
    var L;
    if (!z) {
      D(!0);
      try {
        await orca.commands.invokeEditorCommand(
          "core.editor.setBlocksContent",
          null,
          [{ id: f, content: w(C) }],
          !1
        );
        const Y = (L = orca.state.blocks) == null ? void 0 : L[f];
        Y && (Y.text = C, Y._repr && (Y._repr.front = C)), T(C), S(!1), rt("orca-srs", "success", "题目已保存", { title: "SRS 卡片" });
      } catch (Y) {
        console.error("保存题目失败:", Y), orca.notify("error", `保存失败: ${Y}`);
      } finally {
        D(!1);
      }
    }
  }, [f, C, z]), G = Ke(async () => {
    var Y, ee, xe;
    if (_) return;
    const L = (Y = x == null ? void 0 : x.children) == null ? void 0 : Y[0];
    if (L === void 0) {
      orca.notify("warn", "该卡片没有子块，无法保存答案", { title: "SRS 卡片" });
      return;
    }
    j(!0);
    try {
      await orca.commands.invokeEditorCommand(
        "core.editor.setBlocksContent",
        null,
        [{ id: L, content: w(b) }],
        !1
      );
      const ge = (ee = orca.state.blocks) == null ? void 0 : ee[L];
      ge && (ge.text = b);
      const R = (xe = orca.state.blocks) == null ? void 0 : xe[f];
      R && R._repr && (R._repr.back = b), H(b), v(!1), rt("orca-srs", "success", "答案已保存", { title: "SRS 卡片" });
    } catch (ge) {
      console.error("保存答案失败:", ge), orca.notify("error", `保存失败: ${ge}`);
    } finally {
      j(!1);
    }
  }, [x == null ? void 0 : x.children, f, b, _]), pe = Ke((L) => {
    L === "front" ? (M(l), S(!1)) : (P(d), v(!1));
  }, [l, d]), se = Ke((L) => {
    M(L.target.value);
  }, []), k = Ke((L) => {
    P(L.target.value);
  }, []), ue = Ke((L) => {
    L.stopPropagation();
  }, []), Ce = Ke((L) => {
    L.stopPropagation();
  }, []), $e = Ke((L) => {
    L.ctrlKey || L.metaKey || L.stopPropagation();
  }, []), Ae = Ut(
    () => /* @__PURE__ */ o.jsx(
      Xs,
      {
        block: x,
        panelId: e,
        blockLevel: n,
        indentLevel: a,
        renderingMode: c
      }
    ),
    [x, e, n, a, c]
  ), Ee = Ut(() => (x == null ? void 0 : x.children) && x.children.length > 0, [x == null ? void 0 : x.children]), A = Ut(() => /* @__PURE__ */ o.jsxs(
    "div",
    {
      className: "srs-card-block-content",
      style: {
        backgroundColor: "var(--orca-color-bg-1)",
        border: "1px solid var(--orca-color-border-1)",
        borderRadius: "8px",
        padding: "16px",
        marginTop: "4px",
        marginBottom: "4px",
        userSelect: "text",
        WebkitUserSelect: "text"
      },
      children: [
        /* @__PURE__ */ o.jsx("style", { children: `
        .srs-card-block-content .orca-block-folding-handle,
        .srs-card-block-content .orca-block-handle {
          opacity: 0 !important;
          transition: opacity 0.15s ease;
        }
        .srs-card-block-content .orca-block.orca-container:hover > .orca-repr > .orca-repr-main > .orca-repr-main-none-editable > .orca-block-handle,
        .srs-card-block-content .orca-block.orca-container:hover > .orca-block-folding-handle {
          opacity: 1 !important;
        }
        .srs-card-front .orca-repr-main {
          display: block !important;
        }
      ` }),
        /* @__PURE__ */ o.jsxs(
          "div",
          {
            style: {
              display: "flex",
              alignItems: "center",
              gap: "8px",
              marginBottom: "12px",
              color: "var(--orca-color-text-2)",
              fontSize: "12px",
              fontWeight: "500"
            },
            children: [
              /* @__PURE__ */ o.jsx("i", { className: "ti ti-cards", style: { fontSize: "16px" } }),
              /* @__PURE__ */ o.jsx("span", { children: "SRS 记忆卡片" })
            ]
          }
        ),
        /* @__PURE__ */ o.jsxs(
          "div",
          {
            className: "srs-card-front",
            style: {
              marginBottom: "12px",
              padding: "12px",
              backgroundColor: "var(--orca-color-bg-2)",
              borderRadius: "6px",
              color: "var(--orca-color-text-1)",
              display: "flex",
              flexDirection: "column",
              gap: "8px"
            },
            children: [
              /* @__PURE__ */ o.jsx(Zs, { blockId: f }),
              /* @__PURE__ */ o.jsxs(
                "div",
                {
                  style: {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    fontSize: "11px",
                    color: "var(--orca-color-text-2)"
                  },
                  children: [
                    /* @__PURE__ */ o.jsx("span", { children: "题目：" }),
                    !g && /* @__PURE__ */ o.jsxs(
                      ke,
                      {
                        variant: "soft",
                        onClick: () => S(!0),
                        style: { padding: "2px 8px", fontSize: "11px" },
                        children: [
                          /* @__PURE__ */ o.jsx("i", { className: "ti ti-edit" }),
                          " 编辑"
                        ]
                      }
                    )
                  ]
                }
              ),
              g ? /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
                /* @__PURE__ */ o.jsx(
                  "textarea",
                  {
                    value: C,
                    onChange: se,
                    onInput: se,
                    onMouseDown: ue,
                    onClick: Ce,
                    onKeyDown: $e,
                    autoFocus: !0,
                    readOnly: !1,
                    disabled: !1,
                    style: {
                      width: "100%",
                      minHeight: "80px",
                      padding: "8px",
                      fontSize: "14px",
                      borderRadius: "4px",
                      border: "1px solid var(--orca-color-border-1)",
                      resize: "vertical",
                      pointerEvents: "auto",
                      userSelect: "text",
                      WebkitUserSelect: "text"
                    }
                  }
                ),
                /* @__PURE__ */ o.jsxs(
                  "div",
                  {
                    style: {
                      display: "flex",
                      gap: "8px",
                      justifyContent: "flex-end"
                    },
                    children: [
                      /* @__PURE__ */ o.jsx(ke, { variant: "soft", onClick: () => pe("front"), children: "取消" }),
                      /* @__PURE__ */ o.jsx(ke, { variant: "solid", onClick: J, children: "保存" })
                    ]
                  }
                )
              ] }) : /* @__PURE__ */ o.jsx(
                "div",
                {
                  style: {
                    whiteSpace: "pre-wrap",
                    userSelect: "text",
                    WebkitUserSelect: "text",
                    cursor: "text",
                    fontSize: "20px",
                    fontWeight: "600"
                  },
                  children: N || "（无题目）"
                }
              )
            ]
          }
        ),
        Ee ? (
          // 有子块：显示答案逻辑
          h ? (
            // 已显示答案：显示答案和评分按钮
            /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
              /* @__PURE__ */ o.jsxs(
                "div",
                {
                  className: "srs-card-back",
                  style: {
                    marginBottom: "12px",
                    padding: "12px",
                    backgroundColor: "var(--orca-color-bg-2)",
                    borderRadius: "6px",
                    color: "var(--orca-color-text-1)",
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px"
                  },
                  children: [
                    /* @__PURE__ */ o.jsxs(
                      "div",
                      {
                        style: {
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          fontSize: "11px",
                          color: "var(--orca-color-text-2)"
                        },
                        children: [
                          /* @__PURE__ */ o.jsx("span", { children: "答案：" }),
                          !m && /* @__PURE__ */ o.jsxs(
                            ke,
                            {
                              variant: "soft",
                              onClick: () => v(!0),
                              style: { padding: "2px 8px", fontSize: "11px" },
                              children: [
                                /* @__PURE__ */ o.jsx("i", { className: "ti ti-edit" }),
                                " 编辑"
                              ]
                            }
                          )
                        ]
                      }
                    ),
                    m ? /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
                      /* @__PURE__ */ o.jsx(
                        "textarea",
                        {
                          value: b,
                          onChange: k,
                          onInput: k,
                          onMouseDown: ue,
                          onClick: Ce,
                          onKeyDown: $e,
                          autoFocus: !0,
                          readOnly: !1,
                          disabled: !1,
                          style: {
                            width: "100%",
                            minHeight: "80px",
                            padding: "8px",
                            fontSize: "14px",
                            borderRadius: "4px",
                            border: "1px solid var(--orca-color-border-1)",
                            resize: "vertical",
                            pointerEvents: "auto",
                            userSelect: "text",
                            WebkitUserSelect: "text"
                          }
                        }
                      ),
                      /* @__PURE__ */ o.jsxs(
                        "div",
                        {
                          style: {
                            display: "flex",
                            gap: "8px",
                            justifyContent: "flex-end"
                          },
                          children: [
                            /* @__PURE__ */ o.jsx(ke, { variant: "soft", onClick: () => pe("back"), children: "取消" }),
                            /* @__PURE__ */ o.jsx(ke, { variant: "solid", onClick: G, children: "保存" })
                          ]
                        }
                      )
                    ] }) : /* @__PURE__ */ o.jsx(
                      "div",
                      {
                        style: {
                          whiteSpace: "pre-wrap",
                          userSelect: "text",
                          WebkitUserSelect: "text",
                          cursor: "text",
                          fontSize: "20px",
                          fontWeight: "600"
                        },
                        children: O || "（无答案）"
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ o.jsxs(
                "div",
                {
                  className: "srs-card-grade-buttons",
                  style: {
                    display: "grid",
                    gridTemplateColumns: "repeat(4, 1fr)",
                    gap: "8px"
                  },
                  children: [
                    /* @__PURE__ */ o.jsxs(
                      ke,
                      {
                        variant: "dangerous",
                        onClick: () => B("again"),
                        style: {
                          padding: "12px 4px",
                          fontSize: "12px",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          gap: "4px"
                        },
                        children: [
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", fontWeight: "500" }, children: "1m" }),
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px" }, children: "😞" }),
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.9 }, children: "忘记" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ o.jsxs(
                      ke,
                      {
                        variant: "soft",
                        onClick: () => B("hard"),
                        style: {
                          padding: "12px 4px",
                          fontSize: "12px",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          gap: "4px"
                        },
                        children: [
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", fontWeight: "500" }, children: "6m" }),
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px" }, children: "😐" }),
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.9 }, children: "困难" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ o.jsxs(
                      ke,
                      {
                        variant: "solid",
                        onClick: () => B("good"),
                        style: {
                          padding: "12px 4px",
                          fontSize: "12px",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          gap: "4px"
                        },
                        children: [
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", fontWeight: "500" }, children: "10m" }),
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px" }, children: "😊" }),
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.9 }, children: "良好" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ o.jsxs(
                      ke,
                      {
                        variant: "solid",
                        onClick: () => B("easy"),
                        style: {
                          padding: "12px 4px",
                          fontSize: "12px",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          gap: "4px",
                          backgroundColor: "var(--orca-color-primary-5)",
                          opacity: 0.9
                        },
                        children: [
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", fontWeight: "500" }, children: "8d" }),
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px" }, children: "😄" }),
                          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.9 }, children: "简单" })
                        ]
                      }
                    )
                  ]
                }
              )
            ] })
          ) : (
            // 未显示答案：显示按钮
            /* @__PURE__ */ o.jsx("div", { style: { textAlign: "center" }, children: /* @__PURE__ */ o.jsx(
              ke,
              {
                variant: "soft",
                onClick: () => y(!0),
                style: {
                  padding: "6px 16px",
                  fontSize: "13px"
                },
                children: "显示答案"
              }
            ) })
          )
        ) : (
          // 无子块（摘录卡）：直接显示评分按钮
          /* @__PURE__ */ o.jsxs(
            "div",
            {
              className: "srs-card-grade-buttons",
              style: {
                display: "grid",
                gridTemplateColumns: "repeat(4, 1fr)",
                gap: "8px"
              },
              children: [
                /* @__PURE__ */ o.jsxs(
                  ke,
                  {
                    variant: "dangerous",
                    onClick: () => B("again"),
                    style: {
                      padding: "12px 4px",
                      fontSize: "12px",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "4px"
                    },
                    children: [
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", fontWeight: "500" }, children: "1m" }),
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px" }, children: "😞" }),
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.9 }, children: "忘记" })
                    ]
                  }
                ),
                /* @__PURE__ */ o.jsxs(
                  ke,
                  {
                    variant: "soft",
                    onClick: () => B("hard"),
                    style: {
                      padding: "12px 4px",
                      fontSize: "12px",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "4px"
                    },
                    children: [
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", fontWeight: "500" }, children: "6m" }),
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px" }, children: "😐" }),
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.9 }, children: "困难" })
                    ]
                  }
                ),
                /* @__PURE__ */ o.jsxs(
                  ke,
                  {
                    variant: "solid",
                    onClick: () => B("good"),
                    style: {
                      padding: "12px 4px",
                      fontSize: "12px",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "4px"
                    },
                    children: [
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", fontWeight: "500" }, children: "10m" }),
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px" }, children: "😊" }),
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.9 }, children: "良好" })
                    ]
                  }
                ),
                /* @__PURE__ */ o.jsxs(
                  ke,
                  {
                    variant: "solid",
                    onClick: () => B("easy"),
                    style: {
                      padding: "12px 4px",
                      fontSize: "12px",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "4px",
                      backgroundColor: "var(--orca-color-primary-5)",
                      opacity: 0.9
                    },
                    children: [
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", fontWeight: "500" }, children: "8d" }),
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px" }, children: "😄" }),
                      /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.9 }, children: "简单" })
                    ]
                  }
                )
              ]
            }
          )
        )
      ]
    }
  ), [
    Ee,
    h,
    g,
    m,
    C,
    b,
    N,
    O,
    z,
    _,
    B,
    J,
    G,
    pe,
    se,
    k,
    ue,
    Ce,
    $e
  ]);
  return /* @__PURE__ */ o.jsx(
    Qs,
    {
      panelId: e,
      blockId: t,
      rndId: r,
      mirrorId: s,
      blockLevel: n,
      indentLevel: a,
      initiallyCollapsed: i,
      renderingMode: c,
      reprClassName: "srs-repr-card",
      contentClassName: "srs-repr-card-content",
      contentAttrs: { contentEditable: !1 },
      contentJsx: /* @__PURE__ */ o.jsx(ot, { componentName: "SRS卡片", errorTitle: "卡片加载出错", children: A }),
      childrenJsx: Ae
    }
  );
}
const Pe = {
  CARD_GRADED: "srs.cardGraded",
  // 卡片被评分
  CARD_POSTPONED: "srs.cardPostponed",
  // 卡片被推迟
  CARD_SUSPENDED: "srs.cardSuspended"
  // 卡片被暂停
};
function ei(e, t) {
  orca.broadcasts.broadcast(Pe.CARD_GRADED, { blockId: e, grade: t });
}
function ti(e) {
  orca.broadcasts.broadcast(Pe.CARD_POSTPONED, { blockId: e });
}
function ri(e) {
  orca.broadcasts.broadcast(Pe.CARD_SUSPENDED, { blockId: e });
}
const oi = 1, ni = "reviewLogs", Dt = /* @__PURE__ */ new Map();
let er = [], nt = null;
const ai = 1e3;
function On(e, t) {
  const r = t.toString().padStart(2, "0");
  return `${ni}_${e}_${r}`;
}
function si(e) {
  const t = new Date(e);
  return On(t.getFullYear(), t.getMonth() + 1);
}
async function Hn(e, t) {
  if (Dt.has(t))
    return Dt.get(t);
  try {
    const r = await orca.plugins.getData(e, t);
    if (!r)
      return Dt.set(t, []), [];
    const a = JSON.parse(r).logs || [];
    return Dt.set(t, a), a;
  } catch (r) {
    return console.warn(`[${e}] 加载复习记录失败 (${t}):`, r), [];
  }
}
async function ii(e, t, r) {
  const n = {
    version: oi,
    logs: r
  };
  await orca.plugins.setData(e, t, JSON.stringify(n)), Dt.set(t, r);
}
async function In(e) {
  if (er.length === 0) return;
  const t = /* @__PURE__ */ new Map();
  for (const r of er) {
    const n = si(r.timestamp);
    t.has(n) || t.set(n, []), t.get(n).push(r);
  }
  er = [];
  for (const [r, n] of t) {
    const s = [...await Hn(e, r), ...n];
    await ii(e, r, s);
  }
}
function li(e) {
  nt && clearTimeout(nt), nt = setTimeout(async () => {
    nt = null, await In(e);
  }, ai);
}
async function ci(e, t) {
  er.push(t), li(e);
}
async function di(e) {
  nt && (clearTimeout(nt), nt = null), await In(e);
}
async function Lt(e, t, r) {
  await di(e);
  const n = t.getTime(), a = r.getTime(), s = t.getFullYear(), i = t.getMonth() + 1, c = r.getFullYear(), l = r.getMonth() + 1, d = [];
  let u = s, f = i;
  for (; u < c || u === c && f <= l; ) {
    const x = On(u, f), y = (await Hn(e, x)).filter(
      (g) => g.timestamp >= n && g.timestamp <= a
    );
    d.push(...y), f++, f > 12 && (f = 1, u++);
  }
  return d.sort((x, h) => x.timestamp - h.timestamp);
}
function ui(e, t) {
  return `${e}_${t}`;
}
const fo = "srs-plugin";
function or(e) {
  var r, n, a;
  if (!e) return !1;
  const t = (r = e.properties) == null ? void 0 : r.find((s) => s.name === "_repr");
  return ((n = t == null ? void 0 : t.value) == null ? void 0 : n.type) === "query" || ((a = e._repr) == null ? void 0 : a.type) === "query";
}
async function po(e) {
  var a;
  const t = await orca.invokeBackend("get-block", e);
  if (!t)
    return console.log(`[blockCardCollector] 无法获取块 ${e}`), [];
  const r = (a = t.properties) == null ? void 0 : a.find((s) => s.name === "_repr"), n = r == null ? void 0 : r.value;
  if (!n || n.type !== "query")
    return console.log(`[blockCardCollector] 块 ${e} 不是查询块或没有 _repr`), [];
  if (!n.q)
    return console.log(`[blockCardCollector] 查询块 ${e} 没有查询语句 (repr.q)`), [];
  console.log(`[blockCardCollector] 查询块 ${e} 的查询语句:`, JSON.stringify(n.q));
  try {
    const s = await orca.invokeBackend("query", n.q);
    return !s || s.length === 0 ? (console.log(`[blockCardCollector] 查询块 ${e} 查询结果为空`), []) : (console.log(`[blockCardCollector] 查询块 ${e} 获取到 ${s.length} 个结果`), s);
  } catch (s) {
    return console.error("[blockCardCollector] 执行查询失败:", s), [];
  }
}
async function xo(e) {
  const t = [], r = /* @__PURE__ */ new Set();
  async function n(a) {
    var i;
    if (r.has(a)) return;
    r.add(a);
    let s = (i = orca.state.blocks) == null ? void 0 : i[a];
    if (s || (s = await orca.invokeBackend("get-block", a)), !(!(s != null && s.children) || s.children.length === 0))
      for (const c of s.children)
        t.push(c), await n(c);
  }
  return await n(e), t;
}
function qe(e) {
  return !(e != null && e.refs) || e.refs.length === 0 ? !1 : e.refs.some((t) => t.type === 2 && Me(t.alias));
}
function jt(e) {
  const t = e.refs || [];
  if (t.length === 0) return [];
  const r = [], n = /* @__PURE__ */ new Set();
  for (const a of t) {
    if (a.type !== 2) continue;
    const s = (a.alias || "").trim();
    if (!s) continue;
    const i = s.toLowerCase();
    i === "card" || i.startsWith("card/") || n.has(a.to) || (n.add(a.to), r.push({
      name: s,
      blockId: a.to
    }));
  }
  return r;
}
async function zt(e, t = fo) {
  const r = [];
  if (!Qr(e) && !qe(e))
    return r;
  if (En(e) === "suspend")
    return console.log(`[${t}] convertBlockToReviewCards: 跳过已暂停的卡片 #${e.id}`), r;
  const a = gt(e), s = await Bt(e);
  if (a === "cloze") {
    const i = lo(e.content, t);
    if (i.length === 0)
      return r;
    for (const c of i) {
      const l = await ao(e.id, c, c - 1), d = e.text || "";
      r.push({
        id: e.id,
        front: d,
        back: `（填空 c${c}）`,
        srs: l,
        isNew: !l.lastReviewed || l.reps === 0,
        deck: s,
        tags: jt(e),
        clozeNumber: c,
        content: e.content
      });
    }
  } else if (a === "direction") {
    const i = co(e.content, t);
    if (!i || !i.leftText || !i.rightText)
      return r;
    const c = An(i.direction);
    for (let l = 0; l < c.length; l++) {
      const d = c[l], u = await so(e.id, d, l), f = d === "forward" ? i.leftText : i.rightText, x = d === "forward" ? i.rightText : i.leftText;
      r.push({
        id: e.id,
        front: f,
        back: x,
        srs: u,
        isNew: !u.lastReviewed || u.reps === 0,
        deck: s,
        tags: jt(e),
        directionType: d
      });
    }
  } else if (a === "excerpt") {
    const i = e.text || "", c = await Ue(e.id, /* @__PURE__ */ new Date());
    r.push({
      id: e.id,
      front: i,
      back: "",
      srs: c,
      isNew: !c.lastReviewed || c.reps === 0,
      deck: s,
      tags: jt(e)
    });
  } else if (e.children && e.children.length > 0) {
    const { front: c, back: l } = cr(e), d = await Ue(e.id, /* @__PURE__ */ new Date());
    r.push({
      id: e.id,
      front: c,
      back: l,
      srs: d,
      isNew: !d.lastReviewed || d.reps === 0,
      deck: s,
      tags: jt(e)
    });
  } else {
    const c = e.text || "", l = await Ue(e.id, /* @__PURE__ */ new Date());
    r.push({
      id: e.id,
      front: c,
      // 摘录内容作为 front
      back: "",
      // 无 back
      srs: l,
      isNew: !l.lastReviewed || l.reps === 0,
      deck: s,
      tags: jt(e)
    });
  }
  return r;
}
async function ho(e, t = fo) {
  var a;
  const r = [], n = await po(e);
  if (n.length === 0)
    return r;
  for (const s of n) {
    let i = (a = orca.state.blocks) == null ? void 0 : a[s];
    if (i || (i = await orca.invokeBackend("get-block", s)), !i || !qe(i)) continue;
    const c = await zt(i, t);
    r.push(...c);
  }
  return r;
}
async function go(e, t = fo) {
  var s, i;
  const r = [];
  let n = (s = orca.state.blocks) == null ? void 0 : s[e];
  if (n || (n = await orca.invokeBackend("get-block", e)), n && qe(n)) {
    const c = await zt(n, t);
    r.push(...c);
  }
  const a = await xo(e);
  for (const c of a) {
    let l = (i = orca.state.blocks) == null ? void 0 : i[c];
    if (l || (l = await orca.invokeBackend("get-block", c)), !l || !qe(l)) continue;
    const d = await zt(l, t);
    r.push(...d);
  }
  return r;
}
async function yo(e, t) {
  var n, a, s;
  let r = 0;
  if (t) {
    const i = await po(e);
    for (const c of i) {
      let l = (n = orca.state.blocks) == null ? void 0 : n[c];
      l || (l = await orca.invokeBackend("get-block", c)), l && qe(l) && r++;
    }
  } else {
    let i = (a = orca.state.blocks) == null ? void 0 : a[e];
    i || (i = await orca.invokeBackend("get-block", e)), i && qe(i) && r++;
    const c = await xo(e);
    for (const l of c) {
      let d = (s = orca.state.blocks) == null ? void 0 : s[l];
      d || (d = await orca.invokeBackend("get-block", l)), d && qe(d) && r++;
    }
  }
  return r;
}
const nr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  collectCardsFromChildren: go,
  collectCardsFromQueryBlock: ho,
  convertBlockToReviewCards: zt,
  estimateCardCount: yo,
  getAllDescendantIds: xo,
  getQueryResults: po,
  hasCardTag: qe,
  isQueryBlock: or
}, Symbol.toStringTag, { value: "Module" })), fi = "srs-plugin", Nn = /* @__PURE__ */ new Set();
function Yn(e, t, r) {
  return `${e}-${t || 0}-${r || "basic"}`;
}
function Ur(e, t, r) {
  const n = Yn(e, t, r);
  Nn.add(n), console.log(`[orca-srs] 标记父卡片已处理: ${n}`);
}
function qr() {
  Nn.clear(), console.log("[orca-srs] 重置已处理父卡片集合");
}
async function Un(e, t = fi) {
  var i, c;
  const r = [];
  let n = (i = orca.state.blocks) == null ? void 0 : i[e];
  if (n || (n = await orca.invokeBackend("get-block", e)), !n)
    return r;
  const a = n.backRefs;
  if (!a || a.length === 0)
    return r;
  const s = /* @__PURE__ */ new Set();
  for (const l of a) {
    const d = l.from;
    if (s.has(d))
      continue;
    s.add(d);
    let u = (c = orca.state.blocks) == null ? void 0 : c[d];
    if (u || (u = await orca.invokeBackend("get-block", d)), !u || !qe(u) && !Qr(u))
      continue;
    const f = await zt(u, t);
    r.push(...f);
  }
  return r.length > 0 && console.log(`[${t}] collectChildCards: 父卡片 #${e} 有 ${r.length} 张直接子卡片`), r;
}
async function qn(e) {
  var r, n;
  let t = (r = orca.state.blocks) == null ? void 0 : r[e];
  if (t || (t = await orca.invokeBackend("get-block", e)), !(t != null && t.backRefs) || t.backRefs.length === 0)
    return !1;
  for (const a of t.backRefs) {
    let s = (n = orca.state.blocks) == null ? void 0 : n[a.from];
    if (s || (s = await orca.invokeBackend("get-block", a.from)), s && qe(s))
      return !0;
  }
  return !1;
}
function Vn(e) {
  return `${e.id}-${e.clozeNumber || 0}-${e.directionType || "basic"}`;
}
const pi = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  collectChildCards: Un,
  getCardKey: Vn,
  getParentCardKey: Yn,
  hasChildCards: qn,
  markParentCardProcessed: Ur,
  resetProcessedParentCards: qr
}, Symbol.toStringTag, { value: "Module" })), { useEffect: xi, useCallback: hi } = window.React, gi = {
  " ": "showAnswer",
  // 空格显示答案
  1: "again",
  // 忘记
  2: "hard",
  // 困难
  3: "good",
  // 良好
  4: "easy",
  // 简单
  b: "bury",
  // 推迟到明天（内部仍使用bury以保持兼容）
  s: "suspend"
  // 暂停卡片
};
function mo({
  showAnswer: e,
  isGrading: t,
  onShowAnswer: r,
  onGrade: n,
  onBury: a,
  onSuspend: s,
  enabled: i = !0
}) {
  const c = hi(
    (l) => {
      if (!i) return;
      const d = l.target;
      if (d.tagName === "INPUT" || d.tagName === "TEXTAREA" || d.isContentEditable)
        return;
      const u = gi[l.key];
      u && (l.preventDefault(), l.stopPropagation(), u === "showAnswer" ? !e && !t ? r() : e && !t && n("good") : u === "bury" ? !t && a && a() : u === "suspend" ? !t && s && s() : e && !t && n(u));
    },
    [e, t, r, n, a, s, i]
  );
  xi(() => {
    if (i)
      return document.addEventListener("keydown", c), () => {
        document.removeEventListener("keydown", c);
      };
  }, [c, i]);
}
const { useState: Uo, useMemo: dt } = window.React, { useSnapshot: yi } = window.Valtio, { Button: Le, ModalOverlay: mi } = orca.components;
function vi(e) {
  if (e == null) return "新卡";
  switch (e) {
    case I.New:
      return "新卡";
    case I.Learning:
      return "学习中";
    case I.Review:
      return "复习中";
    case I.Relearning:
      return "重学中";
    default:
      return "未知";
  }
}
function qo(e) {
  if (!e) return "从未";
  const t = new Date(e), r = t.getFullYear(), n = String(t.getMonth() + 1).padStart(2, "0"), a = String(t.getDate()).padStart(2, "0"), s = String(t.getHours()).padStart(2, "0"), i = String(t.getMinutes()).padStart(2, "0");
  return `${r}-${n}-${a} ${s}:${i}`;
}
function Vo(e, t, r, n) {
  return !e || e.length === 0 ? [/* @__PURE__ */ o.jsx("span", { children: "（空白内容）" }, "empty")] : e.map((a, s) => {
    if (a.t === "t")
      return /* @__PURE__ */ o.jsx("span", { children: a.v }, s);
    if (a.t === `${r}.cloze`) {
      const i = a.clozeNumber;
      return t || !(n ? i === n : !0) ? /* @__PURE__ */ o.jsx(
        "span",
        {
          style: {
            backgroundColor: "var(--orca-color-primary-1)",
            color: "var(--orca-color-primary-5)",
            fontWeight: "600",
            padding: "2px 6px",
            borderRadius: "4px",
            borderBottom: "2px solid var(--orca-color-primary-5)"
          },
          children: a.v
        },
        s
      ) : /* @__PURE__ */ o.jsx(
        "span",
        {
          style: {
            color: "var(--orca-color-text-2)",
            fontWeight: "500",
            padding: "2px 6px",
            backgroundColor: "var(--orca-color-bg-2)",
            borderRadius: "4px",
            border: "1px dashed var(--orca-color-border-1)"
          },
          children: "[...]"
        },
        s
      );
    }
    return /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-2)" }, children: a.v }, s);
  });
}
function bi({
  blockId: e,
  onGrade: t,
  onPostpone: r,
  onSuspend: n,
  onClose: a,
  onSkip: s,
  onPrevious: i,
  canGoPrevious: c = !1,
  srsInfo: l,
  isGrading: d = !1,
  onJumpToCard: u,
  inSidePanel: f = !1,
  panelId: x,
  pluginName: h,
  clozeNumber: y
}) {
  const [g, S] = Uo(!1), [m, v] = Uo(!1), C = yi(orca.state), M = dt(() => ((C == null ? void 0 : C.blocks) ?? {})[e], [C == null ? void 0 : C.blocks, e]), b = async (D) => {
    d || (await t(D), S(!1));
  };
  mo({
    showAnswer: g,
    isGrading: d,
    onShowAnswer: () => S(!0),
    onGrade: b,
    onBury: r,
    onSuspend: n
  });
  const P = dt(() => {
    const D = l ? {
      stability: l.stability ?? 0,
      difficulty: l.difficulty ?? 0,
      interval: l.interval ?? 0,
      due: l.due ?? /* @__PURE__ */ new Date(),
      lastReviewed: l.lastReviewed ?? null,
      reps: l.reps ?? 0,
      lapses: l.lapses ?? 0,
      state: l.state
    } : null;
    return Zr(D);
  }, [l]), N = dt(() => {
    const D = l ? {
      stability: l.stability ?? 0,
      difficulty: l.difficulty ?? 0,
      interval: l.interval ?? 0,
      due: l.due ?? /* @__PURE__ */ new Date(),
      lastReviewed: l.lastReviewed ?? null,
      reps: l.reps ?? 0,
      lapses: l.lapses ?? 0,
      state: l.state
    } : null;
    return eo(D);
  }, [l]), T = dt(() => (M == null ? void 0 : M.content) ?? [], [M == null ? void 0 : M.content]), O = dt(() => Vo(T, !1, h, y), [T, h, y]), H = dt(() => Vo(T, !0, h, y), [T, h, y]), z = /* @__PURE__ */ o.jsxs("div", { className: "srs-cloze-card-container", style: {
    backgroundColor: "var(--orca-color-bg-1)",
    borderRadius: "12px",
    padding: "16px",
    width: f ? "100%" : "90%",
    minWidth: f ? "0" : "600px",
    boxShadow: "0 4px 20px rgba(0,0,0,0.15)"
  }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: "8px",
      opacity: 0.6,
      transition: "opacity 0.2s"
    }, onMouseEnter: (D) => D.currentTarget.style.opacity = "1", onMouseLeave: (D) => D.currentTarget.style.opacity = "0.6", children: [
      /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", alignItems: "center", gap: "4px" }, children: [
        i && /* @__PURE__ */ o.jsx(
          Le,
          {
            variant: "plain",
            onClick: c ? i : void 0,
            title: "回到上一张",
            style: {
              padding: "4px 6px",
              fontSize: "14px",
              opacity: c ? 1 : 0.3,
              cursor: c ? "pointer" : "not-allowed"
            },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-arrow-left" })
          }
        ),
        /* @__PURE__ */ o.jsxs("div", { style: {
          fontSize: "12px",
          fontWeight: "500",
          color: "var(--orca-color-primary-5)",
          backgroundColor: "var(--orca-color-primary-1)",
          padding: "2px 8px",
          borderRadius: "4px",
          display: "inline-flex",
          alignItems: "center",
          gap: "4px"
        }, children: [
          /* @__PURE__ */ o.jsx("i", { className: "ti ti-braces", style: { fontSize: "11px" } }),
          "c",
          y || "?"
        ] })
      ] }),
      /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "2px" }, children: [
        r && /* @__PURE__ */ o.jsx(
          Le,
          {
            variant: "plain",
            onClick: r,
            title: "推迟到明天 (B)",
            style: { padding: "4px 6px", fontSize: "14px" },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-calendar-pause" })
          }
        ),
        n && /* @__PURE__ */ o.jsx(
          Le,
          {
            variant: "plain",
            onClick: n,
            title: "暂停卡片 (S)",
            style: { padding: "4px 6px", fontSize: "14px" },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-player-pause" })
          }
        ),
        e && u && /* @__PURE__ */ o.jsx(
          Le,
          {
            variant: "plain",
            onClick: (D) => u(e, D.shiftKey),
            title: "跳转到卡片 (Shift+点击在侧面板打开)",
            style: { padding: "4px 6px", fontSize: "14px" },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-external-link" })
          }
        ),
        /* @__PURE__ */ o.jsx(
          Le,
          {
            variant: "plain",
            onClick: () => v(!m),
            title: "卡片信息",
            style: {
              padding: "4px 6px",
              fontSize: "14px",
              color: m ? "var(--orca-color-primary-5)" : void 0
            },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-info-circle" })
          }
        )
      ] })
    ] }),
    m && /* @__PURE__ */ o.jsx(
      "div",
      {
        contentEditable: !1,
        style: {
          marginBottom: "12px",
          padding: "12px 16px",
          backgroundColor: "var(--orca-color-bg-2)",
          borderRadius: "8px",
          fontSize: "13px",
          color: "var(--orca-color-text-2)"
        },
        children: /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "8px" }, children: [
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "遗忘次数" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: (l == null ? void 0 : l.lapses) ?? 0 })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "复习次数" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: (l == null ? void 0 : l.reps) ?? 0 })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "卡片状态" }),
            /* @__PURE__ */ o.jsx("span", { style: {
              color: (l == null ? void 0 : l.state) === I.Review ? "var(--orca-color-success)" : (l == null ? void 0 : l.state) === I.Learning || (l == null ? void 0 : l.state) === I.Relearning ? "var(--orca-color-warning)" : "var(--orca-color-primary)"
            }, children: vi(l == null ? void 0 : l.state) })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "最后复习" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: qo(l == null ? void 0 : l.lastReviewed) })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "下次到期" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: qo(l == null ? void 0 : l.due) })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "间隔天数" }),
            /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-text-1)" }, children: [
              (l == null ? void 0 : l.interval) ?? 0,
              " 天"
            ] })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "稳定性" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: ((l == null ? void 0 : l.stability) ?? 0).toFixed(2) })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "难度" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: ((l == null ? void 0 : l.difficulty) ?? 0).toFixed(2) })
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ o.jsx("div", { className: "srs-cloze-question", style: {
      marginBottom: "16px",
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      minHeight: "100px",
      fontSize: "16px",
      lineHeight: "1.8",
      color: "var(--orca-color-text-1)"
    }, children: g ? H : O }),
    g ? /* @__PURE__ */ o.jsx(o.Fragment, { children: /* @__PURE__ */ o.jsxs("div", { className: "srs-card-grade-buttons", style: {
      display: "grid",
      gridTemplateColumns: s ? "repeat(5, 1fr)" : "repeat(4, 1fr)",
      gap: "8px",
      marginTop: "16px"
    }, children: [
      s && /* @__PURE__ */ o.jsxs(
        Le,
        {
          variant: "soft",
          onClick: s,
          style: {
            padding: "12px 8px",
            fontSize: "14px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "4px"
          },
          children: [
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.7 }, children: "不评分" }),
            /* @__PURE__ */ o.jsx("span", { style: { fontWeight: 600 }, children: "⏭️" }),
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.8 }, children: "跳过" })
          ]
        }
      ),
      /* @__PURE__ */ o.jsxs(
        Le,
        {
          variant: "dangerous",
          onClick: () => b("again"),
          style: {
            padding: "12px 8px",
            fontSize: "14px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "4px"
          },
          children: [
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.7 }, children: Se(N.again) }),
            /* @__PURE__ */ o.jsx("span", { style: { fontWeight: 600 }, children: Yt(P.again) }),
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.8 }, children: "忘记" })
          ]
        }
      ),
      /* @__PURE__ */ o.jsxs(
        Le,
        {
          variant: "soft",
          onClick: () => b("hard"),
          style: {
            padding: "12px 8px",
            fontSize: "14px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "4px"
          },
          children: [
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.7 }, children: Se(N.hard) }),
            /* @__PURE__ */ o.jsx("span", { style: { fontWeight: 600 }, children: Yt(P.hard) }),
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.8 }, children: "困难" })
          ]
        }
      ),
      /* @__PURE__ */ o.jsxs(
        Le,
        {
          variant: "solid",
          onClick: () => b("good"),
          style: {
            padding: "12px 8px",
            fontSize: "14px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "4px"
          },
          children: [
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.7 }, children: Se(N.good) }),
            /* @__PURE__ */ o.jsx("span", { style: { fontWeight: 600 }, children: Yt(P.good) }),
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.8 }, children: "良好" })
          ]
        }
      ),
      /* @__PURE__ */ o.jsxs(
        Le,
        {
          variant: "solid",
          onClick: () => b("easy"),
          style: {
            padding: "12px 8px",
            fontSize: "14px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "4px",
            backgroundColor: "var(--orca-color-primary-5)",
            opacity: 0.9
          },
          children: [
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", opacity: 0.7 }, children: Se(N.easy) }),
            /* @__PURE__ */ o.jsx("span", { style: { fontWeight: 600 }, children: Yt(P.easy) }),
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.8 }, children: "简单" })
          ]
        }
      )
    ] }) }) : /* @__PURE__ */ o.jsx("div", { style: { textAlign: "center", marginBottom: "12px" }, children: /* @__PURE__ */ o.jsx(
      Le,
      {
        variant: "solid",
        onClick: () => S(!0),
        style: {
          padding: "12px 32px",
          fontSize: "16px"
        },
        children: "显示答案"
      }
    ) })
  ] });
  return f ? /* @__PURE__ */ o.jsx("div", { style: { width: "100%", display: "flex", justifyContent: "center" }, children: z }) : /* @__PURE__ */ o.jsx(
    mi,
    {
      visible: !0,
      canClose: !0,
      onClose: a,
      className: "srs-cloze-card-modal",
      children: z
    }
  );
}
const { useState: Ko, useMemo: qt } = window.React, { useSnapshot: wi } = window.Valtio, { Button: ut } = orca.components;
function Si(e) {
  if (e == null) return "新卡";
  switch (e) {
    case I.New:
      return "新卡";
    case I.Learning:
      return "学习中";
    case I.Review:
      return "复习中";
    case I.Relearning:
      return "重学中";
    default:
      return "未知";
  }
}
function Go(e) {
  if (!e) return "从未";
  const t = new Date(e), r = t.getFullYear(), n = String(t.getMonth() + 1).padStart(2, "0"), a = String(t.getDate()).padStart(2, "0"), s = String(t.getHours()).padStart(2, "0"), i = String(t.getMinutes()).padStart(2, "0");
  return `${r}-${n}-${a} ${s}:${i}`;
}
function Ci({
  blockId: e,
  onGrade: t,
  onPostpone: r,
  onSuspend: n,
  onClose: a,
  onSkip: s,
  onPrevious: i,
  canGoPrevious: c = !1,
  srsInfo: l,
  isGrading: d = !1,
  onJumpToCard: u,
  inSidePanel: f = !1,
  panelId: x,
  pluginName: h,
  reviewDirection: y
}) {
  const [g, S] = Ko(!1), [m, v] = Ko(!1), C = wi(orca.state), M = qt(() => {
    var j;
    return (j = C == null ? void 0 : C.blocks) == null ? void 0 : j[e];
  }, [C == null ? void 0 : C.blocks, e]), b = qt(() => co(M == null ? void 0 : M.content, h), [M == null ? void 0 : M.content, h]), P = async (j) => {
    d || (await t(j), S(!1));
  };
  mo({
    showAnswer: g,
    isGrading: d,
    onShowAnswer: () => S(!0),
    onGrade: P,
    onBury: r,
    onSuspend: n
  }), qt(() => {
    const j = l ? {
      stability: l.stability ?? 0,
      difficulty: l.difficulty ?? 0,
      interval: l.interval ?? 0,
      due: l.due ?? /* @__PURE__ */ new Date(),
      lastReviewed: l.lastReviewed ?? null,
      reps: l.reps ?? 0,
      lapses: l.lapses ?? 0,
      state: l.state
    } : null;
    return Zr(j);
  }, [l]);
  const N = qt(() => {
    const j = l ? {
      stability: l.stability ?? 0,
      difficulty: l.difficulty ?? 0,
      interval: l.interval ?? 0,
      due: l.due ?? /* @__PURE__ */ new Date(),
      lastReviewed: l.lastReviewed ?? null,
      reps: l.reps ?? 0,
      lapses: l.lapses ?? 0,
      state: l.state
    } : null;
    return eo(j);
  }, [l]);
  if (!b)
    return /* @__PURE__ */ o.jsx("div", { style: { padding: "20px", textAlign: "center" }, children: "无法解析方向卡内容" });
  const T = y === "forward" ? b.leftText : b.rightText, O = y === "forward" ? b.rightText : b.leftText, H = y === "forward" ? "ti-arrow-right" : "ti-arrow-left", z = y === "forward" ? "正向" : "反向", D = y === "forward" ? "var(--orca-color-primary-5)" : "var(--orca-color-warning-5)", _ = y === "forward" ? "var(--orca-color-primary-1)" : "var(--orca-color-warning-1)";
  return /* @__PURE__ */ o.jsxs(
    "div",
    {
      className: "srs-direction-card-container",
      style: {
        backgroundColor: "var(--orca-color-bg-1)",
        borderRadius: "12px",
        padding: "16px",
        width: f ? "100%" : "90%",
        minWidth: f ? "0" : "600px",
        boxShadow: "0 4px 20px rgba(0,0,0,0.15)"
      },
      children: [
        /* @__PURE__ */ o.jsxs(
          "div",
          {
            style: {
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "8px",
              opacity: 0.6,
              transition: "opacity 0.2s"
            },
            onMouseEnter: (j) => j.currentTarget.style.opacity = "1",
            onMouseLeave: (j) => j.currentTarget.style.opacity = "0.6",
            children: [
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", alignItems: "center", gap: "4px" }, children: [
                i && /* @__PURE__ */ o.jsx(
                  ut,
                  {
                    variant: "plain",
                    onClick: c ? i : void 0,
                    title: "回到上一张",
                    style: {
                      padding: "4px 6px",
                      fontSize: "14px",
                      opacity: c ? 1 : 0.3,
                      cursor: c ? "pointer" : "not-allowed"
                    },
                    children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-arrow-left" })
                  }
                ),
                /* @__PURE__ */ o.jsxs(
                  "div",
                  {
                    style: {
                      fontSize: "12px",
                      fontWeight: "500",
                      color: D,
                      backgroundColor: _,
                      padding: "2px 8px",
                      borderRadius: "4px",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "4px"
                    },
                    children: [
                      /* @__PURE__ */ o.jsx("i", { className: `ti ${H}`, style: { fontSize: "11px" } }),
                      z
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "2px" }, children: [
                r && /* @__PURE__ */ o.jsx(
                  ut,
                  {
                    variant: "plain",
                    onClick: r,
                    title: "推迟到明天 (B)",
                    style: { padding: "4px 6px", fontSize: "14px" },
                    children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-calendar-pause" })
                  }
                ),
                n && /* @__PURE__ */ o.jsx(
                  ut,
                  {
                    variant: "plain",
                    onClick: n,
                    title: "暂停卡片 (S)",
                    style: { padding: "4px 6px", fontSize: "14px" },
                    children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-player-pause" })
                  }
                ),
                e && u && /* @__PURE__ */ o.jsx(
                  ut,
                  {
                    variant: "plain",
                    onClick: (j) => u(e, j.shiftKey),
                    title: "跳转到卡片 (Shift+点击在侧面板打开)",
                    style: { padding: "4px 6px", fontSize: "14px" },
                    children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-external-link" })
                  }
                ),
                /* @__PURE__ */ o.jsx(
                  ut,
                  {
                    variant: "plain",
                    onClick: () => v(!m),
                    title: "卡片信息",
                    style: {
                      padding: "4px 6px",
                      fontSize: "14px",
                      color: m ? "var(--orca-color-primary-5)" : void 0
                    },
                    children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-info-circle" })
                  }
                )
              ] })
            ]
          }
        ),
        m && /* @__PURE__ */ o.jsx(
          "div",
          {
            contentEditable: !1,
            style: {
              marginBottom: "12px",
              padding: "12px 16px",
              backgroundColor: "var(--orca-color-bg-2)",
              borderRadius: "8px",
              fontSize: "13px",
              color: "var(--orca-color-text-2)"
            },
            children: /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "8px" }, children: [
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
                /* @__PURE__ */ o.jsx("span", { children: "遗忘次数" }),
                /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: (l == null ? void 0 : l.lapses) ?? 0 })
              ] }),
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
                /* @__PURE__ */ o.jsx("span", { children: "复习次数" }),
                /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: (l == null ? void 0 : l.reps) ?? 0 })
              ] }),
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
                /* @__PURE__ */ o.jsx("span", { children: "卡片状态" }),
                /* @__PURE__ */ o.jsx("span", { style: {
                  color: (l == null ? void 0 : l.state) === I.Review ? "var(--orca-color-success)" : (l == null ? void 0 : l.state) === I.Learning || (l == null ? void 0 : l.state) === I.Relearning ? "var(--orca-color-warning)" : "var(--orca-color-primary)"
                }, children: Si(l == null ? void 0 : l.state) })
              ] }),
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
                /* @__PURE__ */ o.jsx("span", { children: "最后复习" }),
                /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: Go(l == null ? void 0 : l.lastReviewed) })
              ] }),
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
                /* @__PURE__ */ o.jsx("span", { children: "下次到期" }),
                /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: Go(l == null ? void 0 : l.due) })
              ] }),
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
                /* @__PURE__ */ o.jsx("span", { children: "间隔天数" }),
                /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-text-1)" }, children: [
                  (l == null ? void 0 : l.interval) ?? 0,
                  " 天"
                ] })
              ] }),
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
                /* @__PURE__ */ o.jsx("span", { children: "稳定性" }),
                /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: ((l == null ? void 0 : l.stability) ?? 0).toFixed(2) })
              ] }),
              /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
                /* @__PURE__ */ o.jsx("span", { children: "难度" }),
                /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: ((l == null ? void 0 : l.difficulty) ?? 0).toFixed(2) })
              ] })
            ] })
          }
        ),
        /* @__PURE__ */ o.jsx(
          "div",
          {
            className: "srs-direction-question",
            style: {
              marginBottom: "16px",
              padding: "20px",
              backgroundColor: "var(--orca-color-bg-2)",
              borderRadius: "8px",
              minHeight: "100px",
              fontSize: "18px",
              lineHeight: "1.8",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "12px"
            },
            children: y === "forward" ? /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
              /* @__PURE__ */ o.jsx("span", { style: { fontWeight: 500 }, children: T }),
              /* @__PURE__ */ o.jsx(
                "i",
                {
                  className: `ti ${H}`,
                  style: {
                    fontSize: "20px",
                    color: D
                  }
                }
              ),
              g ? /* @__PURE__ */ o.jsx(
                "span",
                {
                  style: {
                    fontWeight: 600,
                    color: D,
                    backgroundColor: _,
                    padding: "4px 12px",
                    borderRadius: "6px"
                  },
                  children: O
                }
              ) : /* @__PURE__ */ o.jsx(
                "span",
                {
                  style: {
                    color: "var(--orca-color-text-2)",
                    backgroundColor: "var(--orca-color-bg-3)",
                    padding: "4px 12px",
                    borderRadius: "6px",
                    border: "1px dashed var(--orca-color-border-1)"
                  },
                  children: "❓"
                }
              )
            ] }) : /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
              g ? /* @__PURE__ */ o.jsx(
                "span",
                {
                  style: {
                    fontWeight: 600,
                    color: D,
                    backgroundColor: _,
                    padding: "4px 12px",
                    borderRadius: "6px"
                  },
                  children: O
                }
              ) : /* @__PURE__ */ o.jsx(
                "span",
                {
                  style: {
                    color: "var(--orca-color-text-2)",
                    backgroundColor: "var(--orca-color-bg-3)",
                    padding: "4px 12px",
                    borderRadius: "6px",
                    border: "1px dashed var(--orca-color-border-1)"
                  },
                  children: "❓"
                }
              ),
              /* @__PURE__ */ o.jsx(
                "i",
                {
                  className: `ti ${H}`,
                  style: {
                    fontSize: "20px",
                    color: D
                  }
                }
              ),
              /* @__PURE__ */ o.jsx("span", { style: { fontWeight: 500 }, children: T })
            ] })
          }
        ),
        g ? /* @__PURE__ */ o.jsxs(
          "div",
          {
            className: "srs-card-grade-buttons",
            style: {
              display: "grid",
              gridTemplateColumns: s ? "repeat(5, 1fr)" : "repeat(4, 1fr)",
              gap: "8px",
              marginTop: "16px"
            },
            children: [
              s && /* @__PURE__ */ o.jsxs(
                "button",
                {
                  onClick: s,
                  style: {
                    padding: "16px 8px",
                    fontSize: "14px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: "6px",
                    backgroundColor: "rgba(156, 163, 175, 0.12)",
                    border: "1px solid rgba(156, 163, 175, 0.2)",
                    borderRadius: "8px",
                    cursor: "pointer",
                    transition: "all 0.2s"
                  },
                  onMouseEnter: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(156, 163, 175, 0.18)", j.currentTarget.style.transform = "translateY(-2px)";
                  },
                  onMouseLeave: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(156, 163, 175, 0.12)", j.currentTarget.style.transform = "translateY(0)";
                  },
                  children: [
                    /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: "不评分" }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "⏭️" }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "跳过" })
                  ]
                }
              ),
              /* @__PURE__ */ o.jsxs(
                "button",
                {
                  onClick: () => P("again"),
                  style: {
                    padding: "16px 8px",
                    fontSize: "14px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: "6px",
                    backgroundColor: "rgba(239, 68, 68, 0.12)",
                    border: "1px solid rgba(239, 68, 68, 0.2)",
                    borderRadius: "8px",
                    cursor: "pointer",
                    transition: "all 0.2s"
                  },
                  onMouseEnter: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(239, 68, 68, 0.18)", j.currentTarget.style.transform = "translateY(-2px)";
                  },
                  onMouseLeave: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(239, 68, 68, 0.12)", j.currentTarget.style.transform = "translateY(0)";
                  },
                  children: [
                    /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: Se(N.again) }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😞" }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "忘记" })
                  ]
                }
              ),
              /* @__PURE__ */ o.jsxs(
                "button",
                {
                  onClick: () => P("hard"),
                  style: {
                    padding: "16px 8px",
                    fontSize: "14px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: "6px",
                    backgroundColor: "rgba(251, 191, 36, 0.12)",
                    border: "1px solid rgba(251, 191, 36, 0.2)",
                    borderRadius: "8px",
                    cursor: "pointer",
                    transition: "all 0.2s"
                  },
                  onMouseEnter: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(251, 191, 36, 0.18)", j.currentTarget.style.transform = "translateY(-2px)";
                  },
                  onMouseLeave: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(251, 191, 36, 0.12)", j.currentTarget.style.transform = "translateY(0)";
                  },
                  children: [
                    /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: Se(N.hard) }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😐" }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "困难" })
                  ]
                }
              ),
              /* @__PURE__ */ o.jsxs(
                "button",
                {
                  onClick: () => P("good"),
                  style: {
                    padding: "16px 8px",
                    fontSize: "14px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: "6px",
                    backgroundColor: "rgba(34, 197, 94, 0.12)",
                    border: "1px solid rgba(34, 197, 94, 0.2)",
                    borderRadius: "8px",
                    cursor: "pointer",
                    transition: "all 0.2s"
                  },
                  onMouseEnter: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(34, 197, 94, 0.18)", j.currentTarget.style.transform = "translateY(-2px)";
                  },
                  onMouseLeave: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(34, 197, 94, 0.12)", j.currentTarget.style.transform = "translateY(0)";
                  },
                  children: [
                    /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: Se(N.good) }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😊" }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "良好" })
                  ]
                }
              ),
              /* @__PURE__ */ o.jsxs(
                "button",
                {
                  onClick: () => P("easy"),
                  style: {
                    padding: "16px 8px",
                    fontSize: "14px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: "6px",
                    backgroundColor: "rgba(59, 130, 246, 0.12)",
                    border: "1px solid rgba(59, 130, 246, 0.2)",
                    borderRadius: "8px",
                    cursor: "pointer",
                    transition: "all 0.2s"
                  },
                  onMouseEnter: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(59, 130, 246, 0.18)", j.currentTarget.style.transform = "translateY(-2px)";
                  },
                  onMouseLeave: (j) => {
                    j.currentTarget.style.backgroundColor = "rgba(59, 130, 246, 0.12)", j.currentTarget.style.transform = "translateY(0)";
                  },
                  children: [
                    /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: Se(N.easy) }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😄" }),
                    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "简单" })
                  ]
                }
              )
            ]
          }
        ) : /* @__PURE__ */ o.jsx("div", { style: { textAlign: "center", marginBottom: "12px" }, children: /* @__PURE__ */ o.jsx(
          ut,
          {
            variant: "solid",
            onClick: () => S(!0),
            style: {
              padding: "12px 32px",
              fontSize: "16px"
            },
            children: "显示答案"
          }
        ) })
      ]
    }
  );
}
const { useState: Jo, useEffect: vo, useRef: ar, useMemo: Mr } = window.React, { useSnapshot: ji } = window.Valtio, { Block: sr, Button: ft, ModalOverlay: ki, BlockBreadcrumb: Ri } = orca.components;
function $i(e) {
  if (e == null) return "新卡";
  switch (e) {
    case I.New:
      return "新卡";
    case I.Learning:
      return "学习中";
    case I.Review:
      return "复习中";
    case I.Relearning:
      return "重学中";
    default:
      return "未知";
  }
}
function Qo(e) {
  if (!e) return "从未";
  const t = new Date(e), r = t.getFullYear(), n = String(t.getMonth() + 1).padStart(2, "0"), a = String(t.getDate()).padStart(2, "0"), s = String(t.getHours()).padStart(2, "0"), i = String(t.getMinutes()).padStart(2, "0");
  return `${r}-${n}-${a} ${s}:${i}`;
}
function Di({ blockId: e, panelId: t, fallback: r }) {
  const n = ar(null);
  return vo(() => {
    const a = n.current;
    if (!a || !e) return;
    const s = () => {
      a.querySelectorAll(`
        .orca-block-children,
        .orca-repr-children,
        [data-role='children'],
        [data-testid='children']
      `).forEach((d) => {
        d.remove();
      });
    };
    s();
    const i = new MutationObserver((c) => {
      let l = !1;
      for (const d of c) {
        if (d.type === "childList" && d.addedNodes.length > 0) {
          for (const u of d.addedNodes)
            if (u instanceof HTMLElement && (u.classList.contains("orca-block-children") || u.classList.contains("orca-repr-children") || u.getAttribute("data-role") === "children" || u.querySelector('.orca-block-children, .orca-repr-children, [data-role="children"]'))) {
              l = !0;
              break;
            }
        }
        if (l) break;
      }
      l && s();
    });
    return i.observe(a, {
      childList: !0,
      subtree: !0,
      attributes: !1,
      characterData: !1
    }), () => {
      i.disconnect();
    };
  }, [e]), !e || !t ? /* @__PURE__ */ o.jsx("div", { style: {
    padding: "12px",
    fontSize: "16px",
    color: "var(--orca-color-text-1)",
    lineHeight: "1.6",
    whiteSpace: "pre-wrap"
  }, children: r }) : /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
    /* @__PURE__ */ o.jsx(Ri, { blockId: e }, e),
    /* @__PURE__ */ o.jsx(
      "div",
      {
        ref: n,
        className: "srs-question-block",
        "data-orca-block-root": "true",
        children: /* @__PURE__ */ o.jsx(
          sr,
          {
            panelId: t,
            blockId: e,
            blockLevel: 0,
            indentLevel: 0
          }
        )
      }
    )
  ] });
}
function _i({ blockId: e, panelId: t, fallback: r }) {
  const n = ar(null), a = ar(null);
  return vo(() => {
    const s = n.current;
    if (!s || !e) return;
    const i = () => {
      const d = s.querySelector(":scope > .orca-block > .orca-repr > .orca-repr-main");
      d && (d.style.display = "none"), s.querySelectorAll(`
        :scope > .orca-block > .orca-block-handle,
        :scope > .orca-block > .orca-block-bullet,
        :scope > .orca-block > .orca-repr > .orca-repr-handle,
        :scope > .orca-block > .orca-repr > .orca-repr-collapse
      `).forEach((x) => {
        x.style.display = "none", x.style.width = "0", x.style.height = "0", x.style.overflow = "hidden";
      });
    }, c = (d = 100) => {
      a.current !== null && clearTimeout(a.current), a.current = setTimeout(() => {
        i(), a.current = null;
      }, d);
    };
    i();
    const l = new MutationObserver(() => {
      c(100);
    });
    return l.observe(s, {
      childList: !0,
      subtree: !0,
      attributes: !1,
      characterData: !1
    }), () => {
      l.disconnect(), a.current !== null && (clearTimeout(a.current), a.current = null);
    };
  }, [e]), !e || !t ? /* @__PURE__ */ o.jsx("div", { style: {
    padding: "12px",
    fontSize: "20px",
    fontWeight: "500",
    color: "var(--orca-color-text-1)",
    lineHeight: "1.6",
    whiteSpace: "pre-wrap"
  }, children: r }) : /* @__PURE__ */ o.jsx(
    "div",
    {
      ref: n,
      className: "srs-answer-block",
      style: {
        // 往前缩进一个层级以对齐
        marginLeft: "-25.6px"
      },
      "data-orca-block-root": "true",
      children: /* @__PURE__ */ o.jsx(
        sr,
        {
          panelId: t,
          blockId: e,
          blockLevel: 0,
          indentLevel: 0
        }
      )
    }
  );
}
function Xo({
  front: e,
  back: t,
  onGrade: r,
  onPostpone: n,
  onSuspend: a,
  onClose: s,
  onSkip: i,
  onPrevious: c,
  canGoPrevious: l = !1,
  srsInfo: d,
  isGrading: u = !1,
  blockId: f,
  nextBlockId: x,
  onJumpToCard: h,
  inSidePanel: y = !1,
  panelId: g,
  pluginName: S = "orca-srs",
  clozeNumber: m,
  directionType: v
}) {
  const [C, M] = Jo(!1), [b, P] = Jo(!1), N = ar(f);
  vo(() => {
    N.current !== f && (M(!1), P(!1), N.current = f);
  }, [f]);
  const T = ji(orca.state), { questionBlock: O, answerBlockIds: H, totalChildCount: z, inferredCardType: D } = Mr(() => {
    const k = (T == null ? void 0 : T.blocks) ?? {}, ue = f ? k[f] : null, Ce = (ue == null ? void 0 : ue.children) ?? [], $e = ue ? gt(ue) : "basic";
    return {
      questionBlock: ue,
      answerBlockIds: Ce,
      // 返回所有子块 ID
      totalChildCount: Ce.length,
      inferredCardType: $e
    };
  }, [T == null ? void 0 : T.blocks, f]), _ = D === "cloze" ? "srs.cloze-card" : D === "direction" ? "srs.direction-card" : D === "excerpt" ? "srs.excerpt-card" : "srs.card", j = _ === "srs.excerpt-card" || _ === "srs.card" && O && z === 0, w = _ === "srs.card" || _ === "srs.cloze-card" && !f || _ === "srs.direction-card" && (!f || !v), B = async (k) => {
    u || (console.log(`[SRS Card Demo] 用户选择评分: ${k}`), await r(k), M(!1));
  };
  mo({
    showAnswer: C,
    isGrading: u,
    onShowAnswer: () => M(!0),
    onGrade: B,
    onBury: n,
    onSuspend: a,
    enabled: w
    // 仅在渲染 basic 卡片时启用
  });
  const J = Mr(() => {
    const k = d ? {
      stability: d.stability ?? 0,
      difficulty: d.difficulty ?? 0,
      interval: d.interval ?? 0,
      due: d.due ?? /* @__PURE__ */ new Date(),
      lastReviewed: d.lastReviewed ?? null,
      reps: d.reps ?? 0,
      lapses: d.lapses ?? 0,
      state: d.state
    } : null;
    return Zr(k);
  }, [d]), G = Mr(() => {
    const k = d ? {
      stability: d.stability ?? 0,
      difficulty: d.difficulty ?? 0,
      interval: d.interval ?? 0,
      due: d.due ?? /* @__PURE__ */ new Date(),
      lastReviewed: d.lastReviewed ?? null,
      reps: d.reps ?? 0,
      lapses: d.lapses ?? 0,
      state: d.state
    } : null;
    return eo(k);
  }, [d]);
  if (_ === "srs.cloze-card" && f)
    return /* @__PURE__ */ o.jsx(ot, { componentName: "填空卡片", errorTitle: "填空卡片加载出错", children: /* @__PURE__ */ o.jsx(
      bi,
      {
        blockId: f,
        onGrade: r,
        onPostpone: n,
        onSuspend: a,
        onClose: s,
        onSkip: i,
        onPrevious: c,
        canGoPrevious: l,
        srsInfo: d,
        isGrading: u,
        onJumpToCard: h,
        inSidePanel: y,
        panelId: g,
        pluginName: S,
        clozeNumber: m
      }
    ) });
  if (_ === "srs.direction-card" && f && v)
    return /* @__PURE__ */ o.jsx(ot, { componentName: "方向卡片", errorTitle: "方向卡片加载出错", children: /* @__PURE__ */ o.jsx(
      Ci,
      {
        blockId: f,
        onGrade: r,
        onPostpone: n,
        onSuspend: a,
        onClose: s,
        onSkip: i,
        onPrevious: c,
        canGoPrevious: l,
        srsInfo: d,
        isGrading: u,
        onJumpToCard: h,
        inSidePanel: y,
        panelId: g,
        pluginName: S,
        reviewDirection: v
      }
    ) });
  const pe = /* @__PURE__ */ o.jsxs("div", { className: "srs-card-container", style: {
    borderRadius: "12px",
    padding: "16px",
    width: y ? "100%" : "90%",
    minWidth: y ? "0" : "600px",
    boxShadow: "0 4px 20px rgba(0,0,0,0.15)"
  }, children: [
    f && /* @__PURE__ */ o.jsxs("div", { contentEditable: !1, style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: "8px",
      opacity: 0.6,
      transition: "opacity 0.2s"
    }, onMouseEnter: (k) => k.currentTarget.style.opacity = "1", onMouseLeave: (k) => k.currentTarget.style.opacity = "0.6", children: [
      /* @__PURE__ */ o.jsx("div", { style: { display: "flex", gap: "4px" }, children: c && /* @__PURE__ */ o.jsx(
        ft,
        {
          variant: "plain",
          onClick: l ? c : void 0,
          title: "回到上一张",
          style: {
            padding: "4px 6px",
            fontSize: "14px",
            opacity: l ? 1 : 0.3,
            cursor: l ? "pointer" : "not-allowed"
          },
          children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-arrow-left" })
        }
      ) }),
      /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "2px" }, children: [
        n && /* @__PURE__ */ o.jsx(
          ft,
          {
            variant: "plain",
            onClick: n,
            title: "推迟到明天 (B)",
            style: { padding: "4px 6px", fontSize: "14px" },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-calendar-pause" })
          }
        ),
        a && /* @__PURE__ */ o.jsx(
          ft,
          {
            variant: "plain",
            onClick: a,
            title: "暂停卡片 (S)",
            style: { padding: "4px 6px", fontSize: "14px" },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-player-pause" })
          }
        ),
        h && /* @__PURE__ */ o.jsx(
          ft,
          {
            variant: "plain",
            onClick: (k) => h(f, k.shiftKey),
            title: "跳转到卡片 (Shift+点击在侧面板打开)",
            style: { padding: "4px 6px", fontSize: "14px" },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-external-link" })
          }
        ),
        /* @__PURE__ */ o.jsx(
          ft,
          {
            variant: "plain",
            onClick: () => P(!b),
            title: "卡片信息",
            style: {
              padding: "4px 6px",
              fontSize: "14px",
              color: b ? "var(--orca-color-primary-5)" : void 0
            },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-info-circle" })
          }
        )
      ] })
    ] }),
    f && b && /* @__PURE__ */ o.jsx(
      "div",
      {
        contentEditable: !1,
        style: {
          marginBottom: "12px",
          padding: "12px 16px",
          backgroundColor: "var(--orca-color-bg-2)",
          borderRadius: "8px",
          fontSize: "13px",
          color: "var(--orca-color-text-2)"
        },
        children: /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "8px" }, children: [
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "遗忘次数" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: (d == null ? void 0 : d.lapses) ?? 0 })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "复习次数" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: (d == null ? void 0 : d.reps) ?? 0 })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "卡片状态" }),
            /* @__PURE__ */ o.jsx("span", { style: {
              color: (d == null ? void 0 : d.state) === I.Review ? "var(--orca-color-success)" : (d == null ? void 0 : d.state) === I.Learning || (d == null ? void 0 : d.state) === I.Relearning ? "var(--orca-color-warning)" : "var(--orca-color-primary)"
            }, children: $i(d == null ? void 0 : d.state) })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "最后复习" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: Qo(d == null ? void 0 : d.lastReviewed) })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "下次到期" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: Qo(d == null ? void 0 : d.due) })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "间隔天数" }),
            /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-text-1)" }, children: [
              (d == null ? void 0 : d.interval) ?? 0,
              " 天"
            ] })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "稳定性" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: ((d == null ? void 0 : d.stability) ?? 0).toFixed(2) })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ o.jsx("span", { children: "难度" }),
            /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-text-1)" }, children: ((d == null ? void 0 : d.difficulty) ?? 0).toFixed(2) })
          ] })
        ] })
      }
    ),
    !j && /* @__PURE__ */ o.jsx(
      "div",
      {
        className: "srs-card-front",
        style: {
          marginBottom: "16px",
          padding: "20px",
          backgroundColor: "var(--orca-color-bg-2)",
          borderRadius: "8px",
          minHeight: "80px"
        },
        children: /* @__PURE__ */ o.jsx(
          Di,
          {
            blockId: f,
            panelId: g,
            fallback: e
          },
          f
        )
      }
    ),
    j ? /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
      /* @__PURE__ */ o.jsxs(
        "div",
        {
          className: "srs-card-back",
          style: {
            marginBottom: "16px",
            padding: "20px",
            borderRadius: "8px",
            minHeight: "80px"
          },
          children: [
            /* @__PURE__ */ o.jsx("div", { contentEditable: !1, style: {
              fontSize: "18px",
              fontWeight: "600",
              color: "var(--orca-color-text-2)",
              marginBottom: "16px",
              textAlign: "center"
            }, children: "摘录" }),
            f && g && /* @__PURE__ */ o.jsx(
              sr,
              {
                panelId: g,
                blockId: f,
                blockLevel: 0,
                indentLevel: 0
              }
            ),
            !f && /* @__PURE__ */ o.jsx("div", { style: {
              padding: "12px",
              fontSize: "20px",
              fontWeight: "500",
              color: "var(--orca-color-text-1)",
              lineHeight: "1.6",
              whiteSpace: "pre-wrap",
              userSelect: "text",
              WebkitUserSelect: "text"
            }, children: e })
          ]
        }
      ),
      /* @__PURE__ */ o.jsxs("div", { contentEditable: !1, className: "srs-card-grade-buttons", style: {
        display: "grid",
        gridTemplateColumns: i ? "repeat(5, 1fr)" : "repeat(4, 1fr)",
        gap: "8px"
      }, children: [
        i && /* @__PURE__ */ o.jsxs(
          "button",
          {
            onClick: i,
            style: {
              padding: "16px 8px",
              fontSize: "14px",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "6px",
              backgroundColor: "rgba(156, 163, 175, 0.12)",
              border: "1px solid rgba(156, 163, 175, 0.2)",
              borderRadius: "8px",
              cursor: "pointer",
              transition: "all 0.2s"
            },
            onMouseEnter: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(156, 163, 175, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
            },
            onMouseLeave: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(156, 163, 175, 0.12)", k.currentTarget.style.transform = "translateY(0)";
            },
            children: [
              /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: "不评分" }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "⏭️" }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "跳过" })
            ]
          }
        ),
        /* @__PURE__ */ o.jsxs(
          "button",
          {
            onClick: () => B("again"),
            style: {
              padding: "16px 8px",
              fontSize: "14px",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "6px",
              backgroundColor: "rgba(239, 68, 68, 0.12)",
              border: "1px solid rgba(239, 68, 68, 0.2)",
              borderRadius: "8px",
              cursor: "pointer",
              transition: "all 0.2s"
            },
            onMouseEnter: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(239, 68, 68, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
            },
            onMouseLeave: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(239, 68, 68, 0.12)", k.currentTarget.style.transform = "translateY(0)";
            },
            children: [
              /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: new Date(G.again).toDateString() === (/* @__PURE__ */ new Date()).toDateString() ? be(J.again) : `${Se(G.again)} ${be(J.again)}` }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😞" }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "忘记" })
            ]
          }
        ),
        /* @__PURE__ */ o.jsxs(
          "button",
          {
            onClick: () => B("hard"),
            style: {
              padding: "16px 8px",
              fontSize: "14px",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "6px",
              backgroundColor: "rgba(251, 191, 36, 0.12)",
              border: "1px solid rgba(251, 191, 36, 0.2)",
              borderRadius: "8px",
              cursor: "pointer",
              transition: "all 0.2s"
            },
            onMouseEnter: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(251, 191, 36, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
            },
            onMouseLeave: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(251, 191, 36, 0.12)", k.currentTarget.style.transform = "translateY(0)";
            },
            children: [
              /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: new Date(G.hard).toDateString() === (/* @__PURE__ */ new Date()).toDateString() ? be(J.hard) : `${Se(G.hard)} ${be(J.hard)}` }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😐" }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "困难" })
            ]
          }
        ),
        /* @__PURE__ */ o.jsxs(
          "button",
          {
            onClick: () => B("good"),
            style: {
              padding: "16px 8px",
              fontSize: "14px",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "6px",
              backgroundColor: "rgba(34, 197, 94, 0.12)",
              border: "1px solid rgba(34, 197, 94, 0.2)",
              borderRadius: "8px",
              cursor: "pointer",
              transition: "all 0.2s"
            },
            onMouseEnter: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(34, 197, 94, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
            },
            onMouseLeave: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(34, 197, 94, 0.12)", k.currentTarget.style.transform = "translateY(0)";
            },
            children: [
              /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: new Date(G.good).toDateString() === (/* @__PURE__ */ new Date()).toDateString() ? be(J.good) : `${Se(G.good)} ${be(J.good)}` }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😊" }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "良好" })
            ]
          }
        ),
        /* @__PURE__ */ o.jsxs(
          "button",
          {
            onClick: () => B("easy"),
            style: {
              padding: "16px 8px",
              fontSize: "14px",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "6px",
              backgroundColor: "rgba(59, 130, 246, 0.12)",
              border: "1px solid rgba(59, 130, 246, 0.2)",
              borderRadius: "8px",
              cursor: "pointer",
              transition: "all 0.2s"
            },
            onMouseEnter: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(59, 130, 246, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
            },
            onMouseLeave: (k) => {
              k.currentTarget.style.backgroundColor = "rgba(59, 130, 246, 0.12)", k.currentTarget.style.transform = "translateY(0)";
            },
            children: [
              /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: new Date(G.easy).toDateString() === (/* @__PURE__ */ new Date()).toDateString() ? be(J.easy) : `${Se(G.easy)} ${be(J.easy)}` }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😄" }),
              /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "简单" })
            ]
          }
        )
      ] })
    ] }) : (
      /* 普通卡片：如果没有子块（摘录卡），直接显示评分按钮；否则显示答案按钮 */
      z === 0 || C ? (
        // 摘录卡或已显示答案：显示答案区域（如果有）和评分按钮
        /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
          z > 0 && C && /* @__PURE__ */ o.jsxs(
            "div",
            {
              className: "srs-card-back",
              style: {
                marginBottom: "16px",
                padding: "20px",
                borderRadius: "8px",
                minHeight: "80px"
              },
              children: [
                /* @__PURE__ */ o.jsx("div", { contentEditable: !1, style: {
                  fontSize: "18px",
                  fontWeight: "600",
                  color: "var(--orca-color-text-2)",
                  marginBottom: "16px",
                  textAlign: "center"
                }, children: "答案" }),
                /* @__PURE__ */ o.jsx(
                  _i,
                  {
                    blockId: f,
                    panelId: g,
                    fallback: t
                  },
                  f
                )
              ]
            }
          ),
          /* @__PURE__ */ o.jsxs("div", { contentEditable: !1, className: "srs-card-grade-buttons", style: {
            display: "grid",
            gridTemplateColumns: i ? "repeat(5, 1fr)" : "repeat(4, 1fr)",
            gap: "8px"
          }, children: [
            i && /* @__PURE__ */ o.jsxs(
              "button",
              {
                onClick: i,
                style: {
                  padding: "16px 8px",
                  fontSize: "14px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "6px",
                  backgroundColor: "rgba(156, 163, 175, 0.12)",
                  border: "1px solid rgba(156, 163, 175, 0.2)",
                  borderRadius: "8px",
                  cursor: "pointer",
                  transition: "all 0.2s"
                },
                onMouseEnter: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(156, 163, 175, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
                },
                onMouseLeave: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(156, 163, 175, 0.12)", k.currentTarget.style.transform = "translateY(0)";
                },
                children: [
                  /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: "不评分" }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "⏭️" }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "跳过" })
                ]
              }
            ),
            /* @__PURE__ */ o.jsxs(
              "button",
              {
                onClick: () => B("again"),
                style: {
                  padding: "16px 8px",
                  fontSize: "14px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "6px",
                  backgroundColor: "rgba(239, 68, 68, 0.12)",
                  border: "1px solid rgba(239, 68, 68, 0.2)",
                  borderRadius: "8px",
                  cursor: "pointer",
                  transition: "all 0.2s"
                },
                onMouseEnter: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(239, 68, 68, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
                },
                onMouseLeave: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(239, 68, 68, 0.12)", k.currentTarget.style.transform = "translateY(0)";
                },
                children: [
                  /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: new Date(G.again).toDateString() === (/* @__PURE__ */ new Date()).toDateString() ? be(J.again) : `${Se(G.again)} ${be(J.again)}` }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😞" }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "忘记" })
                ]
              }
            ),
            /* @__PURE__ */ o.jsxs(
              "button",
              {
                onClick: () => B("hard"),
                style: {
                  padding: "16px 8px",
                  fontSize: "14px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "6px",
                  backgroundColor: "rgba(251, 191, 36, 0.12)",
                  border: "1px solid rgba(251, 191, 36, 0.2)",
                  borderRadius: "8px",
                  cursor: "pointer",
                  transition: "all 0.2s"
                },
                onMouseEnter: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(251, 191, 36, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
                },
                onMouseLeave: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(251, 191, 36, 0.12)", k.currentTarget.style.transform = "translateY(0)";
                },
                children: [
                  /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: new Date(G.hard).toDateString() === (/* @__PURE__ */ new Date()).toDateString() ? be(J.hard) : `${Se(G.hard)} ${be(J.hard)}` }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😐" }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "困难" })
                ]
              }
            ),
            /* @__PURE__ */ o.jsxs(
              "button",
              {
                onClick: () => B("good"),
                style: {
                  padding: "16px 8px",
                  fontSize: "14px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "6px",
                  backgroundColor: "rgba(34, 197, 94, 0.12)",
                  border: "1px solid rgba(34, 197, 94, 0.2)",
                  borderRadius: "8px",
                  cursor: "pointer",
                  transition: "all 0.2s"
                },
                onMouseEnter: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(34, 197, 94, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
                },
                onMouseLeave: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(34, 197, 94, 0.12)", k.currentTarget.style.transform = "translateY(0)";
                },
                children: [
                  /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: new Date(G.good).toDateString() === (/* @__PURE__ */ new Date()).toDateString() ? be(J.good) : `${Se(G.good)} ${be(J.good)}` }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😊" }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "良好" })
                ]
              }
            ),
            /* @__PURE__ */ o.jsxs(
              "button",
              {
                onClick: () => B("easy"),
                style: {
                  padding: "16px 8px",
                  fontSize: "14px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "6px",
                  backgroundColor: "rgba(59, 130, 246, 0.12)",
                  border: "1px solid rgba(59, 130, 246, 0.2)",
                  borderRadius: "8px",
                  cursor: "pointer",
                  transition: "all 0.2s"
                },
                onMouseEnter: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(59, 130, 246, 0.18)", k.currentTarget.style.transform = "translateY(-2px)";
                },
                onMouseLeave: (k) => {
                  k.currentTarget.style.backgroundColor = "rgba(59, 130, 246, 0.12)", k.currentTarget.style.transform = "translateY(0)";
                },
                children: [
                  /* @__PURE__ */ o.jsx("div", { style: { fontSize: "10px", opacity: 0.7, lineHeight: "1.2" }, children: new Date(G.easy).toDateString() === (/* @__PURE__ */ new Date()).toDateString() ? be(J.easy) : `${Se(G.easy)} ${be(J.easy)}` }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "32px", lineHeight: "1" }, children: "😄" }),
                  /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", opacity: 0.85, fontWeight: "500" }, children: "简单" })
                ]
              }
            )
          ] })
        ] })
      ) : (
        // 有子块但未显示答案：显示"显示答案"按钮
        /* @__PURE__ */ o.jsx("div", { contentEditable: !1, style: { textAlign: "center", marginBottom: "12px" }, children: /* @__PURE__ */ o.jsx(
          ft,
          {
            variant: "solid",
            onClick: () => M(!0),
            style: {
              padding: "12px 32px",
              fontSize: "16px"
            },
            children: "显示答案"
          }
        ) })
      )
    )
  ] }), se = x && g ? /* @__PURE__ */ o.jsx("div", { style: { position: "absolute", left: "-9999px", visibility: "hidden", pointerEvents: "none" }, children: /* @__PURE__ */ o.jsx(
    sr,
    {
      panelId: g,
      blockId: x,
      blockLevel: 0,
      indentLevel: 0
    }
  ) }) : null;
  return y ? /* @__PURE__ */ o.jsx(ot, { componentName: "复习卡片", errorTitle: "卡片加载出错", children: /* @__PURE__ */ o.jsxs("div", { style: { width: "100%", display: "flex", justifyContent: "center" }, children: [
    pe,
    se
  ] }) }) : /* @__PURE__ */ o.jsx(ot, { componentName: "复习卡片", errorTitle: "卡片加载出错", children: /* @__PURE__ */ o.jsxs(
    ki,
    {
      visible: !0,
      canClose: !0,
      onClose: s,
      className: "srs-card-modal",
      children: [
        pe,
        se
      ]
    }
  ) });
}
const { useEffect: pt, useMemo: Ti, useRef: Vt, useState: Ie } = window.React, { Button: Kt, ModalOverlay: Zo } = orca.components;
function zi(e) {
  const t = e.getMonth() + 1, r = e.getDate();
  return `${t}-${r}`;
}
function Ei({
  cards: e,
  onClose: t,
  onJumpToCard: r,
  inSidePanel: n = !1,
  panelId: a,
  pluginName: s = "orca-srs",
  isRepeatMode: i = !1,
  currentRound: c = 1,
  onRepeatRound: l
}) {
  const d = Vt(null), [u, f] = Ie(e), [x, h] = Ie(0), [y, g] = Ie(0), [S, m] = Ie(!1), [v, C] = Ie(null), [M, b] = Ie(!0), [P, N] = Ie([]), [T, O] = Ie(0), [H, z] = Ie(Date.now()), [D, _] = Ie(c);
  pt(() => {
    c !== D && (f([...e]), h(0), N([]), g(0), O(0), _(c), C(`开始第 ${c} 轮复习`), qr(), console.log(`[SRS Review Session] 重置队列，开始第 ${c} 轮复习，卡片数: ${e.length}`));
  }, [e, c, D]), pt(() => {
    qr(), console.log("[SRS Review Session] 会话开始，重置已处理父卡片集合");
  }, []), pt(() => {
    const R = d.current;
    if (!R) return;
    const W = R.closest(".orca-block-editor");
    if (!W) return;
    const Q = W.querySelector(".orca-block-editor-none-editable"), U = W.querySelector(".orca-block-editor-go-btns"), oe = W.querySelector(".orca-block-editor-sidetools"), X = W.querySelector(".orca-repr-main-none-editable"), q = W.querySelector(".orca-breadcrumb");
    return M ? (W.setAttribute("maximize", "1"), Q && (Q.style.display = "none"), U && (U.style.display = "none"), oe && (oe.style.display = "none"), X && (X.style.display = "none"), q && (q.style.display = "none"), W.querySelectorAll(".orca-block-handle, .orca-repr-handle").forEach((ie) => {
      ie.style.display = "none";
    }), W.querySelectorAll('.orca-block-bullet, [data-role="bullet"]').forEach((ie) => {
      ie.style.display = "none";
    }), W.querySelectorAll(".orca-block-drag-handle").forEach((ie) => {
      ie.style.display = "none";
    }), W.querySelectorAll('.orca-repr-collapse, [class*="collapse"]').forEach((ie) => {
      ie.style.display = "none";
    })) : (W.removeAttribute("maximize"), Q && (Q.style.display = ""), U && (U.style.display = ""), oe && (oe.style.display = ""), X && (X.style.display = ""), q && (q.style.display = ""), W.querySelectorAll(".orca-block-handle, .orca-repr-handle").forEach((ie) => {
      ie.style.display = "";
    }), W.querySelectorAll('.orca-block-bullet, [data-role="bullet"]').forEach((ie) => {
      ie.style.display = "";
    }), W.querySelectorAll(".orca-block-drag-handle").forEach((ie) => {
      ie.style.display = "";
    }), W.querySelectorAll('.orca-repr-collapse, [class*="collapse"]').forEach((ie) => {
      ie.style.display = "";
    })), () => {
      W.removeAttribute("maximize"), Q && (Q.style.display = ""), U && (U.style.display = ""), oe && (oe.style.display = ""), X && (X.style.display = ""), q && (q.style.display = ""), W.querySelectorAll(".orca-block-handle, .orca-repr-handle").forEach((ie) => {
        ie.style.display = "";
      }), W.querySelectorAll('.orca-block-bullet, [data-role="bullet"]').forEach((ie) => {
        ie.style.display = "";
      }), W.querySelectorAll(".orca-block-drag-handle").forEach((ie) => {
        ie.style.display = "";
      }), W.querySelectorAll('.orca-repr-collapse, [class*="collapse"]').forEach((ie) => {
        ie.style.display = "";
      });
    };
  }, [M]);
  const j = u.length, w = x < j ? u[x] : null, B = x + 1 < j ? u[x + 1] : null, J = x >= j && j > 0;
  pt(() => {
    var R;
    B != null && B.id && ((R = orca.state.blocks) != null && R[B.id] || console.log(`[SRS Review Session] 预缓存下一张卡片: ${B.id}`));
  }, [B == null ? void 0 : B.id]), pt(() => {
    z(Date.now());
  }, [x]);
  const G = Ti(() => {
    const R = Date.now();
    let W = 0, Q = 0;
    for (const U of u)
      U.isNew ? Q += 1 : U.srs.due.getTime() <= R && (W += 1);
    return { due: W, fresh: Q };
  }, [u]), pe = Vt(/* @__PURE__ */ new Map()), se = Vt(null), k = Vt(x);
  k.current = x;
  const ue = () => {
    const R = Date.now(), W = pe.current, Q = [];
    console.log(`[${s}] 检查待到期卡片，当前追踪 ${W.size} 张`);
    for (const [U, { card: oe, dueTime: X }] of W.entries())
      console.log(`[${s}] 检查卡片 ${U}: dueTime=${X}, now=${R}, diff=${X - R}ms`), R >= X && (Q.push(oe), W.delete(U), console.log(`[${s}] 卡片 ${U} 已到期，准备加入队列`));
    if (Q.length > 0 && (console.log(`[${s}] ${Q.length} 张短期卡片已到期，添加到复习队列`), f((U) => {
      const oe = k.current, X = U.slice(oe), q = new Set(X.map(
        (ne) => `${ne.id}-${ne.clozeNumber || 0}-${ne.directionType || "basic"}`
      )), de = Q.filter((ne) => {
        const ve = `${ne.id}-${ne.clozeNumber || 0}-${ne.directionType || "basic"}`;
        return !q.has(ve);
      });
      return de.length > 0 ? (O((ne) => ne + de.length), C(`${de.length} 张卡片已到期，加入队列`), orca.notify("info", `${de.length} 张卡片已到期`, { title: "SRS 复习" }), console.log(`[${s}] 成功添加 ${de.length} 张卡片到队列末尾`), [...U, ...de]) : (console.log(`[${s}] 卡片已在未复习队列中，跳过添加`), U);
    })), W.size > 0) {
      let U = 1 / 0;
      for (const { dueTime: X } of W.values())
        X < U && (U = X);
      const oe = Math.max(1e3, U - R + 500);
      console.log(`[${s}] 还有 ${W.size} 张待检查卡片，${oe}ms 后再次检查`), se.current = setTimeout(ue, oe);
    } else
      se.current = null;
  }, Ce = (R, W) => {
    const Q = `${R.id}-${R.clozeNumber || 0}-${R.directionType || "basic"}`, U = W.getTime(), oe = Date.now();
    if (U - oe <= 5 * 60 * 1e3) {
      pe.current.set(Q, { card: R, dueTime: U });
      const X = Math.round((U - oe) / 1e3);
      if (console.log(`[${s}] 追踪短期到期卡片: ${Q}, 将在 ${X} 秒后到期`), C(`卡片将在 ${X} 秒后重新加入队列`), !se.current) {
        const q = Math.max(1e3, U - oe + 500);
        console.log(`[${s}] 启动定时器，${q}ms 后检查`), se.current = setTimeout(ue, q);
      }
    }
  };
  pt(() => {
    let R = null;
    const W = async () => {
      try {
        const { collectReviewCards: Q, buildReviewQueue: U } = await Promise.resolve().then(() => Io), oe = await Q(s), X = U(oe), q = new Set(u.map(
          (ne) => `${ne.id}-${ne.clozeNumber || 0}-${ne.directionType || "basic"}`
        )), de = X.filter((ne) => {
          const ve = `${ne.id}-${ne.clozeNumber || 0}-${ne.directionType || "basic"}`;
          return !q.has(ve);
        });
        de.length > 0 && (console.log(`[${s}] 发现 ${de.length} 张新到期卡片，添加到复习队列`), f((ne) => [...ne, ...de]), O((ne) => ne + de.length), C(`发现 ${de.length} 张新到期卡片已加入队列`), de.length > 0 && orca.notify("info", `${de.length} 张新卡片已到期`, {
          title: "SRS 复习"
        }));
      } catch (Q) {
        console.error(`[${s}] 检查新到期卡片失败:`, Q);
      }
      R = setTimeout(W, 6e4);
    };
    return R = setTimeout(W, 6e4), () => {
      R && clearTimeout(R), se.current && (clearTimeout(se.current), se.current = null);
    };
  }, [s]);
  const $e = async (R) => {
    if (!w) return;
    m(!0), console.log(`[SRS Card Demo] 用户选择评分: ${R}${i ? " (专项训练模式，不更新SRS)" : ""}`);
    let W = [...u], Q = w, U = "";
    if (w.clozeNumber ? U = ` [c${w.clozeNumber}]` : w.directionType && (U = ` [${w.directionType === "forward" ? "→" : "←"}]`), i) {
      C(`评分 ${R.toUpperCase()}${U} (专项训练，不影响复习进度)`), g((De) => De + 1), Ur(w.id, w.clozeNumber, w.directionType), f(W), m(!1), N((De) => [...De, x]), setTimeout(() => h((De) => De + 1), 250);
      return;
    }
    const oe = w.srs.interval, X = w.isNew ? "new" : w.srs.interval < 1 ? "learning" : "review";
    let q;
    w.clozeNumber ? q = await Tn(w.id, w.clozeNumber, R, s) : w.directionType ? q = await zn(w.id, w.directionType, R, s) : q = await oo(w.id, R, s), Q = { ...w, srs: q.state, isNew: !1 }, W[x] = Q;
    const de = R === "again" ? "relearning" : q.state.interval < 1 ? "learning" : "review", ne = Date.now() - H, ve = Date.now(), it = {
      id: ui(ve, w.id),
      cardId: w.id,
      deckName: w.deck,
      timestamp: ve,
      grade: R,
      duration: ne,
      previousInterval: oe,
      newInterval: q.state.interval,
      previousState: X,
      newState: de
    };
    ci(s, it), C(
      `评分 ${R.toUpperCase()}${U} -> 下次 ${zi(q.state.due)}，间隔 ${q.state.interval} 天`
    ), ei(w.id, R), g((De) => De + 1), Ur(w.id, w.clozeNumber, w.directionType), f(W);
    const ie = q.state.due.getTime(), Ht = Date.now();
    (R === "again" || R === "hard") && ie - Ht <= 5 * 60 * 1e3 && Ce(Q, q.state.due), m(!1), N((De) => [...De, x]), setTimeout(() => h((De) => De + 1), 250);
  }, Ae = async () => {
    if (!(!w || S)) {
      m(!0);
      try {
        await $s(
          w.id,
          w.clozeNumber,
          w.directionType
        );
        let R = "";
        w.clozeNumber ? R = ` [c${w.clozeNumber}]` : w.directionType && (R = ` [${w.directionType === "forward" ? "→" : "←"}]`), C(`已推迟${R}，明天再复习`), rt("orca-srs", "info", "卡片已推迟，明天再复习", { title: "SRS 复习" }), ti(w.id);
      } catch (R) {
        console.error("[SRS Review Session] 推迟卡片失败:", R), orca.notify("error", `推迟失败: ${R}`, { title: "SRS 复习" });
      }
      m(!1), N((R) => [...R, x]), setTimeout(() => h((R) => R + 1), 250);
    }
  }, Ee = async () => {
    if (!(!w || S)) {
      m(!0);
      try {
        await js(w.id);
        let R = "";
        w.clozeNumber ? R = ` [c${w.clozeNumber}]` : w.directionType && (R = ` [${w.directionType === "forward" ? "→" : "←"}]`), C(`已暂停${R}`), rt("orca-srs", "info", "卡片已暂停，可在卡片浏览器中取消暂停", { title: "SRS 复习" }), ri(w.id);
      } catch (R) {
        console.error("[SRS Review Session] 暂停卡片失败:", R), orca.notify("error", `暂停失败: ${R}`, { title: "SRS 复习" });
      }
      m(!1), N((R) => [...R, x]), setTimeout(() => h((R) => R + 1), 250);
    }
  }, A = () => {
    if (!w || S) return;
    let R = "";
    w.clozeNumber ? R = ` [c${w.clozeNumber}]` : w.directionType && (R = ` [${w.directionType === "forward" ? "→" : "←"}]`), C(`已跳过${R}`), N((W) => [...W, x]), h((W) => W + 1);
  }, L = async () => {
    try {
      const { collectReviewCards: R, buildReviewQueue: W } = await Promise.resolve().then(() => Io), Q = await R(s), U = W(Q), oe = new Set(u.map(
        (q) => `${q.id}-${q.clozeNumber || 0}-${q.directionType || "basic"}`
      )), X = U.filter((q) => {
        const de = `${q.id}-${q.clozeNumber || 0}-${q.directionType || "basic"}`;
        return !oe.has(de);
      });
      X.length > 0 ? (console.log(`[${s}] 手动检查发现 ${X.length} 张新到期卡片`), f((q) => [...q, ...X]), O((q) => q + X.length), C(`手动检查发现 ${X.length} 张新到期卡片已加入队列`), orca.notify("success", `发现 ${X.length} 张新到期卡片`, {
        title: "SRS 复习"
      })) : (C("暂无新到期卡片"), orca.notify("info", "暂无新到期卡片", {
        title: "SRS 复习"
      }));
    } catch (R) {
      console.error(`[${s}] 手动检查新到期卡片失败:`, R), C("检查新卡片失败"), orca.notify("error", "检查新卡片失败", { title: "SRS 复习" });
    }
  }, Y = () => {
    if (P.length === 0 || S) return;
    const R = P[P.length - 1];
    N((W) => W.slice(0, -1)), h(R), C("返回上一张");
  }, ee = P.length > 0 && !S, xe = (R, W) => {
    if (r) {
      r(R, W);
      return;
    }
    console.log(`[SRS Review Session] 跳转到卡片 #${R}, shiftKey: ${W}`), orca.nav.goTo("block", { blockId: R }), rt(
      "orca-srs",
      "info",
      "已跳转到卡片，复习界面仍然保留",
      { title: "SRS 复习" }
    );
  }, ge = () => {
    console.log(`[SRS Review Session] 本次复习结束，共复习 ${y} 张卡片`), rt(
      "orca-srs",
      "success",
      `本次复习完成！共复习了 ${y} 张卡片`,
      { title: "SRS 复习会话" }
    ), t && t();
  };
  if (j === 0) {
    const R = /* @__PURE__ */ o.jsxs("div", { style: {
      backgroundColor: "var(--orca-color-bg-1)",
      borderRadius: "12px",
      padding: "32px",
      maxWidth: "480px",
      width: "100%",
      textAlign: "center",
      boxShadow: "0 4px 20px rgba(0,0,0,0.08)"
    }, children: [
      /* @__PURE__ */ o.jsx("h3", { style: { marginBottom: "12px" }, children: "今天没有到期或新卡" }),
      /* @__PURE__ */ o.jsx("div", { style: { color: "var(--orca-color-text-2)", marginBottom: "20px" }, children: "请先创建或等待卡片到期，然后再次开始复习" }),
      t && /* @__PURE__ */ o.jsx(Kt, { variant: "solid", onClick: t, children: "关闭" })
    ] });
    return n ? /* @__PURE__ */ o.jsx("div", { style: {
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "24px"
    }, children: R }) : /* @__PURE__ */ o.jsx(Zo, { visible: !0, canClose: !0, onClose: t, children: R });
  }
  if (J) {
    const R = /* @__PURE__ */ o.jsxs("div", { className: "srs-session-complete-container", style: {
      backgroundColor: "var(--orca-color-bg-1)",
      borderRadius: "12px",
      padding: "48px",
      maxWidth: "500px",
      width: "100%",
      boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
      textAlign: "center"
    }, children: [
      /* @__PURE__ */ o.jsx("div", { style: {
        fontSize: "64px",
        marginBottom: "24px"
      }, children: "🎉" }),
      /* @__PURE__ */ o.jsx("h2", { style: {
        fontSize: "24px",
        fontWeight: "600",
        color: "var(--orca-color-text-1)",
        marginBottom: "16px"
      }, children: i ? `第 ${c} 轮复习结束！` : "本次复习结束！" }),
      /* @__PURE__ */ o.jsxs("div", { style: {
        fontSize: "16px",
        color: "var(--orca-color-text-2)",
        marginBottom: "32px",
        lineHeight: "1.6"
      }, children: [
        /* @__PURE__ */ o.jsxs("p", { children: [
          "共复习了 ",
          /* @__PURE__ */ o.jsx("strong", { style: { color: "var(--orca-color-primary-5)" }, children: y }),
          " 张卡片"
        ] }),
        /* @__PURE__ */ o.jsx("p", { style: { marginTop: "8px" }, children: "坚持复习，持续进步！" })
      ] }),
      /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "12px", justifyContent: "center" }, children: [
        i && l && /* @__PURE__ */ o.jsx(
          Kt,
          {
            variant: "outline",
            onClick: l,
            style: {
              padding: "12px 24px",
              fontSize: "16px"
            },
            children: "再复习一轮"
          }
        ),
        /* @__PURE__ */ o.jsx(
          Kt,
          {
            variant: "solid",
            onClick: ge,
            style: {
              padding: "12px 32px",
              fontSize: "16px"
            },
            children: "完成"
          }
        )
      ] })
    ] });
    return n ? /* @__PURE__ */ o.jsx("div", { style: {
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "24px"
    }, children: R }) : /* @__PURE__ */ o.jsx(
      Zo,
      {
        visible: !0,
        canClose: !0,
        onClose: t,
        className: "srs-session-complete-modal",
        children: R
      }
    );
  }
  return n ? /* @__PURE__ */ o.jsxs(
    "div",
    {
      ref: d,
      className: `srs-review-session-panel ${M ? "orca-maximized" : ""}`,
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        backgroundColor: "var(--orca-color-bg-0)"
      },
      children: [
        /* @__PURE__ */ o.jsx(
          "div",
          {
            className: "srs-review-progress-bar",
            contentEditable: !1,
            style: {
              height: "4px",
              backgroundColor: "var(--orca-color-bg-2)"
            },
            children: /* @__PURE__ */ o.jsx("div", { style: {
              height: "100%",
              width: `${x / j * 100}%`,
              backgroundColor: "var(--orca-color-primary-5)",
              transition: "width 0.3s ease"
            } })
          }
        ),
        /* @__PURE__ */ o.jsxs(
          "div",
          {
            className: "srs-review-header",
            contentEditable: !1,
            style: {
              padding: "12px 16px",
              borderBottom: "1px solid var(--orca-color-border-1)",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between"
            },
            children: [
              /* @__PURE__ */ o.jsxs("div", { contentEditable: !1, style: { userSelect: "none" }, children: [
                /* @__PURE__ */ o.jsxs("div", { style: {
                  fontSize: "14px",
                  color: "var(--orca-color-text-2)",
                  fontWeight: 500,
                  userSelect: "none",
                  pointerEvents: "none",
                  display: "flex",
                  alignItems: "center",
                  gap: "8px"
                }, children: [
                  i && /* @__PURE__ */ o.jsxs("span", { style: {
                    backgroundColor: "var(--orca-color-warning-1)",
                    color: "var(--orca-color-warning-6)",
                    padding: "2px 8px",
                    borderRadius: "4px",
                    fontSize: "12px",
                    fontWeight: 600
                  }, children: [
                    "重复复习 · 第 ",
                    c,
                    " 轮"
                  ] }),
                  /* @__PURE__ */ o.jsxs("span", { children: [
                    "卡片 ",
                    x + 1,
                    " / ",
                    j,
                    "（到期 ",
                    G.due,
                    " | 新卡 ",
                    G.fresh,
                    "）"
                  ] }),
                  T > 0 && /* @__PURE__ */ o.jsxs("span", { style: {
                    color: "var(--orca-color-primary-6)",
                    fontSize: "12px"
                  }, children: [
                    "+",
                    T,
                    " 新增"
                  ] })
                ] }),
                v && /* @__PURE__ */ o.jsx("div", { style: {
                  marginTop: "6px",
                  fontSize: "12px",
                  color: "var(--orca-color-text-2)",
                  opacity: 0.8
                }, children: v })
              ] }),
              /* @__PURE__ */ o.jsx(
                Kt,
                {
                  variant: "plain",
                  onClick: L,
                  title: "检查新到期卡片",
                  style: { marginLeft: "8px" },
                  children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-refresh" })
                }
              ),
              !1
            ]
          }
        ),
        /* @__PURE__ */ o.jsx("div", { style: { flex: 1, overflow: "auto", padding: "0" }, children: w ? /* @__PURE__ */ o.jsx(
          Xo,
          {
            front: w.front,
            back: w.back,
            onGrade: $e,
            onPostpone: Ae,
            onSuspend: Ee,
            onClose: t,
            onSkip: A,
            onPrevious: Y,
            canGoPrevious: ee,
            srsInfo: w.srs,
            isGrading: S,
            blockId: w.id,
            nextBlockId: B == null ? void 0 : B.id,
            onJumpToCard: xe,
            inSidePanel: !0,
            panelId: a,
            pluginName: s,
            clozeNumber: w.clozeNumber,
            directionType: w.directionType
          }
        ) : /* @__PURE__ */ o.jsx("div", { style: {
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          height: "100%",
          color: "var(--orca-color-text-2)"
        }, children: "加载中..." }) })
      ]
    }
  ) : /* @__PURE__ */ o.jsxs("div", { className: "srs-review-session", children: [
    /* @__PURE__ */ o.jsx("div", { contentEditable: !1, style: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      height: "4px",
      backgroundColor: "var(--orca-color-bg-2)",
      zIndex: 1e4
    }, children: /* @__PURE__ */ o.jsx("div", { style: {
      height: "100%",
      width: `${x / j * 100}%`,
      backgroundColor: "var(--orca-color-primary-5)",
      transition: "width 0.3s ease"
    } }) }),
    /* @__PURE__ */ o.jsxs("div", { contentEditable: !1, style: {
      position: "fixed",
      top: "12px",
      left: "50%",
      transform: "translateX(-50%)",
      padding: "8px 16px",
      backgroundColor: "var(--orca-color-bg-1)",
      borderRadius: "20px",
      fontSize: "14px",
      color: "var(--orca-color-text-2)",
      boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
      zIndex: 10001,
      display: "flex",
      alignItems: "center",
      gap: "8px"
    }, children: [
      i && /* @__PURE__ */ o.jsxs("span", { style: {
        backgroundColor: "var(--orca-color-warning-1)",
        color: "var(--orca-color-warning-6)",
        padding: "2px 8px",
        borderRadius: "4px",
        fontSize: "12px",
        fontWeight: 600
      }, children: [
        "重复复习 · 第 ",
        c,
        " 轮"
      ] }),
      /* @__PURE__ */ o.jsxs("span", { children: [
        "卡片 ",
        x + 1,
        " / ",
        j,
        "（到期 ",
        G.due,
        " | 新卡 ",
        G.fresh,
        "）"
      ] }),
      T > 0 && /* @__PURE__ */ o.jsxs("span", { style: {
        color: "var(--orca-color-primary-6)",
        fontSize: "12px"
      }, children: [
        "+",
        T,
        " 新增"
      ] })
    ] }),
    v && /* @__PURE__ */ o.jsx("div", { contentEditable: !1, style: {
      position: "fixed",
      top: "48px",
      left: "50%",
      transform: "translateX(-50%)",
      padding: "6px 12px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "12px",
      fontSize: "12px",
      color: "var(--orca-color-text-2)",
      boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
      zIndex: 10001
    }, children: v }),
    w ? /* @__PURE__ */ o.jsx(
      Xo,
      {
        front: w.front,
        back: w.back,
        onGrade: $e,
        onPostpone: Ae,
        onSuspend: Ee,
        onClose: t,
        onSkip: A,
        onPrevious: Y,
        canGoPrevious: ee,
        srsInfo: w.srs,
        isGrading: S,
        blockId: w.id,
        nextBlockId: B == null ? void 0 : B.id,
        onJumpToCard: xe,
        panelId: a,
        pluginName: s,
        clozeNumber: w.clozeNumber,
        directionType: w.directionType
      }
    ) : /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      height: "100vh",
      color: "var(--orca-color-text-2)"
    }, children: "加载中..." })
  ] });
}
let Ge = null;
function br(e, t, r) {
  Ge !== null && (console.log(`[repeatReviewManager] 清理旧的重复复习会话，来源块ID: ${Ge.sourceBlockId}`), Ge = null);
  const n = e.map((s) => ({ ...s })), a = {
    cards: [...e],
    originalCards: n,
    currentRound: 1,
    totalRounds: 1,
    isRepeatMode: !0,
    sourceBlockId: t,
    sourceType: r
  };
  return Ge = a, console.log(`[repeatReviewManager] 创建重复复习会话，卡片数: ${e.length}, 来源: ${r}, 块ID: ${t}`), a;
}
function Kn(e) {
  const t = e.originalCards.map((n) => ({ ...n })), r = {
    ...e,
    cards: t,
    currentRound: e.currentRound + 1,
    totalRounds: e.totalRounds + 1
  };
  return Ge = r, r;
}
function Gn() {
  return console.log(`[repeatReviewManager] 获取重复复习会话，当前会话: ${Ge ? `存在，卡片数 ${Ge.cards.length}` : "不存在"}`), Ge;
}
function Vr() {
  console.log("[repeatReviewManager] 清除重复复习会话"), Ge = null;
}
const Mi = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  clearRepeatReviewSession: Vr,
  createRepeatReviewSession: br,
  getRepeatReviewSession: Gn,
  resetCurrentRound: Kn
}, Symbol.toStringTag, { value: "Module" })), { useEffect: en, useState: tt } = window.React, { BlockShell: Ai, Button: Bi } = orca.components;
function Fi(e) {
  const {
    panelId: t,
    blockId: r,
    rndId: n,
    blockLevel: a,
    indentLevel: s,
    mirrorId: i,
    initiallyCollapsed: c,
    renderingMode: l
  } = e, [d, u] = tt([]), [f, x] = tt(!0), [h, y] = tt(null), [g, S] = tt("orca-srs"), [m, v] = tt(!1), [C, M] = tt(1), [b, P] = tt(null);
  en(() => {
    N();
  }, [r]), en(() => () => {
    console.log("[SRS Review Session Renderer] 组件卸载，清理重复复习会话"), Vr();
  }, []);
  const N = async () => {
    x(!0), y(null);
    try {
      const { getPluginName: D } = await Promise.resolve().then(() => He), _ = typeof D == "function" ? D() : "orca-srs";
      S(_);
      const j = Gn();
      if (j) {
        console.log(`[SRS Review Session Renderer] 使用重复复习会话，原始卡片数: ${j.cards.length}`);
        const { buildReviewQueueWithChildren: w } = await Promise.resolve().then(() => He), B = await w(j.cards, _);
        console.log(`[SRS Review Session Renderer] 展开子卡片后卡片数: ${B.length}`), u(B), v(!0), M(j.currentRound), P({ ...j, cards: B });
      } else {
        const {
          collectReviewCards: w,
          buildReviewQueueWithChildren: B,
          getReviewDeckFilter: J
        } = await Promise.resolve().then(() => He), G = await w(_), pe = typeof J == "function" ? J() : null, se = pe ? G.filter((ue) => ue.deck === pe) : G, k = await B(se, _);
        u(k), v(!1), M(1), P(null);
      }
    } catch (D) {
      console.error("[SRS Review Session Renderer] 加载复习队列失败:", D), y(D instanceof Error ? D.message : `${D}`), orca.notify("error", "加载复习队列失败", { title: "SRS 复习" });
    } finally {
      x(!1);
    }
  }, T = async () => {
    if (!b) return;
    const D = Kn(b), { buildReviewQueueWithChildren: _ } = await Promise.resolve().then(() => He), j = await _(D.cards, g);
    u(j), M(D.currentRound), P({ ...D, cards: j }), console.log(`[SRS Review Session Renderer] 开始第 ${D.currentRound} 轮复习，展开后卡片数: ${j.length}`);
  }, O = () => {
    m && Vr(), orca.nav.close(t);
  }, H = (D, _) => {
    _ ? orca.nav.openInLastPanel("block", { blockId: D }) : orca.nav.goTo("block", { blockId: D }, t);
  }, z = () => f ? /* @__PURE__ */ o.jsx("div", { style: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    fontSize: "14px",
    color: "var(--orca-color-text-2)"
  }, children: "加载复习队列中..." }) : h ? /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    padding: "24px",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center"
  }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: { color: "var(--orca-color-danger-5)" }, children: [
      "加载失败：",
      h
    ] }),
    /* @__PURE__ */ o.jsx(Bi, { variant: "solid", onClick: N, children: "重试" })
  ] }) : /* @__PURE__ */ o.jsx(ot, { componentName: "复习会话", errorTitle: "复习会话加载出错", children: /* @__PURE__ */ o.jsx(
    Ei,
    {
      cards: d,
      onClose: O,
      onJumpToCard: H,
      inSidePanel: !0,
      panelId: t,
      pluginName: g,
      isRepeatMode: m,
      currentRound: C,
      onRepeatRound: m ? T : void 0
    }
  ) });
  return /* @__PURE__ */ o.jsx(
    Ai,
    {
      panelId: t,
      blockId: r,
      rndId: n,
      mirrorId: i,
      blockLevel: a,
      indentLevel: s,
      initiallyCollapsed: c,
      renderingMode: l,
      reprClassName: "srs-repr-review-session",
      contentClassName: "srs-repr-review-session-content",
      contentJsx: z(),
      childrenJsx: null
    }
  );
}
function Jn() {
  const e = /* @__PURE__ */ new Date();
  return new Date(e.getFullYear(), e.getMonth(), e.getDate());
}
function Pi() {
  const e = Jn(), t = new Date(e);
  return t.setDate(t.getDate() + 1), t;
}
function Li(e, t) {
  if (t === "all")
    return e;
  if (t === "new")
    return e.filter((a) => a.isNew);
  const r = Jn(), n = Pi();
  switch (t) {
    case "overdue":
      return e.filter((a) => a.isNew ? !1 : a.srs.due < r);
    case "today":
      return e.filter((a) => {
        if (a.isNew) return !1;
        const s = a.srs.due;
        return s >= r && s < n;
      });
    case "future":
      return e.filter((a) => a.isNew ? !1 : a.srs.due >= n);
    default:
      return e;
  }
}
const { useRef: Wi, useEffect: Oi, useMemo: Hi } = window.React, { Block: Ii } = orca.components;
function Qn({ blockId: e, panelId: t }) {
  const r = Wi(null), n = Hi(() => `block-preview-${e}`, [e]);
  return Oi(() => {
    const a = r.current;
    if (!a) return;
    const s = `preview-${e}`;
    a.setAttribute("data-block-preview", s);
    const i = `style-preview-${e}`;
    if (document.getElementById(i)) return;
    const c = document.createElement("style");
    return c.id = i, c.textContent = `
      [data-block-preview="${s}"] .orca-block-children,
      [data-block-preview="${s}"] .orca-repr-children {
        display: none !important;
      }
      [data-block-preview="${s}"] .orca-block-handle,
      [data-block-preview="${s}"] .orca-block-folding-handle,
      [data-block-preview="${s}"] .orca-block-drag-handle,
      [data-block-preview="${s}"] .orca-repr-main-none-editable,
      [data-block-preview="${s}"] .orca-block-editor-sidetools {
        display: none !important;
      }
      [data-block-preview="${s}"] .orca-repr-main-content {
        font-size: 14px;
        line-height: 1.5;
      }
      [data-block-preview="${s}"] .orca-block-editor {
        background: transparent !important;
      }
      [data-block-preview="${s}"] .orca-block {
        margin: 0 !important;
        padding: 0 !important;
      }
    `, document.head.appendChild(c), () => {
      const l = document.getElementById(i);
      l && document.head.removeChild(l);
    };
  }, [e]), e ? /* @__PURE__ */ o.jsx("div", { ref: r, style: { minHeight: "20px" }, children: /* @__PURE__ */ o.jsx(
    Ii,
    {
      panelId: n,
      blockId: e,
      blockLevel: 0,
      indentLevel: 0,
      renderingMode: "normal"
    }
  ) }) : /* @__PURE__ */ o.jsx("div", { style: { color: "var(--orca-color-text-3)", fontSize: "12px" }, children: "无效的卡片" });
}
const { useState: tn, useMemo: rn } = window.React;
function bo({
  data: e,
  width: t = 400,
  height: r = 200,
  barColor: n = "var(--orca-color-primary-5)",
  showLabels: a = !0,
  showValues: s = !1,
  maxValue: i,
  formatValue: c = (u) => String(u),
  formatLabel: l = (u) => u,
  onBarClick: d
}) {
  const [u, f] = tn(null), [x, h] = tn(null), y = { top: 20, right: 20, bottom: a ? 40 : 20, left: 40 }, g = t - y.left - y.right, S = r - y.top - y.bottom, m = rn(() => {
    if (i !== void 0) return i;
    const T = Math.max(...e.map((O) => O.value), 0);
    return T === 0 ? 1 : T * 1.1;
  }, [e, i]), v = e.length, C = Math.min(8, g / v * 0.2), M = v > 0 ? (g - C * (v - 1)) / v : 0, b = rn(() => {
    const O = m / 5;
    return Array.from({ length: 6 }, (H, z) => Math.round(O * z));
  }, [m]), P = (T, O) => {
    var D;
    f(T);
    const H = O.target.getBoundingClientRect(), z = (D = O.currentTarget.closest("svg")) == null ? void 0 : D.getBoundingClientRect();
    z && h({
      x: H.left - z.left + H.width / 2,
      y: H.top - z.top - 10
    });
  }, N = () => {
    f(null), h(null);
  };
  return e.length === 0 ? /* @__PURE__ */ o.jsx("div", { style: {
    width: t,
    height: r,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "var(--orca-color-text-3)",
    fontSize: "14px"
  }, children: "暂无数据" }) : /* @__PURE__ */ o.jsxs("div", { style: { position: "relative", width: t, height: r }, children: [
    /* @__PURE__ */ o.jsxs("svg", { width: t, height: r, style: { overflow: "visible" }, children: [
      /* @__PURE__ */ o.jsx(
        "line",
        {
          x1: y.left,
          y1: y.top,
          x2: y.left,
          y2: r - y.bottom,
          stroke: "var(--orca-color-border-1)",
          strokeWidth: 1
        }
      ),
      b.map((T, O) => {
        const H = r - y.bottom - T / m * S;
        return /* @__PURE__ */ o.jsxs("g", { children: [
          /* @__PURE__ */ o.jsx(
            "line",
            {
              x1: y.left - 4,
              y1: H,
              x2: y.left,
              y2: H,
              stroke: "var(--orca-color-border-1)",
              strokeWidth: 1
            }
          ),
          /* @__PURE__ */ o.jsx(
            "line",
            {
              x1: y.left,
              y1: H,
              x2: t - y.right,
              y2: H,
              stroke: "var(--orca-color-border-1)",
              strokeWidth: 1,
              strokeDasharray: "2,2",
              opacity: 0.5
            }
          ),
          /* @__PURE__ */ o.jsx(
            "text",
            {
              x: y.left - 8,
              y: H,
              textAnchor: "end",
              dominantBaseline: "middle",
              fontSize: 10,
              fill: "var(--orca-color-text-3)",
              children: T
            }
          )
        ] }, O);
      }),
      /* @__PURE__ */ o.jsx(
        "line",
        {
          x1: y.left,
          y1: r - y.bottom,
          x2: t - y.right,
          y2: r - y.bottom,
          stroke: "var(--orca-color-border-1)",
          strokeWidth: 1
        }
      ),
      e.map((T, O) => {
        const H = y.left + O * (M + C), z = T.value / m * S, D = r - y.bottom - z, _ = u === O;
        return /* @__PURE__ */ o.jsxs("g", { children: [
          /* @__PURE__ */ o.jsx(
            "rect",
            {
              x: H,
              y: D,
              width: M,
              height: Math.max(z, 0),
              fill: T.color || n,
              opacity: _ ? 1 : 0.8,
              rx: 2,
              ry: 2,
              className: "srs-chart-bar-animated srs-chart-bar-hover",
              style: {
                cursor: d ? "pointer" : "default",
                animationDelay: `${O * 0.05}s`
              },
              onMouseEnter: (j) => P(O, j),
              onMouseLeave: N,
              onClick: () => d == null ? void 0 : d(T, O)
            }
          ),
          a && /* @__PURE__ */ o.jsx(
            "text",
            {
              x: H + M / 2,
              y: r - y.bottom + 16,
              textAnchor: "middle",
              fontSize: 10,
              fill: "var(--orca-color-text-3)",
              style: {
                maxWidth: M,
                overflow: "hidden",
                textOverflow: "ellipsis"
              },
              children: l(T.label)
            }
          ),
          s && T.value > 0 && /* @__PURE__ */ o.jsx(
            "text",
            {
              x: H + M / 2,
              y: D - 4,
              textAnchor: "middle",
              fontSize: 10,
              fill: "var(--orca-color-text-2)",
              children: c(T.value)
            }
          )
        ] }, O);
      })
    ] }),
    u !== null && x && /* @__PURE__ */ o.jsxs(
      "div",
      {
        className: "srs-chart-tooltip-animated",
        style: {
          position: "absolute",
          left: x.x,
          top: x.y,
          transform: "translate(-50%, -100%)",
          backgroundColor: "var(--orca-color-bg-4)",
          color: "var(--orca-color-text-1)",
          padding: "6px 10px",
          borderRadius: "4px",
          fontSize: "12px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
          pointerEvents: "none",
          whiteSpace: "nowrap",
          zIndex: 100
        },
        children: [
          /* @__PURE__ */ o.jsx("div", { style: { fontWeight: 500 }, children: e[u].label }),
          /* @__PURE__ */ o.jsx("div", { style: { color: "var(--orca-color-text-2)", marginTop: "2px" }, children: c(e[u].value) })
        ]
      }
    )
  ] });
}
const { useState: Ar, useMemo: Gt } = window.React;
function Xn({
  data: e,
  width: t = 400,
  height: r = 200,
  showLabels: n = !0,
  showLegend: a = !0,
  legendItems: s,
  maxValue: i,
  formatValue: c = (u) => String(u),
  formatLabel: l = (u) => u,
  onSegmentClick: d
}) {
  const [u, f] = Ar(null), [x, h] = Ar(null), [y, g] = Ar(null), S = a ? 30 : 0, m = { top: 20, right: 20, bottom: n ? 40 : 20, left: 40 }, v = t - m.left - m.right, C = r - m.top - m.bottom - S, M = Gt(() => e.map((_) => _.segments.reduce((j, w) => j + w.value, 0)), [e]), b = Gt(() => {
    if (i !== void 0) return i;
    const _ = Math.max(...M, 0);
    return _ === 0 ? 1 : _ * 1.1;
  }, [M, i]), P = e.length, N = Math.min(8, v / P * 0.2), T = P > 0 ? (v - N * (P - 1)) / P : 0, O = Gt(() => {
    const j = b / 5;
    return Array.from({ length: 6 }, (w, B) => Math.round(j * B));
  }, [b]), H = Gt(() => {
    if (s) return s;
    const _ = /* @__PURE__ */ new Map();
    return e.forEach((j) => {
      j.segments.forEach((w) => {
        _.has(w.key) || _.set(w.key, { label: w.label || w.key, color: w.color });
      });
    }), Array.from(_.entries()).map(([j, { label: w, color: B }]) => ({
      key: j,
      label: w,
      color: B
    }));
  }, [e, s]), z = (_, j, w) => {
    var G;
    f({ barIndex: _, segmentKey: j });
    const B = w.target.getBoundingClientRect(), J = (G = w.currentTarget.closest("svg")) == null ? void 0 : G.getBoundingClientRect();
    J && h({
      x: B.left - J.left + B.width / 2,
      y: B.top - J.top - 10
    }), g({
      label: e[_].label,
      segments: e[_].segments,
      total: M[_]
    });
  }, D = () => {
    f(null), h(null), g(null);
  };
  return e.length === 0 ? /* @__PURE__ */ o.jsx("div", { style: {
    width: t,
    height: r,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "var(--orca-color-text-3)",
    fontSize: "14px"
  }, children: "暂无数据" }) : /* @__PURE__ */ o.jsxs("div", { style: { position: "relative", width: t, height: r }, children: [
    /* @__PURE__ */ o.jsxs("svg", { width: t, height: r - S, style: { overflow: "visible" }, children: [
      /* @__PURE__ */ o.jsx(
        "line",
        {
          x1: m.left,
          y1: m.top,
          x2: m.left,
          y2: r - m.bottom - S,
          stroke: "var(--orca-color-border-1)",
          strokeWidth: 1
        }
      ),
      O.map((_, j) => {
        const w = r - m.bottom - S - _ / b * C;
        return /* @__PURE__ */ o.jsxs("g", { children: [
          /* @__PURE__ */ o.jsx(
            "line",
            {
              x1: m.left - 4,
              y1: w,
              x2: m.left,
              y2: w,
              stroke: "var(--orca-color-border-1)",
              strokeWidth: 1
            }
          ),
          /* @__PURE__ */ o.jsx(
            "line",
            {
              x1: m.left,
              y1: w,
              x2: t - m.right,
              y2: w,
              stroke: "var(--orca-color-border-1)",
              strokeWidth: 1,
              strokeDasharray: "2,2",
              opacity: 0.5
            }
          ),
          /* @__PURE__ */ o.jsx(
            "text",
            {
              x: m.left - 8,
              y: w,
              textAnchor: "end",
              dominantBaseline: "middle",
              fontSize: 10,
              fill: "var(--orca-color-text-3)",
              children: _
            }
          )
        ] }, j);
      }),
      /* @__PURE__ */ o.jsx(
        "line",
        {
          x1: m.left,
          y1: r - m.bottom - S,
          x2: t - m.right,
          y2: r - m.bottom - S,
          stroke: "var(--orca-color-border-1)",
          strokeWidth: 1
        }
      ),
      e.map((_, j) => {
        const w = m.left + j * (T + N);
        let B = r - m.bottom - S;
        return /* @__PURE__ */ o.jsxs("g", { children: [
          _.segments.map((J, G) => {
            const pe = J.value / b * C;
            B -= pe;
            const se = (u == null ? void 0 : u.barIndex) === j && (u == null ? void 0 : u.segmentKey) === J.key;
            return /* @__PURE__ */ o.jsx(
              "rect",
              {
                x: w,
                y: B,
                width: T,
                height: Math.max(pe, 0),
                fill: J.color,
                opacity: se ? 1 : 0.8,
                rx: G === _.segments.length - 1 ? 2 : 0,
                ry: G === _.segments.length - 1 ? 2 : 0,
                className: "srs-chart-bar-animated srs-chart-bar-hover",
                style: {
                  cursor: d ? "pointer" : "default",
                  animationDelay: `${j * 0.03 + G * 0.02}s`
                },
                onMouseEnter: (k) => z(j, J.key, k),
                onMouseLeave: D,
                onClick: () => d == null ? void 0 : d(_, J, j)
              },
              G
            );
          }),
          n && /* @__PURE__ */ o.jsx(
            "text",
            {
              x: w + T / 2,
              y: r - m.bottom - S + 16,
              textAnchor: "middle",
              fontSize: 10,
              fill: "var(--orca-color-text-3)",
              children: l(_.label)
            }
          )
        ] }, j);
      })
    ] }),
    a && H.length > 0 && /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      justifyContent: "center",
      gap: "16px",
      marginTop: "8px",
      flexWrap: "wrap"
    }, children: H.map((_) => /* @__PURE__ */ o.jsxs(
      "div",
      {
        style: {
          display: "flex",
          alignItems: "center",
          gap: "4px",
          fontSize: "12px",
          color: "var(--orca-color-text-2)"
        },
        children: [
          /* @__PURE__ */ o.jsx("div", { style: {
            width: "12px",
            height: "12px",
            backgroundColor: _.color,
            borderRadius: "2px"
          } }),
          /* @__PURE__ */ o.jsx("span", { children: _.label })
        ]
      },
      _.key
    )) }),
    y && x && /* @__PURE__ */ o.jsxs(
      "div",
      {
        className: "srs-chart-tooltip-animated",
        style: {
          position: "absolute",
          left: x.x,
          top: x.y,
          transform: "translate(-50%, -100%)",
          backgroundColor: "var(--orca-color-bg-4)",
          color: "var(--orca-color-text-1)",
          padding: "8px 12px",
          borderRadius: "4px",
          fontSize: "12px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
          pointerEvents: "none",
          whiteSpace: "nowrap",
          zIndex: 100
        },
        children: [
          /* @__PURE__ */ o.jsx("div", { style: { fontWeight: 500, marginBottom: "4px" }, children: y.label }),
          y.segments.map((_) => /* @__PURE__ */ o.jsxs(
            "div",
            {
              style: {
                display: "flex",
                alignItems: "center",
                gap: "6px",
                marginTop: "2px"
              },
              children: [
                /* @__PURE__ */ o.jsx("div", { style: {
                  width: "8px",
                  height: "8px",
                  backgroundColor: _.color,
                  borderRadius: "2px"
                } }),
                /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-text-2)" }, children: [
                  _.label || _.key,
                  ": ",
                  c(_.value)
                ] })
              ]
            },
            _.key
          )),
          /* @__PURE__ */ o.jsxs("div", { style: {
            marginTop: "4px",
            paddingTop: "4px",
            borderTop: "1px solid var(--orca-color-border-1)",
            color: "var(--orca-color-text-2)"
          }, children: [
            "总计: ",
            c(y.total)
          ] })
        ]
      }
    )
  ] });
}
const { useState: Ni, useMemo: on } = window.React;
function Yi(e, t, r, n, a, s) {
  const i = _t(e, t, r, s), c = _t(e, t, r, a), l = _t(e, t, n, s), d = _t(e, t, n, a), u = s - a <= 180 ? 0 : 1;
  return n === 0 ? [
    "M",
    e,
    t,
    "L",
    c.x,
    c.y,
    "A",
    r,
    r,
    0,
    u,
    1,
    i.x,
    i.y,
    "Z"
  ].join(" ") : [
    "M",
    i.x,
    i.y,
    "A",
    r,
    r,
    0,
    u,
    0,
    c.x,
    c.y,
    "L",
    d.x,
    d.y,
    "A",
    n,
    n,
    0,
    u,
    1,
    l.x,
    l.y,
    "Z"
  ].join(" ");
}
function _t(e, t, r, n) {
  const a = (n - 90) * Math.PI / 180;
  return {
    x: e + r * Math.cos(a),
    y: t + r * Math.sin(a)
  };
}
function Zn({
  data: e,
  width: t = 300,
  height: r = 300,
  innerRadius: n = 0,
  showLabels: a = !1,
  showLegend: s = !0,
  showPercentage: i = !0,
  formatValue: c = (d) => String(d),
  onSliceClick: l
}) {
  const [d, u] = Ni(null), f = on(() => e.reduce((b, P) => b + P.value, 0), [e]), x = s ? Math.ceil(e.length / 2) * 24 + 16 : 0, h = Math.min(t, r - x), y = t / 2, g = (r - x) / 2, S = h / 2 - 20, m = n > 0 ? Math.min(n, S * 0.8) : 0, v = on(() => {
    let b = 0;
    return e.map((P, N) => {
      const T = f > 0 ? P.value / f : 0, O = T * 360, H = b, z = b + O;
      b = z;
      const D = H + O / 2, _ = (S + m) / 2, j = _t(y, g, _, D);
      return {
        ...P,
        index: N,
        startAngle: H,
        endAngle: z,
        percentage: T,
        labelPos: j
      };
    });
  }, [e, f, y, g, S, m]), C = (b) => {
    u(b);
  }, M = () => {
    u(null);
  };
  return e.length === 0 || f === 0 ? /* @__PURE__ */ o.jsx("div", { style: {
    width: t,
    height: r,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "var(--orca-color-text-3)",
    fontSize: "14px"
  }, children: "暂无数据" }) : /* @__PURE__ */ o.jsxs("div", { style: { position: "relative", width: t, height: r }, children: [
    /* @__PURE__ */ o.jsxs("svg", { width: t, height: r - x, style: { overflow: "visible" }, children: [
      v.map((b) => {
        const P = d === b.index, N = P ? 1.05 : 1, T = P ? `translate(${y * (1 - N)}, ${g * (1 - N)}) scale(${N})` : void 0;
        return /* @__PURE__ */ o.jsxs("g", { transform: T, style: { transformOrigin: `${y}px ${g}px` }, children: [
          /* @__PURE__ */ o.jsx(
            "path",
            {
              d: Yi(
                y,
                g,
                S,
                m,
                b.startAngle,
                b.endAngle
              ),
              fill: b.color,
              opacity: P ? 1 : 0.85,
              className: "srs-chart-pie-slice srs-chart-pie-hover",
              style: {
                cursor: l ? "pointer" : "default",
                animationDelay: `${b.index * 0.1}s`
              },
              onMouseEnter: () => C(b.index),
              onMouseLeave: M,
              onClick: () => l == null ? void 0 : l(b, b.index)
            }
          ),
          a && b.percentage > 0.05 && /* @__PURE__ */ o.jsx(
            "text",
            {
              x: b.labelPos.x,
              y: b.labelPos.y,
              textAnchor: "middle",
              dominantBaseline: "middle",
              fontSize: 11,
              fill: "white",
              fontWeight: 500,
              style: { pointerEvents: "none" },
              children: i ? `${Math.round(b.percentage * 100)}%` : c(b.value)
            }
          )
        ] }, b.key);
      }),
      m > 0 && /* @__PURE__ */ o.jsxs("g", { children: [
        /* @__PURE__ */ o.jsx(
          "text",
          {
            x: y,
            y: g - 8,
            textAnchor: "middle",
            dominantBaseline: "middle",
            fontSize: 20,
            fontWeight: 600,
            fill: "var(--orca-color-text-1)",
            children: c(f)
          }
        ),
        /* @__PURE__ */ o.jsx(
          "text",
          {
            x: y,
            y: g + 12,
            textAnchor: "middle",
            dominantBaseline: "middle",
            fontSize: 12,
            fill: "var(--orca-color-text-3)",
            children: "总计"
          }
        )
      ] })
    ] }),
    s && /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      flexWrap: "wrap",
      justifyContent: "center",
      gap: "8px 16px",
      marginTop: "8px",
      padding: "0 8px"
    }, children: e.map((b, P) => {
      const N = f > 0 ? (b.value / f * 100).toFixed(1) : "0", T = d === P;
      return /* @__PURE__ */ o.jsxs(
        "div",
        {
          style: {
            display: "flex",
            alignItems: "center",
            gap: "6px",
            fontSize: "12px",
            color: T ? "var(--orca-color-text-1)" : "var(--orca-color-text-2)",
            cursor: l ? "pointer" : "default",
            transition: "color 0.15s ease"
          },
          onMouseEnter: () => C(P),
          onMouseLeave: M,
          onClick: () => l == null ? void 0 : l(b, P),
          children: [
            /* @__PURE__ */ o.jsx("div", { style: {
              width: "12px",
              height: "12px",
              backgroundColor: b.color,
              borderRadius: "2px",
              flexShrink: 0
            } }),
            /* @__PURE__ */ o.jsx("span", { children: b.label || b.key }),
            /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-text-3)" }, children: [
              c(b.value),
              " (",
              N,
              "%)"
            ] })
          ]
        },
        b.key
      );
    }) }),
    d !== null && /* @__PURE__ */ o.jsxs(
      "div",
      {
        className: "srs-chart-tooltip-animated",
        style: {
          position: "absolute",
          left: y,
          top: g - S - 40,
          transform: "translateX(-50%)",
          backgroundColor: "var(--orca-color-bg-4)",
          color: "var(--orca-color-text-1)",
          padding: "8px 12px",
          borderRadius: "4px",
          fontSize: "12px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
          pointerEvents: "none",
          whiteSpace: "nowrap",
          zIndex: 100
        },
        children: [
          /* @__PURE__ */ o.jsxs("div", { style: {
            display: "flex",
            alignItems: "center",
            gap: "6px"
          }, children: [
            /* @__PURE__ */ o.jsx("div", { style: {
              width: "10px",
              height: "10px",
              backgroundColor: e[d].color,
              borderRadius: "2px"
            } }),
            /* @__PURE__ */ o.jsx("span", { style: { fontWeight: 500 }, children: e[d].label || e[d].key })
          ] }),
          /* @__PURE__ */ o.jsxs("div", { style: { marginTop: "4px", color: "var(--orca-color-text-2)" }, children: [
            c(e[d].value),
            " (",
            (e[d].value / f * 100).toFixed(1),
            "%)"
          ] })
        ]
      }
    )
  ] });
}
const { useState: nn, useMemo: kt } = window.React;
function Ui({
  data: e,
  width: t = 400,
  height: r = 200,
  lineColor: n = "var(--orca-color-primary-5)",
  fillColor: a = "var(--orca-color-primary-2)",
  showArea: s = !0,
  showDots: i = !0,
  showLabels: c = !0,
  showValues: l = !1,
  maxValue: d,
  formatValue: u = (h) => String(h),
  formatLabel: f = (h) => h,
  onPointClick: x
}) {
  const [h, y] = nn(null), [g, S] = nn(null), m = { top: 20, right: 20, bottom: c ? 40 : 20, left: 50 }, v = t - m.left - m.right, C = r - m.top - m.bottom, M = kt(() => {
    if (d !== void 0) return d;
    const z = Math.max(...e.map((D) => D.value), 0);
    return z === 0 ? 1 : z * 1.1;
  }, [e, d]), b = kt(() => {
    if (e.length === 0) return [];
    const z = e.length > 1 ? v / (e.length - 1) : 0;
    return e.map((D, _) => ({
      ...D,
      x: m.left + _ * z,
      y: r - m.bottom - D.value / M * C
    }));
  }, [e, v, C, M, m, r]), P = kt(() => b.length === 0 ? "" : b.map((z, D) => `${D === 0 ? "M" : "L"} ${z.x} ${z.y}`).join(" "), [b]), N = kt(() => {
    if (b.length === 0) return "";
    const z = r - m.bottom;
    return `${P} L ${b[b.length - 1].x} ${z} L ${b[0].x} ${z} Z`;
  }, [P, b, r, m.bottom]), T = kt(() => {
    const D = M / 5;
    return Array.from({ length: 6 }, (_, j) => Math.round(D * j));
  }, [M]), O = (z, D) => {
    y(z);
    const _ = b[z];
    S({ x: _.x, y: _.y - 10 });
  }, H = () => {
    y(null), S(null);
  };
  return e.length === 0 ? /* @__PURE__ */ o.jsx("div", { style: {
    width: t,
    height: r,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "var(--orca-color-text-3)",
    fontSize: "14px"
  }, children: "暂无数据" }) : /* @__PURE__ */ o.jsxs("div", { style: { position: "relative", width: t, height: r }, children: [
    /* @__PURE__ */ o.jsxs("svg", { width: t, height: r, style: { overflow: "visible" }, children: [
      /* @__PURE__ */ o.jsx(
        "line",
        {
          x1: m.left,
          y1: m.top,
          x2: m.left,
          y2: r - m.bottom,
          stroke: "var(--orca-color-border-1)",
          strokeWidth: 1
        }
      ),
      T.map((z, D) => {
        const _ = r - m.bottom - z / M * C;
        return /* @__PURE__ */ o.jsxs("g", { children: [
          /* @__PURE__ */ o.jsx(
            "line",
            {
              x1: m.left - 4,
              y1: _,
              x2: m.left,
              y2: _,
              stroke: "var(--orca-color-border-1)",
              strokeWidth: 1
            }
          ),
          /* @__PURE__ */ o.jsx(
            "line",
            {
              x1: m.left,
              y1: _,
              x2: t - m.right,
              y2: _,
              stroke: "var(--orca-color-border-1)",
              strokeWidth: 1,
              strokeDasharray: "2,2",
              opacity: 0.5
            }
          ),
          /* @__PURE__ */ o.jsx(
            "text",
            {
              x: m.left - 8,
              y: _,
              textAnchor: "end",
              dominantBaseline: "middle",
              fontSize: 10,
              fill: "var(--orca-color-text-3)",
              children: z
            }
          )
        ] }, D);
      }),
      /* @__PURE__ */ o.jsx(
        "line",
        {
          x1: m.left,
          y1: r - m.bottom,
          x2: t - m.right,
          y2: r - m.bottom,
          stroke: "var(--orca-color-border-1)",
          strokeWidth: 1
        }
      ),
      s && /* @__PURE__ */ o.jsx(
        "path",
        {
          d: N,
          fill: a,
          className: "srs-chart-line-area"
        }
      ),
      /* @__PURE__ */ o.jsx(
        "path",
        {
          d: P,
          fill: "none",
          stroke: n,
          strokeWidth: 2,
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: "srs-chart-line-path"
        }
      ),
      i && b.map((z, D) => {
        const _ = h === D;
        return /* @__PURE__ */ o.jsxs("g", { children: [
          /* @__PURE__ */ o.jsx(
            "circle",
            {
              cx: z.x,
              cy: z.y,
              r: _ ? 6 : 4,
              fill: n,
              stroke: "var(--orca-color-bg-1)",
              strokeWidth: 2,
              className: "srs-chart-line-dot",
              style: {
                cursor: x ? "pointer" : "default",
                animationDelay: `${0.5 + D * 0.03}s`
              },
              onMouseEnter: (j) => O(D),
              onMouseLeave: H,
              onClick: () => x == null ? void 0 : x(z, D)
            }
          ),
          c && /* @__PURE__ */ o.jsx(
            "text",
            {
              x: z.x,
              y: r - m.bottom + 16,
              textAnchor: "middle",
              fontSize: 10,
              fill: "var(--orca-color-text-3)",
              children: f(z.label)
            }
          ),
          l && /* @__PURE__ */ o.jsx(
            "text",
            {
              x: z.x,
              y: z.y - 10,
              textAnchor: "middle",
              fontSize: 10,
              fill: "var(--orca-color-text-2)",
              children: u(z.value)
            }
          )
        ] }, D);
      }),
      h !== null && /* @__PURE__ */ o.jsx(
        "line",
        {
          x1: b[h].x,
          y1: m.top,
          x2: b[h].x,
          y2: r - m.bottom,
          stroke: n,
          strokeWidth: 1,
          strokeDasharray: "4,4",
          opacity: 0.5
        }
      )
    ] }),
    h !== null && g && /* @__PURE__ */ o.jsxs(
      "div",
      {
        className: "srs-chart-tooltip-animated",
        style: {
          position: "absolute",
          left: g.x,
          top: g.y,
          transform: "translate(-50%, -100%)",
          backgroundColor: "var(--orca-color-bg-4)",
          color: "var(--orca-color-text-1)",
          padding: "6px 10px",
          borderRadius: "4px",
          fontSize: "12px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
          pointerEvents: "none",
          whiteSpace: "nowrap",
          zIndex: 100
        },
        children: [
          /* @__PURE__ */ o.jsx("div", { style: { fontWeight: 500 }, children: e[h].label }),
          /* @__PURE__ */ o.jsx("div", { style: { color: "var(--orca-color-text-2)", marginTop: "2px" }, children: u(e[h].value) })
        ]
      }
    )
  ] });
}
const { useState: Fe, useEffect: qi, useCallback: Br, useMemo: Rc } = window.React, { Button: an } = orca.components, Vi = [
  { key: "1month", label: "1个月" },
  { key: "3months", label: "3个月" },
  { key: "1year", label: "1年" },
  { key: "all", label: "全部" }
];
function Kr(e) {
  if (e < 6e4)
    return `${Math.round(e / 1e3)}秒`;
  if (e < 36e5)
    return `${Math.round(e / 6e4)}分钟`;
  const t = Math.floor(e / 36e5), r = Math.round(e % 36e5 / 6e4);
  return r > 0 ? `${t}小时${r}分钟` : `${t}小时`;
}
function ir(e) {
  return `${e.getMonth() + 1}/${e.getDate()}`;
}
function Ki({ value: e, onChange: t }) {
  return /* @__PURE__ */ o.jsx("div", { style: {
    display: "flex",
    gap: "8px",
    flexWrap: "wrap"
  }, children: Vi.map((r) => /* @__PURE__ */ o.jsx(
    "button",
    {
      onClick: () => t(r.key),
      style: {
        padding: "6px 12px",
        borderRadius: "16px",
        border: "1px solid",
        borderColor: e === r.key ? "var(--orca-color-primary-5)" : "var(--orca-color-border-1)",
        backgroundColor: e === r.key ? "var(--orca-color-primary-1)" : "transparent",
        color: e === r.key ? "var(--orca-color-primary-6)" : "var(--orca-color-text-2)",
        fontSize: "13px",
        cursor: "pointer",
        transition: "all 0.2s ease"
      },
      children: r.label
    },
    r.key
  )) });
}
function Gi({ decks: e, selectedDeck: t, onChange: r }) {
  return /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    alignItems: "center",
    gap: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "13px", color: "var(--orca-color-text-2)" }, children: "牌组:" }),
    /* @__PURE__ */ o.jsxs(
      "select",
      {
        value: t || "",
        onChange: (n) => r(n.target.value || void 0),
        style: {
          padding: "6px 12px",
          borderRadius: "6px",
          border: "1px solid var(--orca-color-border-1)",
          backgroundColor: "var(--orca-color-bg-1)",
          color: "var(--orca-color-text-1)",
          fontSize: "13px",
          cursor: "pointer",
          minWidth: "120px"
        },
        children: [
          /* @__PURE__ */ o.jsx("option", { value: "", children: "全部牌组" }),
          e.map((n) => /* @__PURE__ */ o.jsx("option", { value: n.name, children: n.name }, n.name))
        ]
      }
    )
  ] });
}
function Ji({ stats: e, isLoading: t }) {
  if (t)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "加载中..." });
  if (!e)
    return null;
  const { reviewedCount: r, newLearnedCount: n, relearnedCount: a, totalTime: s, gradeDistribution: i } = e;
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "16px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("h3", { style: {
      margin: "0 0 12px 0",
      fontSize: "15px",
      fontWeight: 600,
      color: "var(--orca-color-text-1)"
    }, children: "今日统计" }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(100px, 1fr))",
      gap: "12px"
    }, children: [
      /* @__PURE__ */ o.jsx(Jt, { label: "已复习", value: r, color: "var(--orca-color-primary-6)" }),
      /* @__PURE__ */ o.jsx(Jt, { label: "新学", value: n, color: "var(--orca-color-success-6)" }),
      /* @__PURE__ */ o.jsx(Jt, { label: "重学", value: a, color: "var(--orca-color-danger-6)" }),
      /* @__PURE__ */ o.jsx(Jt, { label: "复习时间", value: Kr(s) })
    ] }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      marginTop: "16px",
      paddingTop: "12px",
      borderTop: "1px solid var(--orca-color-border-1)"
    }, children: [
      /* @__PURE__ */ o.jsx("div", { style: {
        fontSize: "13px",
        color: "var(--orca-color-text-2)",
        marginBottom: "8px"
      }, children: "评分分布" }),
      /* @__PURE__ */ o.jsxs("div", { style: {
        display: "flex",
        gap: "16px",
        flexWrap: "wrap"
      }, children: [
        /* @__PURE__ */ o.jsx(Qt, { label: "Again", value: i.again, color: "#ef4444" }),
        /* @__PURE__ */ o.jsx(Qt, { label: "Hard", value: i.hard, color: "#f97316" }),
        /* @__PURE__ */ o.jsx(Qt, { label: "Good", value: i.good, color: "#22c55e" }),
        /* @__PURE__ */ o.jsx(Qt, { label: "Easy", value: i.easy, color: "#3b82f6" })
      ] })
    ] })
  ] });
}
function Jt({ label: e, value: t, color: r }) {
  return /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "8px",
    backgroundColor: "var(--orca-color-bg-1)",
    borderRadius: "6px"
  }, children: [
    /* @__PURE__ */ o.jsx("div", { style: {
      fontSize: "20px",
      fontWeight: 600,
      color: r || "var(--orca-color-text-1)"
    }, children: t }),
    /* @__PURE__ */ o.jsx("div", { style: {
      fontSize: "12px",
      color: "var(--orca-color-text-3)",
      marginTop: "4px"
    }, children: e })
  ] });
}
function Qt({ label: e, value: t, color: r }) {
  return /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    alignItems: "center",
    gap: "6px"
  }, children: [
    /* @__PURE__ */ o.jsx("div", { style: {
      width: "10px",
      height: "10px",
      backgroundColor: r,
      borderRadius: "2px"
    } }),
    /* @__PURE__ */ o.jsxs("span", { style: { fontSize: "13px", color: "var(--orca-color-text-2)" }, children: [
      e,
      ": ",
      t
    ] })
  ] });
}
function Qi({ forecast: e, isLoading: t }) {
  if (t)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "加载中..." });
  if (!e || e.days.length === 0)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "暂无预测数据" });
  const r = e.days.map((a) => ({
    label: ir(a.date),
    segments: [
      { key: "review", value: a.reviewDue, color: "#22c55e", label: "复习" },
      { key: "new", value: a.newAvailable, color: "#3b82f6", label: "新卡" }
    ]
  })), n = e.days.map((a) => ({
    label: ir(a.date),
    value: a.cumulative
  }));
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "16px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("h3", { style: {
      margin: "0 0 12px 0",
      fontSize: "15px",
      fontWeight: 600,
      color: "var(--orca-color-text-1)"
    }, children: "未来30天到期预测" }),
    /* @__PURE__ */ o.jsx("div", { style: { marginBottom: "16px" }, children: /* @__PURE__ */ o.jsx(
      Xn,
      {
        data: r,
        width: 600,
        height: 200,
        showLabels: !0,
        showLegend: !0,
        legendItems: [
          { key: "review", label: "复习卡", color: "#22c55e" },
          { key: "new", label: "新卡", color: "#3b82f6" }
        ]
      }
    ) }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      marginTop: "16px",
      paddingTop: "12px",
      borderTop: "1px solid var(--orca-color-border-1)"
    }, children: [
      /* @__PURE__ */ o.jsx("div", { style: {
        fontSize: "13px",
        color: "var(--orca-color-text-2)",
        marginBottom: "8px"
      }, children: "累计到期趋势" }),
      /* @__PURE__ */ o.jsx(
        Ui,
        {
          data: n,
          width: 600,
          height: 150,
          lineColor: "var(--orca-color-warning-5)",
          fillColor: "var(--orca-color-warning-2)",
          showArea: !0,
          showDots: !1,
          showLabels: !1
        }
      )
    ] })
  ] });
}
function Xi({ history: e, isLoading: t }) {
  if (t)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "加载中..." });
  if (!e || e.days.length === 0)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "暂无复习历史" });
  const r = e.days.map((n) => ({
    label: ir(n.date),
    segments: [
      { key: "again", value: n.again, color: "#ef4444", label: "Again" },
      { key: "hard", value: n.hard, color: "#f97316", label: "Hard" },
      { key: "good", value: n.good, color: "#22c55e", label: "Good" },
      { key: "easy", value: n.easy, color: "#3b82f6", label: "Easy" }
    ]
  }));
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "16px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("h3", { style: {
      margin: "0 0 12px 0",
      fontSize: "15px",
      fontWeight: 600,
      color: "var(--orca-color-text-1)"
    }, children: "复习历史" }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      gap: "16px",
      marginBottom: "12px",
      fontSize: "13px",
      color: "var(--orca-color-text-2)"
    }, children: [
      /* @__PURE__ */ o.jsxs("span", { children: [
        "总复习: ",
        e.totalReviews,
        " 次"
      ] }),
      /* @__PURE__ */ o.jsxs("span", { children: [
        "日均: ",
        e.averagePerDay.toFixed(1),
        " 次"
      ] })
    ] }),
    /* @__PURE__ */ o.jsx(
      Xn,
      {
        data: r,
        width: 600,
        height: 200,
        showLabels: !0,
        showLegend: !0,
        legendItems: [
          { key: "again", label: "Again", color: "#ef4444" },
          { key: "hard", label: "Hard", color: "#f97316" },
          { key: "good", label: "Good", color: "#22c55e" },
          { key: "easy", label: "Easy", color: "#3b82f6" }
        ]
      }
    )
  ] });
}
function Zi({ distribution: e, isLoading: t, onSliceClick: r }) {
  if (t)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "加载中..." });
  if (!e || e.total === 0)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "暂无卡片数据" });
  const n = [
    { key: "new", value: e.new, color: "#3b82f6", label: "新卡" },
    { key: "learning", value: e.learning, color: "#f97316", label: "学习中" },
    { key: "review", value: e.review, color: "#22c55e", label: "已掌握" },
    { key: "suspended", value: e.suspended, color: "#9ca3af", label: "暂停" }
  ].filter((a) => a.value > 0);
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "16px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("h3", { style: {
      margin: "0 0 12px 0",
      fontSize: "15px",
      fontWeight: 600,
      color: "var(--orca-color-text-1)"
    }, children: "卡片状态分布" }),
    /* @__PURE__ */ o.jsx(
      Zn,
      {
        data: n,
        width: 300,
        height: 280,
        innerRadius: 50,
        showLegend: !0,
        showPercentage: !0,
        onSliceClick: r ? (a) => r(a.key) : void 0
      }
    )
  ] });
}
function el({ stats: e, isLoading: t }) {
  if (t)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "加载中..." });
  if (!e || e.dailyTime.length === 0)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "暂无复习时间数据" });
  const r = e.dailyTime.map((n) => ({
    label: ir(n.date),
    value: Math.round(n.time / 6e4)
    // 转换为分钟
  }));
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "16px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("h3", { style: {
      margin: "0 0 12px 0",
      fontSize: "15px",
      fontWeight: 600,
      color: "var(--orca-color-text-1)"
    }, children: "复习时间统计" }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      gap: "16px",
      marginBottom: "12px",
      fontSize: "13px",
      color: "var(--orca-color-text-2)"
    }, children: [
      /* @__PURE__ */ o.jsxs("span", { children: [
        "总时间: ",
        Kr(e.totalTime)
      ] }),
      /* @__PURE__ */ o.jsxs("span", { children: [
        "日均: ",
        Kr(e.averagePerDay)
      ] })
    ] }),
    /* @__PURE__ */ o.jsx(
      bo,
      {
        data: r,
        width: 600,
        height: 180,
        barColor: "var(--orca-color-primary-5)",
        showLabels: !0,
        formatValue: (n) => `${n}分钟`
      }
    )
  ] });
}
function tl({ distribution: e, isLoading: t }) {
  if (t)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "加载中..." });
  if (!e || e.buckets.every((n) => n.count === 0))
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "暂无间隔数据" });
  const r = e.buckets.map((n) => ({
    label: n.label,
    value: n.count
  }));
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "16px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("h3", { style: {
      margin: "0 0 12px 0",
      fontSize: "15px",
      fontWeight: 600,
      color: "var(--orca-color-text-1)"
    }, children: "卡片间隔分布" }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      gap: "16px",
      marginBottom: "12px",
      fontSize: "13px",
      color: "var(--orca-color-text-2)"
    }, children: [
      /* @__PURE__ */ o.jsxs("span", { children: [
        "平均间隔: ",
        e.averageInterval.toFixed(1),
        " 天"
      ] }),
      /* @__PURE__ */ o.jsxs("span", { children: [
        "最大间隔: ",
        e.maxInterval,
        " 天"
      ] })
    ] }),
    /* @__PURE__ */ o.jsx(
      bo,
      {
        data: r,
        width: 400,
        height: 180,
        barColor: "var(--orca-color-success-5)",
        showLabels: !0,
        formatValue: (n) => `${n}张`
      }
    )
  ] });
}
function rl({ stats: e, isLoading: t }) {
  if (t)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "加载中..." });
  if (!e || e.total === 0)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "暂无答题数据" });
  const r = [
    { key: "again", value: e.again, color: "#ef4444", label: "Again" },
    { key: "hard", value: e.hard, color: "#f97316", label: "Hard" },
    { key: "good", value: e.good, color: "#22c55e", label: "Good" },
    { key: "easy", value: e.easy, color: "#3b82f6", label: "Easy" }
  ].filter((n) => n.value > 0);
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "16px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("h3", { style: {
      margin: "0 0 12px 0",
      fontSize: "15px",
      fontWeight: 600,
      color: "var(--orca-color-text-1)"
    }, children: "答题按钮统计" }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      gap: "16px",
      marginBottom: "12px",
      fontSize: "13px",
      color: "var(--orca-color-text-2)"
    }, children: [
      /* @__PURE__ */ o.jsxs("span", { children: [
        "总答题: ",
        e.total,
        " 次"
      ] }),
      /* @__PURE__ */ o.jsxs("span", { children: [
        "正确率: ",
        (e.correctRate * 100).toFixed(1),
        "%"
      ] })
    ] }),
    /* @__PURE__ */ o.jsx(
      Zn,
      {
        data: r,
        width: 300,
        height: 250,
        innerRadius: 0,
        showLegend: !0,
        showPercentage: !0
      }
    )
  ] });
}
function ol({ distribution: e, isLoading: t }) {
  if (t)
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "加载中..." });
  if (!e || e.buckets.every((n) => n.count === 0))
    return /* @__PURE__ */ o.jsx("div", { style: {
      padding: "16px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      textAlign: "center",
      color: "var(--orca-color-text-3)"
    }, children: "暂无难度数据" });
  const r = e.buckets.map((n) => ({
    label: n.label,
    value: n.count
  }));
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "16px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("h3", { style: {
      margin: "0 0 12px 0",
      fontSize: "15px",
      fontWeight: 600,
      color: "var(--orca-color-text-1)"
    }, children: "卡片难度分布" }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      gap: "16px",
      marginBottom: "12px",
      fontSize: "13px",
      color: "var(--orca-color-text-2)"
    }, children: [
      /* @__PURE__ */ o.jsxs("span", { children: [
        "平均难度: ",
        e.averageDifficulty.toFixed(2)
      ] }),
      /* @__PURE__ */ o.jsxs("span", { children: [
        "范围: ",
        e.minDifficulty.toFixed(1),
        " - ",
        e.maxDifficulty.toFixed(1)
      ] })
    ] }),
    /* @__PURE__ */ o.jsx(
      bo,
      {
        data: r,
        width: 400,
        height: 180,
        barColor: "var(--orca-color-warning-5)",
        showLabels: !0,
        formatValue: (n) => `${n}张`
      }
    )
  ] });
}
function nl({ panelId: e, pluginName: t, onBack: r, decks: n }) {
  const [a, s] = Fe("1month"), [i, c] = Fe(void 0), [l, d] = Fe(!0), [u, f] = Fe(null), [x, h] = Fe(null), [y, g] = Fe(null), [S, m] = Fe(null), [v, C] = Fe(null), [M, b] = Fe(null), [P, N] = Fe(null), [T, O] = Fe(null), [H, z] = Fe(!1), D = Br(async (w = !1) => {
    d(!0), w && z(!0);
    try {
      const {
        getTodayStatistics: B,
        getFutureForecast: J,
        getReviewHistory: G,
        getCardStateDistribution: pe,
        getReviewTimeStats: se,
        getIntervalDistribution: k,
        getAnswerButtonStats: ue,
        getDifficultyDistribution: Ce,
        getStatisticsPreferences: $e,
        saveStatisticsPreferences: Ae,
        clearStatisticsCache: Ee
      } = await Promise.resolve().then(() => tr);
      w && Ee();
      const A = await $e(t);
      s(A.timeRange), A.selectedDeck && c(A.selectedDeck);
      const [
        L,
        Y,
        ee,
        xe,
        ge,
        R,
        W,
        Q
      ] = await Promise.all([
        B(t, i),
        J(t, 30, i),
        G(t, a, i),
        pe(t, i),
        se(t, a, i),
        k(t, i),
        ue(t, a, i),
        Ce(t, i)
      ]);
      f(L), h(Y), g(ee), m(xe), C(ge), b(R), N(W), O(Q);
    } catch (B) {
      console.error(`[${t}] 加载统计数据失败:`, B);
    } finally {
      d(!1), z(!1);
    }
  }, [t, a, i]);
  qi(() => {
    D();
  }, [D]);
  const _ = Br(async (w) => {
    s(w);
    try {
      const { saveTimeRangePreference: B } = await Promise.resolve().then(() => tr);
      await B(t, w);
    } catch (B) {
      console.error(`[${t}] 保存时间范围偏好失败:`, B);
    }
  }, [t]), j = Br(async (w) => {
    c(w);
    try {
      const { saveSelectedDeckPreference: B } = await Promise.resolve().then(() => tr);
      await B(t, w);
    } catch (B) {
      console.error(`[${t}] 保存牌组偏好失败:`, B);
    }
  }, [t]);
  return /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
    padding: "16px",
    height: "100%",
    overflow: "auto"
  }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      gap: "12px",
      flexWrap: "wrap"
    }, children: [
      /* @__PURE__ */ o.jsx(an, { variant: "plain", onClick: r, style: { fontSize: "13px", padding: "6px 12px" }, children: "← 返回" }),
      /* @__PURE__ */ o.jsx("div", { style: {
        fontSize: "16px",
        fontWeight: 600,
        color: "var(--orca-color-text-1)",
        flex: 1
      }, children: "学习统计" }),
      /* @__PURE__ */ o.jsxs(
        an,
        {
          variant: "plain",
          onClick: () => !H && void D(!0),
          style: {
            fontSize: "13px",
            padding: "6px 12px",
            opacity: H ? 0.6 : 1,
            cursor: H ? "not-allowed" : "pointer"
          },
          title: "刷新数据（清除缓存）",
          children: [
            /* @__PURE__ */ o.jsx(
              "i",
              {
                className: `ti ti-refresh ${H ? "srs-refresh-spinning" : ""}`,
                style: { marginRight: "4px" }
              }
            ),
            H ? "刷新中..." : "刷新"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      gap: "16px",
      flexWrap: "wrap",
      padding: "12px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px"
    }, children: [
      /* @__PURE__ */ o.jsx(Ki, { value: a, onChange: _ }),
      /* @__PURE__ */ o.jsx("div", { style: { width: "1px", height: "24px", backgroundColor: "var(--orca-color-border-1)" } }),
      /* @__PURE__ */ o.jsx(Gi, { decks: n, selectedDeck: i, onChange: j })
    ] }),
    /* @__PURE__ */ o.jsx(Ji, { stats: u, isLoading: l }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(350px, 1fr))",
      gap: "16px"
    }, children: [
      /* @__PURE__ */ o.jsx(Zi, { distribution: S, isLoading: l }),
      /* @__PURE__ */ o.jsx(rl, { stats: P, isLoading: l })
    ] }),
    /* @__PURE__ */ o.jsx(Qi, { forecast: x, isLoading: l }),
    /* @__PURE__ */ o.jsx(Xi, { history: y, isLoading: l }),
    /* @__PURE__ */ o.jsx(el, { stats: v, isLoading: l }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(350px, 1fr))",
      gap: "16px"
    }, children: [
      /* @__PURE__ */ o.jsx(tl, { distribution: M, isLoading: l }),
      /* @__PURE__ */ o.jsx(ol, { distribution: T, isLoading: l })
    ] })
  ] });
}
const { useState: Fr, useEffect: al, useCallback: Pr, useMemo: sn } = window.React, { Button: ln } = orca.components;
function sl(e) {
  switch (e) {
    case "high_again_rate":
      return "频繁遗忘";
    case "high_lapses":
      return "遗忘次数多";
    case "high_difficulty":
      return "难度较高";
    case "multiple":
      return "多重困难";
  }
}
function cn(e) {
  switch (e) {
    case "high_again_rate":
      return "#ef4444";
    case "high_lapses":
      return "#f59e0b";
    case "high_difficulty":
      return "#8b5cf6";
    case "multiple":
      return "#dc2626";
  }
}
function il(e) {
  switch (e) {
    case "high_again_rate":
      return "ti-alert-triangle";
    case "high_lapses":
      return "ti-repeat";
    case "high_difficulty":
      return "ti-flame";
    case "multiple":
      return "ti-alert-octagon";
  }
}
function ll({ info: e, panelId: t, onCardClick: r }) {
  const { card: n, reason: a, recentAgainCount: s, totalLapses: i, difficulty: c } = e, l = () => {
    r(n.id);
  };
  return /* @__PURE__ */ o.jsxs(
    "div",
    {
      style: {
        border: "1px solid var(--orca-color-border-1)",
        borderRadius: "8px",
        padding: "12px",
        backgroundColor: "var(--orca-color-bg-1)",
        display: "flex",
        flexDirection: "column",
        gap: "8px",
        cursor: "pointer",
        transition: "all 0.2s ease"
      },
      onClick: l,
      onMouseEnter: (d) => {
        d.currentTarget.style.backgroundColor = "var(--orca-color-bg-2)", d.currentTarget.style.borderColor = "var(--orca-color-primary-4)";
      },
      onMouseLeave: (d) => {
        d.currentTarget.style.backgroundColor = "var(--orca-color-bg-1)", d.currentTarget.style.borderColor = "var(--orca-color-border-1)";
      },
      children: [
        /* @__PURE__ */ o.jsxs("div", { style: {
          display: "flex",
          alignItems: "center",
          gap: "8px"
        }, children: [
          /* @__PURE__ */ o.jsxs("span", { style: {
            display: "inline-flex",
            alignItems: "center",
            gap: "4px",
            padding: "2px 8px",
            borderRadius: "12px",
            fontSize: "12px",
            fontWeight: 500,
            backgroundColor: `${cn(a)}20`,
            color: cn(a)
          }, children: [
            /* @__PURE__ */ o.jsx("i", { className: `ti ${il(a)}`, style: { fontSize: "12px" } }),
            sl(a)
          ] }),
          /* @__PURE__ */ o.jsx("span", { style: {
            fontSize: "12px",
            color: "var(--orca-color-text-3)"
          }, children: n.deck })
        ] }),
        /* @__PURE__ */ o.jsx("div", { style: { minHeight: "24px" }, children: /* @__PURE__ */ o.jsx(Qn, { blockId: n.id, panelId: t }) }),
        /* @__PURE__ */ o.jsxs("div", { style: {
          display: "flex",
          gap: "16px",
          fontSize: "12px",
          color: "var(--orca-color-text-3)",
          borderTop: "1px solid var(--orca-color-border-1)",
          paddingTop: "8px"
        }, children: [
          /* @__PURE__ */ o.jsxs("span", { title: "最近10次复习中的Again次数", children: [
            /* @__PURE__ */ o.jsx("i", { className: "ti ti-x", style: { marginRight: "2px" } }),
            "Again: ",
            s
          ] }),
          /* @__PURE__ */ o.jsxs("span", { title: "总遗忘次数", children: [
            /* @__PURE__ */ o.jsx("i", { className: "ti ti-repeat", style: { marginRight: "2px" } }),
            "遗忘: ",
            i
          ] }),
          /* @__PURE__ */ o.jsxs("span", { title: "难度值 (1-10)", children: [
            /* @__PURE__ */ o.jsx("i", { className: "ti ti-flame", style: { marginRight: "2px" } }),
            "难度: ",
            c.toFixed(1)
          ] }),
          n.clozeNumber && /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-primary-5)" }, children: [
            "填空 c",
            n.clozeNumber
          ] }),
          n.directionType && /* @__PURE__ */ o.jsx("span", { style: { color: n.directionType === "forward" ? "var(--orca-color-primary-5)" : "var(--orca-color-warning-5)" }, children: n.directionType === "forward" ? "正向" : "反向" })
        ] })
      ]
    }
  );
}
function cl({
  panelId: e,
  pluginName: t,
  onBack: r,
  onStartReview: n
}) {
  const [a, s] = Fr([]), [i, c] = Fr(!0), [l, d] = Fr("all"), u = Pr(async () => {
    c(!0);
    try {
      const { getDifficultCards: g } = await Promise.resolve().then(() => Sc), S = await g(t);
      s(S);
    } catch (g) {
      console.error(`[${t}] 加载困难卡片失败:`, g), orca.notify("error", "加载困难卡片失败", { title: "SRS" });
    } finally {
      c(!1);
    }
  }, [t]);
  al(() => {
    u();
  }, [u]);
  const f = sn(() => l === "all" ? a : a.filter((g) => l === "high_again_rate" ? g.reason === "high_again_rate" || g.reason === "multiple" : l === "high_lapses" ? g.reason === "high_lapses" || g.reason === "multiple" : l === "high_difficulty" ? g.reason === "high_difficulty" || g.reason === "multiple" : !0), [a, l]), x = sn(() => {
    const g = {
      all: a.length,
      high_again_rate: 0,
      high_lapses: 0,
      high_difficulty: 0
    };
    for (const S of a)
      (S.reason === "high_again_rate" || S.reason === "multiple") && g.high_again_rate++, (S.reason === "high_lapses" || S.reason === "multiple") && g.high_lapses++, (S.reason === "high_difficulty" || S.reason === "multiple") && g.high_difficulty++;
    return g;
  }, [a]), h = Pr(() => {
    const g = f.map((S) => S.card);
    if (g.length === 0) {
      orca.notify("info", "没有困难卡片需要复习", { title: "SRS" });
      return;
    }
    n(g);
  }, [f, n]), y = Pr((g) => {
    orca.nav.openInLastPanel("block", { blockId: g });
  }, []);
  return i ? /* @__PURE__ */ o.jsx("div", { style: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "200px",
    color: "var(--orca-color-text-2)"
  }, children: "加载中..." }) : /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      gap: "12px"
    }, children: [
      /* @__PURE__ */ o.jsx(ln, { variant: "plain", onClick: r, style: { fontSize: "13px", padding: "6px 12px" }, children: "← 返回" }),
      /* @__PURE__ */ o.jsxs("div", { style: {
        fontSize: "16px",
        fontWeight: 600,
        color: "var(--orca-color-text-1)",
        flex: 1,
        display: "flex",
        alignItems: "center",
        gap: "8px"
      }, children: [
        /* @__PURE__ */ o.jsx("i", { className: "ti ti-alert-triangle", style: { color: "#ef4444" } }),
        "困难卡片",
        /* @__PURE__ */ o.jsxs("span", { style: {
          fontSize: "14px",
          fontWeight: 400,
          color: "var(--orca-color-text-3)"
        }, children: [
          "(",
          a.length,
          ")"
        ] })
      ] }),
      f.length > 0 && /* @__PURE__ */ o.jsx(
        ln,
        {
          variant: "solid",
          onClick: h,
          style: { fontSize: "13px", padding: "6px 12px" },
          children: "复习困难卡片"
        }
      )
    ] }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      padding: "12px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      fontSize: "13px",
      color: "var(--orca-color-text-2)",
      lineHeight: 1.6
    }, children: [
      /* @__PURE__ */ o.jsx("p", { style: { margin: 0 }, children: "困难卡片是指经常遗忘或难度较高的卡片。系统会自动识别以下类型：" }),
      /* @__PURE__ */ o.jsxs("ul", { style: { margin: "8px 0 0 0", paddingLeft: "20px" }, children: [
        /* @__PURE__ */ o.jsxs("li", { children: [
          /* @__PURE__ */ o.jsx("span", { style: { color: "#ef4444" }, children: "频繁遗忘" }),
          "：最近10次复习中按了3次以上 Again"
        ] }),
        /* @__PURE__ */ o.jsxs("li", { children: [
          /* @__PURE__ */ o.jsx("span", { style: { color: "#f59e0b" }, children: "遗忘次数多" }),
          "：总遗忘次数达到3次以上"
        ] }),
        /* @__PURE__ */ o.jsxs("li", { children: [
          /* @__PURE__ */ o.jsx("span", { style: { color: "#8b5cf6" }, children: "难度较高" }),
          "：难度值达到7以上"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      gap: "8px",
      flexWrap: "wrap"
    }, children: [
      { key: "all", label: "全部", color: "var(--orca-color-text-2)" },
      { key: "high_again_rate", label: "频繁遗忘", color: "#ef4444" },
      { key: "high_lapses", label: "遗忘次数多", color: "#f59e0b" },
      { key: "high_difficulty", label: "难度较高", color: "#8b5cf6" }
    ].map((g) => /* @__PURE__ */ o.jsxs(
      "button",
      {
        onClick: () => d(g.key),
        style: {
          padding: "6px 12px",
          borderRadius: "16px",
          border: "1px solid",
          borderColor: l === g.key ? g.color : "var(--orca-color-border-1)",
          backgroundColor: l === g.key ? `${g.color}15` : "transparent",
          color: l === g.key ? g.color : "var(--orca-color-text-2)",
          fontSize: "13px",
          cursor: "pointer",
          transition: "all 0.2s ease"
        },
        children: [
          g.label,
          " (",
          x[g.key],
          ")"
        ]
      },
      g.key
    )) }),
    /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      flexDirection: "column",
      gap: "8px"
    }, children: f.length === 0 ? /* @__PURE__ */ o.jsxs("div", { style: {
      textAlign: "center",
      padding: "48px 24px",
      color: "var(--orca-color-text-3)"
    }, children: [
      /* @__PURE__ */ o.jsx("i", { className: "ti ti-mood-smile", style: { fontSize: "48px", opacity: 0.5, display: "block", marginBottom: "12px" } }),
      /* @__PURE__ */ o.jsx("div", { style: { fontSize: "15px", marginBottom: "8px" }, children: l === "all" ? "太棒了！没有困难卡片" : "没有符合条件的困难卡片" }),
      /* @__PURE__ */ o.jsx("div", { style: { fontSize: "13px", opacity: 0.7 }, children: "继续保持良好的复习习惯" })
    ] }) : f.map((g, S) => /* @__PURE__ */ o.jsx(
      ll,
      {
        info: g,
        panelId: e,
        onCardClick: y
      },
      `${g.card.id}-${g.card.clozeNumber || 0}-${g.card.directionType || "basic"}-${S}`
    )) })
  ] });
}
const { useMemo: Xe } = window.React, { Button: dl } = orca.components;
function ul() {
  const e = (/* @__PURE__ */ new Date()).getHours();
  return e < 6 ? "夜深了" : e < 12 ? "早上好" : e < 14 ? "中午好" : e < 18 ? "下午好" : e < 22 ? "晚上好" : "夜深了";
}
function fl(e, t) {
  return e === 0 && t === 0 ? "今天的学习任务已完成！" : e > 50 ? "有不少卡片等待复习，加油！" : e > 0 ? "开始今天的学习吧" : "探索新知识的时候到了";
}
function pl({ dueCards: e, newCards: t, reviewHistory: r, onStartReview: n }) {
  const a = ul(), s = fl(e, t), i = e + t, c = Xe(() => !r || r.days.length === 0 ? 0 : (r.days.slice(-7).reduce((x, h) => x + h.total, 0) / 7).toFixed(1), [r]), l = Xe(() => {
    const u = ["六", "日", "一", "二", "三", "四", "五"], f = /* @__PURE__ */ new Date(), x = [];
    for (let h = 6; h >= 0; h--) {
      const y = new Date(f);
      y.setDate(y.getDate() - h);
      const g = y.getDay();
      let S = 0;
      if (r) {
        const m = r.days.find((v) => new Date(v.date).toDateString() === y.toDateString());
        m && (S = m.total);
      }
      x.push({
        day: u[g],
        count: S,
        isToday: h === 0
      });
    }
    return x;
  }, [r]), d = Math.max(...l.map((u) => u.count), 1);
  return /* @__PURE__ */ o.jsxs("div", { style: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: "16px"
  }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: {
      padding: "20px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "12px",
      border: "1px solid var(--orca-color-border-1)",
      userSelect: "none"
    }, children: [
      /* @__PURE__ */ o.jsx("h2", { style: {
        margin: "0 0 4px 0",
        fontSize: "20px",
        fontWeight: 600,
        color: "var(--orca-color-text-1)"
      }, children: a }),
      /* @__PURE__ */ o.jsx("p", { style: {
        margin: "0 0 20px 0",
        fontSize: "14px",
        color: "var(--orca-color-text-3)"
      }, children: s }),
      /* @__PURE__ */ o.jsx("div", { style: {
        display: "flex",
        alignItems: "flex-end",
        gap: "8px",
        height: "80px",
        marginBottom: "12px"
      }, children: l.map((u, f) => /* @__PURE__ */ o.jsxs("div", { style: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "4px"
      }, children: [
        /* @__PURE__ */ o.jsx("div", { style: {
          width: "100%",
          height: `${Math.max(u.count / d * 60, 4)}px`,
          backgroundColor: u.isToday ? "#6366f1" : "var(--orca-color-primary-3)",
          borderRadius: "4px 4px 0 0",
          transition: "height 0.3s ease"
        } }),
        /* @__PURE__ */ o.jsx("span", { style: {
          fontSize: "11px",
          color: u.isToday ? "#6366f1" : "var(--orca-color-text-3)"
        }, children: u.day })
      ] }, f)) }),
      /* @__PURE__ */ o.jsxs("div", { style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        paddingTop: "12px",
        borderTop: "1px solid var(--orca-color-border-1)"
      }, children: [
        /* @__PURE__ */ o.jsxs("div", { children: [
          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", color: "#6366f1" }, children: "日均复习" }),
          /* @__PURE__ */ o.jsxs("div", { style: { fontSize: "18px", fontWeight: 600, color: "#6366f1" }, children: [
            c,
            " ",
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", fontWeight: 400 }, children: "张" })
          ] }),
          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "11px", color: "var(--orca-color-text-3)" }, children: "最近 7 天" })
        ] }),
        /* @__PURE__ */ o.jsxs("div", { style: { textAlign: "right" }, children: [
          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", color: "var(--orca-color-text-3)" }, children: "🎯 今日目标:" }),
          /* @__PURE__ */ o.jsxs("span", { style: { fontSize: "12px", color: "var(--orca-color-text-2)", marginLeft: "4px" }, children: [
            i,
            " 张卡片"
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ o.jsx(
      xl,
      {
        reviewHistory: r,
        onStartReview: n,
        dueCards: e
      }
    )
  ] });
}
function xl({ reviewHistory: e, onStartReview: t, dueCards: r }) {
  const n = Xe(() => {
    if (!e)
      return { timeStudied: 0, cardsStudied: 0, again: 0, hard: 0, good: 0, easy: 0 };
    const i = e.days.slice(-7), c = i.reduce((x, h) => x + h.total, 0), l = i.reduce((x, h) => x + h.again, 0), d = i.reduce((x, h) => x + h.hard, 0), u = i.reduce((x, h) => x + h.good, 0), f = i.reduce((x, h) => x + h.easy, 0);
    return { timeStudied: 0, cardsStudied: c, again: l, hard: d, good: u, easy: f };
  }, [e]), a = n.again + n.hard + n.good + n.easy, s = (i) => a > 0 ? Math.round(i / a * 100) : 0;
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "20px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "12px",
    border: "1px solid var(--orca-color-border-1)",
    userSelect: "none"
  }, children: [
    /* @__PURE__ */ o.jsx("h3", { style: {
      margin: "0 0 16px 0",
      fontSize: "16px",
      fontWeight: 600,
      color: "var(--orca-color-text-1)"
    }, children: "本周摘要" }),
    /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      gap: "24px",
      marginBottom: "16px"
    }, children: /* @__PURE__ */ o.jsxs("div", { children: [
      /* @__PURE__ */ o.jsx("div", { style: { fontSize: "11px", color: "var(--orca-color-text-3)" }, children: "已复习卡片" }),
      /* @__PURE__ */ o.jsxs("div", { style: { fontSize: "24px", fontWeight: 600, color: "var(--orca-color-text-1)" }, children: [
        n.cardsStudied,
        " ",
        /* @__PURE__ */ o.jsx("span", { style: { fontSize: "14px", fontWeight: 400 }, children: "张" })
      ] })
    ] }) }),
    /* @__PURE__ */ o.jsxs("div", { style: { marginBottom: "16px" }, children: [
      /* @__PURE__ */ o.jsx("div", { style: { fontSize: "12px", color: "var(--orca-color-text-2)", marginBottom: "8px" }, children: "复习表现分布" }),
      /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "6px" }, children: [
        /* @__PURE__ */ o.jsx(Xt, { icon: "❌", label: "忘记了", percent: s(n.again), color: "#ef4444" }),
        /* @__PURE__ */ o.jsx(Xt, { icon: "😐", label: "有点难", percent: s(n.hard), color: "#f97316" }),
        /* @__PURE__ */ o.jsx(Xt, { icon: "😊", label: "想起来了", percent: s(n.good), color: "#22c55e" }),
        /* @__PURE__ */ o.jsx(Xt, { icon: "🎉", label: "很简单", percent: s(n.easy), color: "#3b82f6" })
      ] })
    ] }),
    r > 0 && /* @__PURE__ */ o.jsxs(
      dl,
      {
        variant: "solid",
        onClick: t,
        style: {
          width: "100%",
          padding: "10px",
          fontSize: "14px",
          backgroundColor: "#6366f1",
          borderRadius: "8px"
        },
        children: [
          "开始今日复习 · ",
          r,
          " 张"
        ]
      }
    )
  ] });
}
function Xt({ icon: e, label: t, percent: r, color: n }) {
  return /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    alignItems: "center",
    gap: "8px"
  }, children: [
    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "14px" }, children: e }),
    /* @__PURE__ */ o.jsx("span", { style: { fontSize: "13px", color: "var(--orca-color-text-2)", flex: 1 }, children: t }),
    /* @__PURE__ */ o.jsx("div", { style: {
      width: "80px",
      height: "6px",
      backgroundColor: "var(--orca-color-bg-3)",
      borderRadius: "3px",
      overflow: "hidden"
    }, children: /* @__PURE__ */ o.jsx("div", { style: {
      width: `${r}%`,
      height: "100%",
      backgroundColor: n,
      borderRadius: "3px",
      transition: "width 0.3s ease"
    } }) }),
    /* @__PURE__ */ o.jsxs("span", { style: { fontSize: "12px", color: "var(--orca-color-text-3)", width: "40px", textAlign: "right" }, children: [
      r,
      "%"
    ] })
  ] });
}
function hl({ reviewHistory: e }) {
  const t = Xe(() => {
    const s = /* @__PURE__ */ new Date(), i = new Date(s);
    i.setMonth(i.getMonth() - 6), i.setDate(1);
    const c = /* @__PURE__ */ new Map();
    if (e)
      for (const x of e.days) {
        const h = new Date(x.date).toDateString();
        c.set(h, x.total);
      }
    const l = [];
    let d = [];
    const u = new Date(i), f = u.getDay();
    for (let x = 0; x < f; x++)
      d.push({ date: /* @__PURE__ */ new Date(0), count: -1, level: 0 });
    for (; u <= s; ) {
      const x = c.get(u.toDateString()) || 0;
      let h = 0;
      x > 0 && (h = 1), x >= 10 && (h = 2), x >= 20 && (h = 3), x >= 30 && (h = 4), d.push({
        date: new Date(u),
        count: x,
        level: h
      }), d.length === 7 && (l.push(d), d = []), u.setDate(u.getDate() + 1);
    }
    return d.length > 0 && l.push(d), l;
  }, [e]), r = Xe(() => {
    let s = 0, i = 0, c = 0;
    const l = t.flat().filter((d) => d.count >= 0);
    for (let d = 0; d < l.length; d++)
      l[d].count > 0 ? (s++, c++, c > i && (i = c)) : c = 0;
    return { daysStudied: s, bestStreak: i };
  }, [t]), n = Xe(() => {
    const s = [];
    let i = -1;
    return t.forEach((c, l) => {
      const d = c.find((u) => u.count >= 0);
      if (d && d.date.getMonth() !== i) {
        i = d.date.getMonth();
        const u = ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"];
        s.push({ month: u[i], weekIndex: l });
      }
    }), s;
  }, [t]), a = [
    "#ebedf0",
    // 0: 无 - 浅灰色
    "#c6e48b",
    // 1: 少
    "#7bc96f",
    // 2: 中
    "#239a3b",
    // 3: 多
    "#196127"
    // 4: 很多
  ];
  return /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "20px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "12px",
    border: "1px solid var(--orca-color-border-1)",
    userSelect: "none"
  }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: "16px"
    }, children: [
      /* @__PURE__ */ o.jsx("h3", { style: {
        margin: 0,
        fontSize: "16px",
        fontWeight: 600,
        color: "var(--orca-color-text-1)"
      }, children: "学习历史" }),
      /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "24px" }, children: [
        /* @__PURE__ */ o.jsxs("div", { style: { textAlign: "center" }, children: [
          /* @__PURE__ */ o.jsx("div", { style: { fontSize: "11px", color: "var(--orca-color-text-3)" }, children: "学习天数" }),
          /* @__PURE__ */ o.jsxs("div", { style: { fontSize: "18px", fontWeight: 600, color: "var(--orca-color-text-1)" }, children: [
            r.daysStudied,
            " ",
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", fontWeight: 400 }, children: "天" })
          ] })
        ] }),
        /* @__PURE__ */ o.jsxs("div", { style: { textAlign: "center" }, children: [
          /* @__PURE__ */ o.jsx("div", { style: { fontSize: "11px", color: "var(--orca-color-text-3)" }, children: "最长连续" }),
          /* @__PURE__ */ o.jsxs("div", { style: { fontSize: "18px", fontWeight: 600, color: "var(--orca-color-text-1)" }, children: [
            r.bestStreak,
            " ",
            /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", fontWeight: 400 }, children: "天" })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ o.jsxs("div", { style: { overflowX: "auto" }, children: [
      /* @__PURE__ */ o.jsx("div", { style: {
        display: "flex",
        marginLeft: "20px",
        marginBottom: "4px"
      }, children: n.map((s, i) => {
        var c;
        return /* @__PURE__ */ o.jsx(
          "span",
          {
            style: {
              fontSize: "11px",
              color: "var(--orca-color-text-3)",
              width: `${(((c = n[i + 1]) == null ? void 0 : c.weekIndex) || t.length) - s.weekIndex}2px`,
              minWidth: "36px"
            },
            children: s.month
          },
          i
        );
      }) }),
      /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "2px" }, children: [
        /* @__PURE__ */ o.jsx("div", { style: {
          display: "flex",
          flexDirection: "column",
          gap: "2px",
          marginRight: "4px"
        }, children: ["一", "", "三", "", "五", "", "日"].map((s, i) => /* @__PURE__ */ o.jsx(
          "div",
          {
            style: {
              width: "12px",
              height: "10px",
              fontSize: "9px",
              color: "var(--orca-color-text-3)",
              display: "flex",
              alignItems: "center"
            },
            children: s
          },
          i
        )) }),
        t.map((s, i) => /* @__PURE__ */ o.jsx(
          "div",
          {
            style: {
              display: "flex",
              flexDirection: "column",
              gap: "2px"
            },
            children: s.map((c, l) => /* @__PURE__ */ o.jsx(
              "div",
              {
                style: {
                  width: "10px",
                  height: "10px",
                  backgroundColor: c.count < 0 ? "transparent" : a[c.level],
                  borderRadius: "2px"
                },
                title: c.count >= 0 ? `${c.date.toLocaleDateString()}: ${c.count} 次复习` : ""
              },
              l
            ))
          },
          i
        ))
      ] })
    ] }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      gap: "4px",
      marginTop: "12px",
      fontSize: "11px",
      color: "var(--orca-color-text-3)"
    }, children: [
      /* @__PURE__ */ o.jsx("span", { children: "无" }),
      a.map((s, i) => /* @__PURE__ */ o.jsx(
        "div",
        {
          style: {
            width: "10px",
            height: "10px",
            backgroundColor: s,
            borderRadius: "2px"
          }
        },
        i
      )),
      /* @__PURE__ */ o.jsx("span", { children: "多" })
    ] })
  ] });
}
function gl({ forecast: e }) {
  const t = Xe(() => e ? e.days.slice(0, 30).map((a) => ({
    date: a.date,
    count: a.reviewDue + a.newAvailable
  })) : [], [e]), r = Xe(() => t.length === 0 ? 0 : t.reduce((a, s) => a + s.count, 0), [t]), n = Math.max(...t.map((a) => a.count), 1);
  return !e || t.length === 0 ? null : /* @__PURE__ */ o.jsxs("div", { style: {
    padding: "20px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "12px",
    border: "1px solid var(--orca-color-border-1)",
    userSelect: "none"
  }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: "16px"
    }, children: [
      /* @__PURE__ */ o.jsx("h3", { style: {
        margin: 0,
        fontSize: "16px",
        fontWeight: 600,
        color: "var(--orca-color-text-1)"
      }, children: "未来 30 天到期预测" }),
      /* @__PURE__ */ o.jsxs("div", { style: { textAlign: "right" }, children: [
        /* @__PURE__ */ o.jsx("div", { style: { fontSize: "11px", color: "var(--orca-color-text-3)" }, children: "总计" }),
        /* @__PURE__ */ o.jsxs("div", { style: { fontSize: "18px", fontWeight: 600, color: "var(--orca-color-text-1)" }, children: [
          r,
          " ",
          /* @__PURE__ */ o.jsx("span", { style: { fontSize: "12px", fontWeight: 400 }, children: "张" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      alignItems: "flex-end",
      gap: "3px",
      height: "80px"
    }, children: t.map((a, s) => /* @__PURE__ */ o.jsx(
      "div",
      {
        style: {
          flex: 1,
          height: `${Math.max(a.count / n * 100, a.count > 0 ? 8 : 2)}%`,
          backgroundColor: a.count > 0 ? "#22c55e" : "#e5e7eb",
          borderRadius: "2px 2px 0 0",
          minWidth: "6px"
        },
        title: `${a.date.getMonth() + 1}/${a.date.getDate()}: ${a.count} 张卡片`
      },
      s
    )) }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      justifyContent: "space-between",
      marginTop: "8px",
      fontSize: "11px",
      color: "var(--orca-color-text-3)"
    }, children: [
      /* @__PURE__ */ o.jsx("span", { children: "今天" }),
      /* @__PURE__ */ o.jsx("span", { children: "30 天后" })
    ] })
  ] });
}
function yl({
  reviewHistory: e,
  futureForecast: t,
  newCards: r,
  dueCards: n,
  onStartReview: a,
  isLoading: s
}) {
  return s ? /* @__PURE__ */ o.jsx("div", { style: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "200px",
    color: "var(--orca-color-text-3)"
  }, children: "加载中..." }) : /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    flexDirection: "column",
    gap: "16px"
  }, children: [
    /* @__PURE__ */ o.jsx(
      pl,
      {
        dueCards: n,
        newCards: r,
        reviewHistory: e,
        onStartReview: a
      }
    ),
    /* @__PURE__ */ o.jsx(
      hl,
      {
        reviewHistory: e
      }
    ),
    /* @__PURE__ */ o.jsx(gl, { forecast: t })
  ] });
}
const { useState: we, useEffect: at, useCallback: Te, useMemo: Et, useRef: Mt } = window.React, { Button: fe } = orca.components, ml = [
  { key: "all", label: "全部" },
  { key: "overdue", label: "已到期" },
  { key: "today", label: "今天" },
  { key: "future", label: "未来" },
  { key: "new", label: "新卡" }
];
function dn({ text: e, query: t }) {
  if (!t.trim())
    return /* @__PURE__ */ o.jsx(o.Fragment, { children: e });
  const r = e.split(new RegExp(`(${t})`, "gi"));
  return /* @__PURE__ */ o.jsx(o.Fragment, { children: r.map(
    (n, a) => n.toLowerCase() === t.toLowerCase() ? /* @__PURE__ */ o.jsx("span", { style: {
      backgroundColor: "var(--orca-color-warning-2)",
      color: "var(--orca-color-warning-7)",
      fontWeight: 600,
      padding: "0 2px",
      borderRadius: "2px"
    }, children: n }, a) : /* @__PURE__ */ o.jsx("span", { children: n }, a)
  ) });
}
function Lr({ label: e, value: t, color: r }) {
  return /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "12px 16px",
    backgroundColor: "var(--orca-color-bg-2)",
    borderRadius: "8px",
    minWidth: "80px"
  }, children: [
    /* @__PURE__ */ o.jsx("div", { style: {
      fontSize: "24px",
      fontWeight: 600,
      color: r || "var(--orca-color-text-1)"
    }, children: t }),
    /* @__PURE__ */ o.jsx("div", { style: {
      fontSize: "12px",
      color: "var(--orca-color-text-3)",
      marginTop: "4px"
    }, children: e })
  ] });
}
function vl({ card: e, panelId: t, onCardClick: r, onCardReset: n, onCardDelete: a }) {
  const s = (x) => {
    const h = /* @__PURE__ */ new Date(), y = new Date(h.getFullYear(), h.getMonth(), h.getDate()), g = new Date(y);
    return g.setDate(g.getDate() + 1), x < y ? `已到期 ${Math.floor((y.getTime() - x.getTime()) / 864e5)} 天` : x < g ? "今天到期" : `${Math.floor((x.getTime() - y.getTime()) / 864e5)} 天后到期`;
  }, i = (x) => {
    const h = x.getMonth() + 1, y = x.getDate();
    return `${h}月${y}日`;
  }, c = (x) => x < 1 ? "< 1天" : x < 30 ? `${Math.round(x)}天` : x < 365 ? `${Math.round(x / 30)}月` : `${(x / 365).toFixed(1)}年`, l = (x) => {
    x.stopPropagation(), r(e.id);
  }, d = (x) => {
    x.stopPropagation(), n(e);
  }, u = (x) => {
    x.stopPropagation(), a(e);
  }, f = e.srs.resets ?? 0;
  return /* @__PURE__ */ o.jsxs(
    "div",
    {
      style: {
        border: "1px solid var(--orca-color-border-1)",
        borderRadius: "8px",
        padding: "12px",
        backgroundColor: "var(--orca-color-bg-1)",
        display: "flex",
        flexDirection: "column",
        gap: "8px",
        transition: "all 0.2s ease"
      },
      children: [
        /* @__PURE__ */ o.jsx("div", { style: { fontSize: "12px", color: "var(--orca-color-text-3)" }, children: /* @__PURE__ */ o.jsx(orca.components.BlockBreadcrumb, { blockId: e.id }) }),
        /* @__PURE__ */ o.jsx("div", { style: { minHeight: "24px" }, children: /* @__PURE__ */ o.jsx(Qn, { blockId: e.id, panelId: t }) }),
        /* @__PURE__ */ o.jsxs("div", { style: {
          display: "flex",
          alignItems: "center",
          gap: "8px",
          fontSize: "12px",
          color: "var(--orca-color-text-3)",
          borderTop: "1px solid var(--orca-color-border-1)",
          paddingTop: "8px"
        }, children: [
          /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "12px", flex: 1, flexWrap: "wrap" }, children: [
            e.isNew ? /* @__PURE__ */ o.jsx("span", { style: { color: "var(--orca-color-primary-6)" }, children: "未学习" }) : /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
              /* @__PURE__ */ o.jsx("span", { style: {
                color: (() => {
                  const x = /* @__PURE__ */ new Date(), h = new Date(x.getFullYear(), x.getMonth(), x.getDate()), y = new Date(h);
                  return y.setDate(y.getDate() + 1), e.srs.due < h ? "var(--orca-color-success-6)" : e.srs.due < y ? "var(--orca-color-danger-6)" : "var(--orca-color-text-2)";
                })()
              }, children: s(e.srs.due) }),
              /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-text-2)" }, children: [
                "下次: ",
                i(e.srs.due)
              ] }),
              /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-text-2)" }, children: [
                "间隔: ",
                c(e.srs.interval)
              ] })
            ] }),
            e.clozeNumber && /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-primary-5)" }, children: [
              "填空 c",
              e.clozeNumber
            ] }),
            e.directionType && /* @__PURE__ */ o.jsx("span", { style: { color: e.directionType === "forward" ? "var(--orca-color-primary-5)" : "var(--orca-color-warning-5)" }, children: e.directionType === "forward" ? "正向" : "反向" }),
            f > 0 && /* @__PURE__ */ o.jsxs("span", { style: { color: "var(--orca-color-warning-6)" }, children: [
              "重置 ",
              f,
              " 次"
            ] })
          ] }),
          /* @__PURE__ */ o.jsxs(
            fe,
            {
              variant: "plain",
              onClick: u,
              style: {
                fontSize: "12px",
                padding: "4px 8px",
                minWidth: "auto",
                color: "var(--orca-color-danger-6)"
              },
              title: "删除卡片（移除 Card 标记和 SRS 数据）",
              children: [
                /* @__PURE__ */ o.jsx("i", { className: "ti ti-trash", style: { marginRight: "4px" } }),
                "删除"
              ]
            }
          ),
          /* @__PURE__ */ o.jsxs(
            fe,
            {
              variant: "plain",
              onClick: d,
              style: {
                fontSize: "12px",
                padding: "4px 8px",
                minWidth: "auto",
                color: "var(--orca-color-warning-6)"
              },
              title: "重置卡片为新卡状态",
              children: [
                /* @__PURE__ */ o.jsx("i", { className: "ti ti-refresh", style: { marginRight: "4px" } }),
                "重置"
              ]
            }
          ),
          /* @__PURE__ */ o.jsxs(
            fe,
            {
              variant: "plain",
              onClick: l,
              style: {
                fontSize: "12px",
                padding: "4px 8px",
                minWidth: "auto"
              },
              title: "在右侧面板打开编辑",
              children: [
                /* @__PURE__ */ o.jsx("i", { className: "ti ti-external-link", style: { marginRight: "4px" } }),
                "跳转"
              ]
            }
          )
        ] })
      ]
    }
  );
}
function bl({ deck: e, pluginName: t, searchQuery: r = "", onViewDeck: n, onReviewDeck: a, onNoteChange: s }) {
  const [i, c] = we(!1), [l, d] = we(e.note || ""), u = e.overdueCount + e.todayCount, f = () => {
    n(e.name);
  }, x = (m) => {
    m.stopPropagation(), (u > 0 || e.newCount > 0) && a(e.name);
  }, h = (m) => {
    m.stopPropagation(), c(!0);
  }, y = async (m) => {
    m.stopPropagation();
    try {
      const { setDeckNote: v } = await Promise.resolve().then(() => Jr);
      await v(t, e.name, l), s(e.name, l), c(!1);
    } catch (v) {
      console.error(`[${t}] 保存卡组备注失败:`, v), orca.notify("error", "保存备注失败", { title: "SRS" });
    }
  }, g = (m) => {
    m.stopPropagation(), d(e.note || ""), c(!1);
  }, S = (m) => {
    d(m.target.value);
  };
  return /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", flexDirection: "column" }, children: [
    /* @__PURE__ */ o.jsxs(
      "div",
      {
        onClick: f,
        style: {
          display: "flex",
          alignItems: "center",
          padding: "10px 12px",
          backgroundColor: "var(--orca-color-bg-1)",
          borderRadius: "6px",
          cursor: "pointer",
          transition: "background-color 0.15s ease"
        },
        onMouseEnter: (m) => {
          m.currentTarget.style.backgroundColor = "var(--orca-color-bg-2)";
        },
        onMouseLeave: (m) => {
          m.currentTarget.style.backgroundColor = "var(--orca-color-bg-1)";
        },
        children: [
          /* @__PURE__ */ o.jsxs("div", { style: {
            flex: 1,
            fontSize: "14px",
            color: "var(--orca-color-text-1)",
            fontWeight: 500
          }, children: [
            /* @__PURE__ */ o.jsx("div", { children: /* @__PURE__ */ o.jsx(dn, { text: e.name, query: r }) }),
            e.note && !i && /* @__PURE__ */ o.jsx(
              "div",
              {
                style: {
                  fontSize: "12px",
                  color: "var(--orca-color-text-3)",
                  marginTop: "2px",
                  cursor: "pointer"
                },
                onClick: h,
                title: "点击编辑备注",
                children: /* @__PURE__ */ o.jsx(dn, { text: e.note, query: r })
              }
            )
          ] }),
          /* @__PURE__ */ o.jsx("div", { style: {
            width: "60px",
            textAlign: "center",
            fontSize: "14px",
            color: e.newCount > 0 ? "#3b82f6" : "#9ca3af"
          }, children: e.newCount }),
          /* @__PURE__ */ o.jsx("div", { style: {
            width: "60px",
            textAlign: "center",
            fontSize: "14px",
            color: e.todayCount > 0 ? "#ef4444" : "#9ca3af"
          }, children: e.todayCount }),
          /* @__PURE__ */ o.jsx("div", { style: {
            width: "60px",
            textAlign: "center",
            fontSize: "14px",
            color: e.overdueCount > 0 ? "#22c55e" : "#9ca3af"
          }, children: e.overdueCount }),
          /* @__PURE__ */ o.jsxs("div", { style: { width: "64px", textAlign: "center", display: "flex", gap: "4px" }, children: [
            /* @__PURE__ */ o.jsx(
              fe,
              {
                variant: "plain",
                onClick: h,
                style: {
                  padding: "4px",
                  minWidth: "auto",
                  opacity: 0.7
                },
                title: e.note ? "编辑备注" : "添加备注",
                children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-note" })
              }
            ),
            /* @__PURE__ */ o.jsx(
              fe,
              {
                variant: "plain",
                onClick: x,
                style: {
                  padding: "4px",
                  minWidth: "auto",
                  opacity: u > 0 || e.newCount > 0 ? 1 : 0.3
                },
                title: "开始复习",
                children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-player-play" })
              }
            )
          ] })
        ]
      }
    ),
    i && /* @__PURE__ */ o.jsx("div", { style: {
      padding: "8px 12px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "6px",
      marginTop: "4px"
    }, children: /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "8px", alignItems: "center" }, children: [
      /* @__PURE__ */ o.jsx(
        "input",
        {
          type: "text",
          value: l,
          onChange: S,
          placeholder: "输入卡组备注...",
          style: {
            flex: 1,
            padding: "4px 8px",
            border: "1px solid var(--orca-color-border-1)",
            borderRadius: "4px",
            backgroundColor: "var(--orca-color-bg-1)",
            color: "var(--orca-color-text-1)",
            fontSize: "13px"
          },
          onClick: (m) => m.stopPropagation(),
          autoFocus: !0
        }
      ),
      /* @__PURE__ */ o.jsx(
        fe,
        {
          variant: "plain",
          onClick: g,
          style: { fontSize: "12px", padding: "4px 8px" },
          children: "取消"
        }
      ),
      /* @__PURE__ */ o.jsx(
        fe,
        {
          variant: "solid",
          onClick: y,
          style: { fontSize: "12px", padding: "4px 8px" },
          children: "保存"
        }
      )
    ] }) })
  ] });
}
function wl({
  deckStats: e,
  todayStats: t,
  panelId: r,
  pluginName: n,
  onViewDeck: a,
  onReviewDeck: s,
  onStartTodayReview: i,
  onRefresh: c,
  onNoteChange: l,
  onShowStatistics: d,
  onShowDifficultCards: u
}) {
  const [f, x] = we(""), h = Mt(null), y = t.pendingCount > 0 || t.newCount > 0, g = 15, [S, m] = we(g), v = Mt(null), C = Et(() => {
    if (!f.trim())
      return e.decks;
    const T = f.toLowerCase().trim();
    return e.decks.filter((O) => {
      var D;
      const H = O.name.toLowerCase().includes(T), z = ((D = O.note) == null ? void 0 : D.toLowerCase().includes(T)) || !1;
      return H || z;
    });
  }, [e.decks, f]);
  at(() => {
    m(g);
  }, [f]), at(() => {
    const T = v.current;
    if (!T) return;
    const O = new IntersectionObserver(
      (H) => {
        H[0].isIntersecting && S < C.length && m((z) => Math.min(z + g, C.length));
      },
      { threshold: 0.1 }
    );
    return O.observe(T), () => O.disconnect();
  }, [S, C.length]);
  const M = C.slice(0, S), b = S < C.length, P = () => {
    var T;
    x(""), (T = h.current) == null || T.focus();
  }, N = Et(() => {
    if (!f.trim())
      return {
        deckCount: e.decks.length,
        totalCards: t.totalCount,
        newCards: t.newCount,
        pendingCards: t.pendingCount
      };
    const T = C.reduce((z, D) => z + D.totalCount, 0), O = C.reduce((z, D) => z + D.newCount, 0), H = C.reduce((z, D) => z + D.overdueCount + D.todayCount, 0);
    return {
      deckCount: C.length,
      totalCards: T,
      newCards: O,
      pendingCards: H
    };
  }, [e.decks, C, t, f]);
  return /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      gap: "8px"
    }, children: [
      /* @__PURE__ */ o.jsxs(
        fe,
        {
          variant: "plain",
          onClick: u,
          className: "srs-difficult-cards-button",
          style: {
            fontSize: "13px",
            padding: "6px 12px",
            display: "flex",
            alignItems: "center",
            gap: "4px",
            color: "var(--orca-color-danger-6)"
          },
          title: "查看困难卡片",
          children: [
            /* @__PURE__ */ o.jsx("i", { className: "ti ti-alert-triangle" }),
            "困难卡片"
          ]
        }
      ),
      /* @__PURE__ */ o.jsxs(
        fe,
        {
          variant: "plain",
          onClick: d,
          className: "srs-statistics-button",
          style: {
            fontSize: "13px",
            padding: "6px 12px",
            display: "flex",
            alignItems: "center",
            gap: "4px"
          },
          title: "查看学习统计",
          children: [
            /* @__PURE__ */ o.jsx("i", { className: "ti ti-chart-bar" }),
            "统计"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      gap: "12px",
      justifyContent: "center",
      flexWrap: "wrap"
    }, children: [
      /* @__PURE__ */ o.jsx(
        Lr,
        {
          label: "未学习",
          value: t.newCount,
          color: "var(--orca-color-primary-6)"
        }
      ),
      /* @__PURE__ */ o.jsx(
        Lr,
        {
          label: "学习中",
          value: t.todayCount,
          color: "var(--orca-color-danger-6)"
        }
      ),
      /* @__PURE__ */ o.jsx(
        Lr,
        {
          label: "待复习",
          value: t.pendingCount - t.todayCount,
          color: "var(--orca-color-success-6)"
        }
      )
    ] }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      padding: "12px",
      backgroundColor: "var(--orca-color-bg-2)",
      borderRadius: "8px",
      border: "1px solid var(--orca-color-border-1)"
    }, children: [
      /* @__PURE__ */ o.jsx("i", { className: "ti ti-search", style: {
        fontSize: "16px",
        color: "var(--orca-color-text-3)"
      } }),
      /* @__PURE__ */ o.jsx(
        "input",
        {
          ref: h,
          type: "text",
          value: f,
          onChange: (T) => x(T.target.value),
          placeholder: "搜索卡组名称或备注内容...",
          style: {
            flex: 1,
            border: "none",
            outline: "none",
            backgroundColor: "transparent",
            color: "var(--orca-color-text-1)",
            fontSize: "14px",
            padding: "4px 0"
          },
          onKeyDown: (T) => {
            T.key === "Escape" && P();
          }
        }
      ),
      f && /* @__PURE__ */ o.jsx(
        fe,
        {
          variant: "plain",
          onClick: P,
          style: {
            padding: "4px",
            minWidth: "auto",
            fontSize: "14px",
            color: "var(--orca-color-text-3)"
          },
          title: "清空搜索",
          children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-x" })
        }
      )
    ] }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      border: "1px solid var(--orca-color-border-1)",
      borderRadius: "8px",
      overflow: "hidden"
    }, children: [
      /* @__PURE__ */ o.jsxs("div", { style: {
        display: "flex",
        alignItems: "center",
        padding: "10px 12px",
        backgroundColor: "var(--orca-color-bg-2)",
        borderBottom: "1px solid var(--orca-color-border-1)"
      }, children: [
        /* @__PURE__ */ o.jsx("div", { style: {
          flex: 1,
          fontSize: "13px",
          fontWeight: 600,
          color: "var(--orca-color-text-2)"
        }, children: "牌组" }),
        /* @__PURE__ */ o.jsx("div", { style: {
          width: "60px",
          textAlign: "center",
          fontSize: "13px",
          fontWeight: 600,
          color: "#3b82f6"
        }, children: "未学习" }),
        /* @__PURE__ */ o.jsx("div", { style: {
          width: "60px",
          textAlign: "center",
          fontSize: "13px",
          fontWeight: 600,
          color: "#ef4444"
        }, children: "学习中" }),
        /* @__PURE__ */ o.jsx("div", { style: {
          width: "60px",
          textAlign: "center",
          fontSize: "13px",
          fontWeight: 600,
          color: "#22c55e"
        }, children: "待复习" }),
        /* @__PURE__ */ o.jsx("div", { style: { width: "64px" } })
      ] }),
      /* @__PURE__ */ o.jsx("div", { style: { display: "flex", flexDirection: "column" }, children: e.decks.length === 0 ? /* @__PURE__ */ o.jsx("div", { style: {
        textAlign: "center",
        padding: "24px",
        color: "var(--orca-color-text-3)"
      }, children: "暂无牌组，请先创建卡片" }) : C.length === 0 ? /* @__PURE__ */ o.jsxs("div", { style: {
        textAlign: "center",
        padding: "24px",
        color: "var(--orca-color-text-3)"
      }, children: [
        /* @__PURE__ */ o.jsx("div", { style: { marginBottom: "8px" }, children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-search-off", style: { fontSize: "24px", opacity: 0.5 } }) }),
        /* @__PURE__ */ o.jsx("div", { children: "未找到匹配的卡组" }),
        /* @__PURE__ */ o.jsx("div", { style: { fontSize: "12px", marginTop: "4px", opacity: 0.7 }, children: "尝试搜索卡组名称或备注内容" })
      ] }) : /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
        M.map((T) => /* @__PURE__ */ o.jsx(
          bl,
          {
            deck: T,
            pluginName: n,
            searchQuery: f,
            onViewDeck: a,
            onReviewDeck: s,
            onNoteChange: l
          },
          T.name
        )),
        /* @__PURE__ */ o.jsx(
          "div",
          {
            ref: v,
            style: {
              padding: b ? "12px" : "8px",
              textAlign: "center",
              color: "var(--orca-color-text-3)",
              fontSize: "13px"
            },
            children: b ? /* @__PURE__ */ o.jsxs("span", { children: [
              "加载更多... (",
              S,
              "/",
              C.length,
              ")"
            ] }) : C.length > g ? /* @__PURE__ */ o.jsxs("span", { style: { opacity: 0.6 }, children: [
              "已加载全部 ",
              C.length,
              " 个卡组"
            ] }) : null
          }
        )
      ] }) })
    ] }),
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "12px"
    }, children: [
      /* @__PURE__ */ o.jsx("div", { style: {
        fontSize: "13px",
        color: "var(--orca-color-text-2)",
        textAlign: "center"
      }, children: f.trim() ? /* @__PURE__ */ o.jsxs("div", { children: [
        /* @__PURE__ */ o.jsxs("div", { children: [
          "搜索结果：",
          N.deckCount,
          " 个卡组，",
          N.totalCards,
          " 张卡片"
        ] }),
        /* @__PURE__ */ o.jsxs("div", { style: { marginTop: "2px", opacity: 0.8 }, children: [
          N.newCards,
          " 张新卡，",
          N.pendingCards,
          " 张待复习"
        ] })
      ] }) : /* @__PURE__ */ o.jsxs("div", { children: [
        "共 ",
        t.totalCount,
        " 张卡片，",
        t.newCount,
        " 张新卡，",
        t.pendingCount,
        " 张待复习"
      ] }) }),
      /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "8px" }, children: [
        /* @__PURE__ */ o.jsx(
          fe,
          {
            variant: "solid",
            onClick: y ? i : void 0,
            style: {
              opacity: y ? 1 : 0.5,
              cursor: y ? "pointer" : "not-allowed",
              padding: "8px 24px"
            },
            children: "开始今日复习"
          }
        ),
        /* @__PURE__ */ o.jsxs(
          fe,
          {
            variant: "plain",
            onClick: c,
            style: { padding: "8px 16px" },
            title: "刷新数据",
            children: [
              /* @__PURE__ */ o.jsx("i", { className: "ti ti-refresh", style: { marginRight: "4px" } }),
              "刷新"
            ]
          }
        )
      ] })
    ] })
  ] });
}
const Zt = 20;
function Sl({
  deckName: e,
  cards: t,
  allDeckCards: r,
  currentFilter: n,
  panelId: a,
  onFilterChange: s,
  onCardClick: i,
  onCardReset: c,
  onCardDelete: l,
  onBack: d,
  onReviewDeck: u
}) {
  const [f, x] = we(Zt), h = Mt(null);
  at(() => {
    x(Zt);
  }, [n, t.length]), at(() => {
    const v = h.current;
    if (!v) return;
    const C = new IntersectionObserver(
      (M) => {
        M[0].isIntersecting && f < t.length && x((b) => Math.min(b + Zt, t.length));
      },
      { threshold: 0.1 }
    );
    return C.observe(v), () => C.disconnect();
  }, [f, t.length]);
  const y = Et(() => {
    const v = /* @__PURE__ */ new Date(), C = new Date(v.getFullYear(), v.getMonth(), v.getDate()), M = new Date(C);
    return M.setDate(M.getDate() + 1), {
      all: r.length,
      overdue: r.filter((b) => !b.isNew && b.srs.due < C).length,
      today: r.filter((b) => !b.isNew && b.srs.due >= C && b.srs.due < M).length,
      future: r.filter((b) => !b.isNew && b.srs.due >= M).length,
      new: r.filter((b) => b.isNew).length
    };
  }, [r]), g = y.overdue + y.today > 0, S = t.slice(0, f), m = f < t.length;
  return /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "12px" }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      gap: "12px"
    }, children: [
      /* @__PURE__ */ o.jsx(fe, { variant: "plain", onClick: d, style: { fontSize: "13px", padding: "6px 12px" }, children: "← 返回" }),
      /* @__PURE__ */ o.jsx("div", { style: {
        fontSize: "16px",
        fontWeight: 600,
        color: "var(--orca-color-text-1)",
        flex: 1
      }, children: e }),
      g && /* @__PURE__ */ o.jsx(
        fe,
        {
          variant: "solid",
          onClick: () => u(e),
          style: { fontSize: "13px", padding: "6px 12px" },
          children: "复习此牌组"
        }
      )
    ] }),
    /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      gap: "8px",
      flexWrap: "wrap"
    }, children: ml.map((v) => /* @__PURE__ */ o.jsxs(
      "button",
      {
        onClick: () => s(v.key),
        style: {
          padding: "6px 12px",
          borderRadius: "16px",
          border: "1px solid",
          borderColor: n === v.key ? "var(--orca-color-primary-5)" : "var(--orca-color-border-1)",
          backgroundColor: n === v.key ? "var(--orca-color-primary-1)" : "transparent",
          color: n === v.key ? "var(--orca-color-primary-6)" : "var(--orca-color-text-2)",
          fontSize: "13px",
          cursor: "pointer",
          transition: "all 0.2s ease"
        },
        children: [
          v.label,
          " (",
          y[v.key],
          ")"
        ]
      },
      v.key
    )) }),
    /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      flexDirection: "column",
      gap: "8px"
    }, children: t.length === 0 ? /* @__PURE__ */ o.jsx("div", { style: {
      textAlign: "center",
      padding: "24px",
      color: "var(--orca-color-text-3)"
    }, children: "没有符合条件的卡片" }) : /* @__PURE__ */ o.jsxs(o.Fragment, { children: [
      S.map((v, C) => /* @__PURE__ */ o.jsx(
        vl,
        {
          card: v,
          panelId: a,
          onCardClick: i,
          onCardReset: c,
          onCardDelete: l
        },
        `${v.id}-${v.clozeNumber || 0}-${v.directionType || "basic"}-${C}`
      )),
      /* @__PURE__ */ o.jsx(
        "div",
        {
          ref: h,
          style: {
            padding: "16px",
            textAlign: "center",
            color: "var(--orca-color-text-3)",
            fontSize: "13px"
          },
          children: m ? /* @__PURE__ */ o.jsxs("span", { children: [
            "加载更多... (",
            f,
            "/",
            t.length,
            ")"
          ] }) : t.length > Zt ? /* @__PURE__ */ o.jsxs("span", { children: [
            "已加载全部 ",
            t.length,
            " 张卡片"
          ] }) : null
        }
      )
    ] }) })
  ] });
}
function Cl({ panelId: e, pluginName: t, onClose: r }) {
  const [n, a] = we("dashboard"), [s, i] = we(null), [c, l] = we([]), [d, u] = we({ decks: [], totalCards: 0, totalNew: 0, totalOverdue: 0 }), [f, x] = we({ pendingCount: 0, todayCount: 0, newCount: 0, totalCount: 0 }), [h, y] = we(!0), [g, S] = we(null), [m, v] = we("all"), [C, M] = we(null), [b, P] = we(null), [N, T] = we(null), O = Te(async () => {
    y(!0), S(null);
    try {
      const { collectReviewCards: A, calculateDeckStats: L } = await Promise.resolve().then(() => He), { calculateHomeStats: Y } = await Promise.resolve().then(() => Bo), { getAllDeckNotes: ee } = await Promise.resolve().then(() => Jr), {
        getReviewHistory: xe,
        getFutureForecast: ge,
        getTodayStatistics: R
      } = await Promise.resolve().then(() => tr), W = await A(t);
      l(W);
      const Q = L(W), U = await ee(t), oe = {
        ...Q,
        decks: Q.decks.map((ve) => ({
          ...ve,
          note: U[ve.name] || ""
        }))
      };
      u(oe);
      const X = Y(W);
      x(X);
      const [q, de, ne] = await Promise.all([
        xe(t, "3months"),
        ge(t, 30),
        R(t)
      ]);
      M(q), P(de), T(ne);
    } catch (A) {
      console.error(`[${t}] Flash Home 加载数据失败:`, A), S(A instanceof Error ? A.message : String(A));
    } finally {
      y(!1);
    }
  }, [t]);
  at(() => {
    O();
  }, [O]), at(() => {
    const L = setInterval(async () => {
      try {
        const { collectReviewCards: Y, calculateDeckStats: ee } = await Promise.resolve().then(() => He), { calculateHomeStats: xe } = await Promise.resolve().then(() => Bo), { getAllDeckNotes: ge } = await Promise.resolve().then(() => Jr), R = await Y(t), W = f.pendingCount, Q = xe(R);
        Q.pendingCount > W && console.log(`[${t}] Flash Home: 发现新到期卡片，从 ${W} 增加到 ${Q.pendingCount}`), l(R);
        const U = ee(R), oe = await ge(t), X = {
          ...U,
          decks: U.decks.map((q) => ({
            ...q,
            note: oe[q.name] || ""
          }))
        };
        u(X), x(Q);
      } catch (Y) {
        console.warn(`[${t}] Flash Home 自动刷新失败:`, Y);
      }
    }, 12e4);
    return () => clearInterval(L);
  }, [t, f.pendingCount]);
  const H = Mt(O);
  H.current = O;
  const z = Mt({ graded: null, postponed: null, suspended: null });
  at(() => {
    const A = () => {
      console.log(`[${t}] Flash Home: 收到 CARD_GRADED 事件，静默刷新`), H.current();
    }, L = () => {
      console.log(`[${t}] Flash Home: 收到 CARD_POSTPONED 事件，静默刷新`), H.current();
    }, Y = () => {
      console.log(`[${t}] Flash Home: 收到 CARD_SUSPENDED 事件，静默刷新`), H.current();
    };
    return z.current = {
      graded: A,
      postponed: L,
      suspended: Y
    }, orca.broadcasts.isHandlerRegistered(Pe.CARD_GRADED) || orca.broadcasts.registerHandler(Pe.CARD_GRADED, A), orca.broadcasts.isHandlerRegistered(Pe.CARD_POSTPONED) || orca.broadcasts.registerHandler(Pe.CARD_POSTPONED, L), orca.broadcasts.isHandlerRegistered(Pe.CARD_SUSPENDED) || orca.broadcasts.registerHandler(Pe.CARD_SUSPENDED, Y), () => {
      const ee = z.current;
      ee.graded && orca.broadcasts.unregisterHandler(Pe.CARD_GRADED, ee.graded), ee.postponed && orca.broadcasts.unregisterHandler(Pe.CARD_POSTPONED, ee.postponed), ee.suspended && orca.broadcasts.unregisterHandler(Pe.CARD_SUSPENDED, ee.suspended);
    };
  }, [t]);
  const D = Et(() => s ? c.filter((A) => A.deck === s) : [], [c, s]), _ = Et(() => Li(D, m), [D, m]), j = Te((A) => {
    i(A), v("all"), a("card-list");
  }, []), w = Te(async (A) => {
    try {
      const { startReviewSession: L } = await Promise.resolve().then(() => He);
      await L(A);
    } catch (L) {
      console.error(`[${t}] 启动牌组复习失败:`, L), orca.notify("error", "启动复习失败", { title: "SRS 复习" });
    }
  }, [t]), B = Te(async () => {
    try {
      const { startReviewSession: A } = await Promise.resolve().then(() => He);
      await A();
    } catch (A) {
      console.error(`[${t}] 启动今日复习失败:`, A), orca.notify("error", "启动复习失败", { title: "SRS 复习" });
    }
  }, [t]), J = Te(async (A) => {
    try {
      const { resetCardSrsState: L, resetClozeSrsState: Y, resetDirectionSrsState: ee } = await Promise.resolve().then(() => Oo);
      let xe;
      A.clozeNumber ? xe = await Y(A.id, A.clozeNumber) : A.directionType ? xe = await ee(A.id, A.directionType) : xe = await L(A.id), l((ge) => ge.map((R) => (A.clozeNumber ? R.id === A.id && R.clozeNumber === A.clozeNumber : A.directionType ? R.id === A.id && R.directionType === A.directionType : R.id === A.id) ? { ...R, srs: xe, isNew: !0 } : R)), orca.notify("success", "卡片已重置为新卡", { title: "SRS" });
    } catch (L) {
      console.error(`[${t}] 重置卡片失败:`, L), orca.notify("error", "重置卡片失败", { title: "SRS" });
    }
  }, [t]), G = Te(async (A) => {
    l((L) => L.filter((Y) => A.clozeNumber ? !(Y.id === A.id && Y.clozeNumber === A.clozeNumber) : A.directionType ? !(Y.id === A.id && Y.directionType === A.directionType) : Y.id !== A.id));
    try {
      const { deleteCardSrsData: L, deleteClozeCardSrsData: Y, deleteDirectionCardSrsData: ee } = await Promise.resolve().then(() => Oo);
      A.clozeNumber ? await Y(A.id, A.clozeNumber) : A.directionType ? await ee(A.id, A.directionType) : await L(A.id), await orca.commands.invokeEditorCommand(
        "core.editor.removeTag",
        null,
        A.id,
        "card"
      ), orca.notify("success", "卡片已删除", { title: "SRS" });
    } catch (L) {
      console.error(`[${t}] 删除卡片失败:`, L), orca.notify("error", "删除卡片失败", { title: "SRS" });
    }
  }, [t]), pe = Te((A) => {
    orca.nav.openInLastPanel("block", { blockId: A });
  }, []), se = Te(() => {
    a("deck-list"), i(null), v("all");
  }, []), k = Te(() => {
    a("statistics");
  }, []), ue = Te(() => {
    a("difficult-cards");
  }, []), Ce = Te((A) => {
    v(A);
  }, []), $e = Te(async (A) => {
    try {
      const { createRepeatReviewSession: L } = await Promise.resolve().then(() => Mi), { getOrCreateReviewSessionBlock: Y } = await Promise.resolve().then(() => ra);
      L(A, 0, "children");
      const ee = await Y(t);
      orca.nav.openInLastPanel("block", { blockId: ee }), orca.notify("success", `已开始复习 ${A.length} 张困难卡片`, { title: "SRS 复习" });
    } catch (L) {
      console.error(`[${t}] 启动困难卡片复习失败:`, L), orca.notify("error", "启动复习失败", { title: "SRS 复习" });
    }
  }, [t]), Ae = Te(() => {
    O();
  }, [O]), Ee = Te((A, L) => {
    u((Y) => ({
      ...Y,
      decks: Y.decks.map(
        (ee) => ee.name === A ? { ...ee, note: L } : ee
      )
    }));
  }, []);
  return h ? /* @__PURE__ */ o.jsx("div", { style: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    minHeight: "200px",
    fontSize: "14px",
    color: "var(--orca-color-text-2)"
  }, children: "加载中..." }) : g ? /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    padding: "24px",
    alignItems: "center",
    justifyContent: "center",
    minHeight: "200px"
  }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: { color: "var(--orca-color-danger-5)" }, children: [
      "加载失败：",
      g
    ] }),
    /* @__PURE__ */ o.jsx(fe, { variant: "solid", onClick: Ae, children: "重试" })
  ] }) : /* @__PURE__ */ o.jsx("div", { style: {
    padding: "16px",
    height: "100%",
    overflow: "auto"
  }, children: n === "dashboard" ? /* @__PURE__ */ o.jsxs("div", { className: "srs-dashboard-view", children: [
    /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: "16px"
    }, children: [
      /* @__PURE__ */ o.jsxs("div", { style: {
        display: "flex",
        gap: "8px"
      }, children: [
        /* @__PURE__ */ o.jsx(
          fe,
          {
            variant: "solid",
            onClick: () => a("dashboard"),
            style: { fontSize: "13px", padding: "6px 12px" },
            children: "主页"
          }
        ),
        /* @__PURE__ */ o.jsx(
          fe,
          {
            variant: "plain",
            onClick: () => a("deck-list"),
            style: { fontSize: "13px", padding: "6px 12px" },
            children: "卡组"
          }
        ),
        /* @__PURE__ */ o.jsx(
          fe,
          {
            variant: "plain",
            onClick: k,
            style: { fontSize: "13px", padding: "6px 12px" },
            children: "统计"
          }
        )
      ] }),
      /* @__PURE__ */ o.jsxs("div", { style: { display: "flex", gap: "8px" }, children: [
        /* @__PURE__ */ o.jsxs(
          fe,
          {
            variant: "plain",
            onClick: ue,
            style: { fontSize: "13px", padding: "6px 12px", color: "var(--orca-color-danger-6)" },
            children: [
              /* @__PURE__ */ o.jsx("i", { className: "ti ti-alert-triangle", style: { marginRight: "4px" } }),
              "困难卡片"
            ]
          }
        ),
        /* @__PURE__ */ o.jsx(
          fe,
          {
            variant: "plain",
            onClick: Ae,
            style: { fontSize: "13px", padding: "6px 12px" },
            children: /* @__PURE__ */ o.jsx("i", { className: "ti ti-refresh" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ o.jsx(
      yl,
      {
        pluginName: t,
        todayStats: N,
        reviewHistory: C,
        futureForecast: b,
        totalCards: f.totalCount,
        newCards: f.newCount,
        dueCards: f.pendingCount,
        onStartReview: B,
        onRefresh: Ae,
        isLoading: h
      }
    )
  ] }) : n === "deck-list" ? /* @__PURE__ */ o.jsxs("div", { className: "srs-deck-list-view", children: [
    /* @__PURE__ */ o.jsx("div", { style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: "16px"
    }, children: /* @__PURE__ */ o.jsxs("div", { style: {
      display: "flex",
      gap: "8px"
    }, children: [
      /* @__PURE__ */ o.jsx(
        fe,
        {
          variant: "plain",
          onClick: () => a("dashboard"),
          style: { fontSize: "13px", padding: "6px 12px" },
          children: "主页"
        }
      ),
      /* @__PURE__ */ o.jsx(
        fe,
        {
          variant: "solid",
          onClick: () => a("deck-list"),
          style: { fontSize: "13px", padding: "6px 12px" },
          children: "卡组"
        }
      ),
      /* @__PURE__ */ o.jsx(
        fe,
        {
          variant: "plain",
          onClick: k,
          style: { fontSize: "13px", padding: "6px 12px" },
          children: "统计"
        }
      )
    ] }) }),
    /* @__PURE__ */ o.jsx(
      wl,
      {
        deckStats: d,
        todayStats: f,
        panelId: e,
        pluginName: t,
        onViewDeck: j,
        onReviewDeck: w,
        onStartTodayReview: B,
        onRefresh: Ae,
        onNoteChange: Ee,
        onShowStatistics: k,
        onShowDifficultCards: ue
      }
    )
  ] }) : n === "statistics" ? /* @__PURE__ */ o.jsx("div", { className: "srs-statistics-view", children: /* @__PURE__ */ o.jsx(
    nl,
    {
      panelId: e,
      pluginName: t,
      onBack: se,
      decks: d.decks
    }
  ) }) : n === "difficult-cards" ? /* @__PURE__ */ o.jsx("div", { className: "srs-difficult-cards-view", children: /* @__PURE__ */ o.jsx(
    cl,
    {
      panelId: e,
      pluginName: t,
      onBack: se,
      onStartReview: $e
    }
  ) }) : /* @__PURE__ */ o.jsx("div", { className: "srs-flash-home-view", children: /* @__PURE__ */ o.jsx(
    Sl,
    {
      deckName: s || "",
      cards: _,
      allDeckCards: D,
      currentFilter: m,
      panelId: e,
      onFilterChange: Ce,
      onCardClick: pe,
      onCardReset: J,
      onCardDelete: G,
      onBack: se,
      onReviewDeck: w
    }
  ) }) });
}
const { useState: Wr, useEffect: jl } = window.React, { BlockShell: kl, Button: Rl } = orca.components;
function $l(e) {
  const {
    panelId: t,
    blockId: r,
    rndId: n,
    blockLevel: a,
    indentLevel: s,
    mirrorId: i,
    initiallyCollapsed: c,
    renderingMode: l
  } = e, [d, u] = Wr("orca-srs"), [f, x] = Wr(!0), [h, y] = Wr(null);
  jl(() => {
    g();
  }, []);
  const g = async () => {
    x(!0), y(null);
    try {
      const { getPluginName: C } = await Promise.resolve().then(() => He), M = typeof C == "function" ? C() : "orca-srs";
      u(M);
    } catch (C) {
      console.error("[SRS Flashcard Home Renderer] 加载插件名称失败:", C), y(C instanceof Error ? C.message : String(C));
    } finally {
      x(!1);
    }
  }, S = () => {
    orca.nav.close(t);
  }, m = () => {
    g();
  }, v = () => f ? /* @__PURE__ */ o.jsx("div", { style: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    minHeight: "200px",
    fontSize: "14px",
    color: "var(--orca-color-text-2)"
  }, children: "加载中..." }) : h ? /* @__PURE__ */ o.jsxs("div", { style: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    padding: "24px",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center"
  }, children: [
    /* @__PURE__ */ o.jsxs("div", { style: { color: "var(--orca-color-danger-5)" }, children: [
      "加载失败：",
      h
    ] }),
    /* @__PURE__ */ o.jsx(Rl, { variant: "solid", onClick: m, children: "重试" })
  ] }) : /* @__PURE__ */ o.jsx(
    ot,
    {
      componentName: "Flash Home",
      errorTitle: "Flash Home 加载出错",
      children: /* @__PURE__ */ o.jsx(
        Cl,
        {
          panelId: t,
          pluginName: d,
          onClose: S
        }
      )
    }
  );
  return /* @__PURE__ */ o.jsx(
    kl,
    {
      panelId: t,
      blockId: r,
      rndId: n,
      mirrorId: i,
      blockLevel: a,
      indentLevel: s,
      initiallyCollapsed: c,
      renderingMode: l,
      reprClassName: "srs-repr-flashcard-home",
      contentClassName: "srs-repr-flashcard-home-content",
      contentJsx: v(),
      childrenJsx: null
    }
  );
}
const { useRef: Dl } = window.React;
function _l({
  blockId: e,
  data: t,
  index: r
}) {
  const n = Dl(null), a = t.v || "", s = t.clozeNumber || 1;
  return /* @__PURE__ */ o.jsx(
    "span",
    {
      ref: n,
      className: "orca-inline srs-cloze-inline",
      "data-cloze-number": s,
      style: {
        color: "#999",
        // 浅灰色
        borderBottom: "2px solid #4a90e2",
        // 蓝色下划线
        paddingBottom: "1px",
        cursor: "text"
      },
      title: `Cloze ${s}`,
      children: a
    }
  );
}
const { useRef: Tl, useState: un, useCallback: zl } = window.React, fn = {
  forward: "ti ti-arrow-right",
  backward: "ti ti-arrow-left",
  bidirectional: "ti ti-arrows-exchange"
}, pn = {
  forward: "var(--orca-color-primary-5)",
  backward: "var(--orca-color-warning-5)",
  bidirectional: "var(--orca-color-success-5)"
}, Or = {
  forward: "正向",
  backward: "反向",
  bidirectional: "双向"
};
function El({
  blockId: e,
  data: t,
  index: r
}) {
  const n = Tl(null), a = t.direction || "forward", [s, i] = un(a), [c, l] = un(!1), d = (t.t || "").replace(".direction", ""), u = fn[s] || fn.forward, f = pn[s] || pn.forward, x = Or[s] || Or.forward, h = zl(
    async (y) => {
      if (y.preventDefault(), y.stopPropagation(), !c) {
        l(!0);
        try {
          const g = Es(s);
          i(g), await Ms(Number(e), g, d);
          const S = Or[g] || "未知";
          orca.notify("info", `已切换为${S}卡片`);
        } catch (g) {
          console.error("切换方向失败:", g), i(a);
        } finally {
          l(!1);
        }
      }
    },
    [e, s, a, c, d]
  );
  return /* @__PURE__ */ o.jsx(
    "span",
    {
      ref: n,
      className: "orca-inline srs-direction-inline",
      onClick: h,
      style: {
        cursor: c ? "wait" : "pointer",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: "24px",
        height: "24px",
        fontSize: "16px",
        margin: "0 4px",
        borderRadius: "4px",
        backgroundColor: "var(--orca-color-bg-2)",
        color: f,
        transition: "all 0.2s ease",
        opacity: c ? 0.5 : 1
      },
      title: `方向卡 (${x}) - 点击切换`,
      children: /* @__PURE__ */ o.jsx("i", { className: u })
    }
  );
}
function Ml(e) {
  orca.renderers.registerBlock(
    "srs.card",
    !1,
    Er,
    [],
    !1
  ), orca.renderers.registerBlock(
    "srs.cloze-card",
    !1,
    Er,
    [],
    !1
  ), orca.renderers.registerBlock(
    "srs.direction-card",
    !1,
    Er,
    [],
    !1
  ), orca.renderers.registerBlock(
    "srs.review-session",
    !1,
    Fi,
    [],
    !1
  ), orca.renderers.registerBlock(
    "srs.flashcard-home",
    !1,
    $l,
    [],
    !1
  ), orca.renderers.registerInline(
    `${e}.cloze`,
    !1,
    _l
  ), orca.renderers.registerInline(
    `${e}.direction`,
    !1,
    El
  );
}
function Al(e) {
  orca.renderers.unregisterBlock("srs.card"), orca.renderers.unregisterBlock("srs.cloze-card"), orca.renderers.unregisterBlock("srs.direction-card"), orca.renderers.unregisterBlock("srs.review-session"), orca.renderers.unregisterBlock("srs.flashcard-home"), orca.renderers.unregisterInline(`${e}.cloze`), orca.renderers.unregisterInline(`${e}.direction`);
}
function Bl(e) {
  orca.converters.registerBlock(
    "plain",
    "srs.card",
    (t, r) => {
      const n = r.front || "（无题目）", a = r.back || "（无答案）";
      return `[SRS 卡片]
题目: ${n}
答案: ${a}`;
    }
  ), orca.converters.registerBlock(
    "plain",
    "srs.cloze-card",
    (t, r) => {
      const n = r.front || "（无题目）", a = r.back || "（无答案）";
      return `[SRS 填空卡片]
题目: ${n}
答案: ${a}`;
    }
  ), orca.converters.registerBlock(
    "plain",
    "srs.direction-card",
    (t, r) => {
      const n = r.front || "（左侧）", a = r.back || "（右侧）", s = r.direction || "forward";
      return `[SRS 方向卡片]
${n} ${s === "forward" ? "->" : s === "backward" ? "<-" : "<->"} ${a}`;
    }
  ), orca.converters.registerBlock(
    "plain",
    "srs.review-session",
    () => "[SRS 复习会话面板块]"
  ), orca.converters.registerBlock(
    "plain",
    "srs.flashcard-home",
    () => "[SRS Flashcard Home 面板块]"
  ), orca.converters.registerInline(
    "plain",
    `${e}.cloze`,
    (t) => t.v || ""
  ), orca.converters.registerInline(
    "plain",
    `${e}.direction`,
    (t) => {
      const r = t.direction || "forward";
      return ` ${r === "forward" ? "->" : r === "backward" ? "<-" : "<->"} `;
    }
  );
}
function Fl(e) {
  orca.converters.unregisterBlock("plain", "srs.card"), orca.converters.unregisterBlock("plain", "srs.cloze-card"), orca.converters.unregisterBlock("plain", "srs.direction-card"), orca.converters.unregisterBlock("plain", "srs.review-session"), orca.converters.unregisterBlock("plain", "srs.flashcard-home"), orca.converters.unregisterInline("plain", `${e}.cloze`), orca.converters.unregisterInline("plain", `${e}.direction`);
}
const lr = [], Hr = /* @__PURE__ */ new Map();
function ea(e, t, r, n) {
  const a = e instanceof Error ? e.message : String(e);
  if (a.includes("load") || a.includes("fetch") || a.includes("network") || a.includes("timeout")) {
    const i = Hr.get(r), c = (i == null ? void 0 : i.retryCount) ?? 0;
    c < 2 ? (Hr.set(r, { type: n, retryCount: c + 1 }), orca.notify("error", "卡片加载失败，请稍后重试", {
      title: "SRS 复习"
    })) : (Hr.delete(r), orca.notify("error", `卡片加载失败: ${a}`, { title: "SRS 复习" }));
  } else
    orca.notify("error", `启动复习失败: ${a}`, { title: "SRS 复习" });
}
function Pl(e) {
  const t = `${e}.reviewQueryResults`;
  orca.blockMenuCommands.registerBlockMenuCommand(t, {
    worksOnMultipleBlocks: !1,
    render: (n, a, s) => {
      var c;
      const i = (c = orca.state.blocks) == null ? void 0 : c[n];
      return !i || !or(i) ? null : /* @__PURE__ */ o.jsx(
        Wl,
        {
          blockId: n,
          pluginName: e,
          close: s
        }
      );
    }
  }), lr.push(t);
  const r = `${e}.reviewChildrenCards`;
  orca.blockMenuCommands.registerBlockMenuCommand(r, {
    worksOnMultipleBlocks: !1,
    render: (n, a, s) => {
      var c;
      const i = (c = orca.state.blocks) == null ? void 0 : c[n];
      return !i || or(i) ? null : /* @__PURE__ */ o.jsx(
        Ol,
        {
          blockId: n,
          pluginName: e,
          close: s
        }
      );
    }
  }), lr.push(r), console.log(`[${e}] 右键菜单已注册`);
}
function Ll(e) {
  for (const t of lr)
    orca.blockMenuCommands.unregisterBlockMenuCommand(t);
  lr.length = 0, console.log(`[${e}] 右键菜单已注销`);
}
function Wl({
  blockId: e,
  pluginName: t,
  close: r
}) {
  const [n, a] = React.useState(null), [s, i] = React.useState(!0), [c, l] = React.useState(!1), [d, u] = React.useState(!1);
  React.useEffect(() => {
    let y = !1;
    async function g() {
      try {
        const { getQueryResults: S } = await Promise.resolve().then(() => nr), m = await S(e);
        if (!y && m.length === 0) {
          u(!0), a(0), i(!1);
          return;
        }
        const v = await yo(e, !0);
        y || (a(v), i(!1));
      } catch (S) {
        console.error(`[${t}] 获取查询块卡片数量失败:`, S), y || (l(!0), a(0), i(!1));
      }
    }
    return g(), () => {
      y = !0;
    };
  }, [e, t]);
  const f = async () => {
    var y;
    r();
    try {
      if (!((y = orca.state.blocks) == null ? void 0 : y[e]) && !await orca.invokeBackend("get-block", e)) {
        orca.notify("error", "块不存在", { title: "SRS 复习" });
        return;
      }
      const { getQueryResults: S } = await Promise.resolve().then(() => nr);
      if ((await S(e)).length === 0) {
        orca.notify("info", "查询结果为空", { title: "SRS 复习" });
        return;
      }
      const v = await ho(e, t);
      if (v.length === 0) {
        orca.notify("info", "查询结果中没有找到卡片", { title: "SRS 复习" });
        return;
      }
      br(v, e, "query"), await ta(t), orca.notify("success", `已开始复习 ${v.length} 张卡片`, { title: "SRS 复习" });
    } catch (g) {
      console.error(`[${t}] 启动查询块复习失败:`, g), ea(g, t, e, "query");
    }
  }, x = orca.components.MenuText;
  let h;
  return s ? h = "复习此查询结果..." : c ? h = "复习此查询结果 (加载失败)" : d ? h = "复习此查询结果 (查询为空)" : n === 0 ? h = "复习此查询结果 (0)" : h = `复习此查询结果 (${n})`, /* @__PURE__ */ o.jsx(
    x,
    {
      preIcon: "ti ti-cards",
      title: h,
      disabled: s || n === 0 || c,
      onClick: f
    }
  );
}
function Ol({
  blockId: e,
  pluginName: t,
  close: r
}) {
  const [n, a] = React.useState(null), [s, i] = React.useState(!0), [c, l] = React.useState(!1);
  React.useEffect(() => {
    let f = !1;
    async function x() {
      try {
        const h = await yo(e, !1);
        f || (a(h), l(h > 0), i(!1));
      } catch (h) {
        console.error(`[${t}] 获取子块卡片数量失败:`, h), f || (l(!1), i(!1));
      }
    }
    return x(), () => {
      f = !0;
    };
  }, [e, t]);
  const d = async () => {
    r();
    try {
      const f = await go(e, t);
      if (f.length === 0) {
        orca.notify("info", "子块中没有找到卡片", { title: "SRS 复习" });
        return;
      }
      br(f, e, "children"), await ta(t), orca.notify("success", `已开始复习 ${f.length} 张卡片`, { title: "SRS 复习" });
    } catch (f) {
      console.error(`[${t}] 启动子块复习失败:`, f), ea(f, t, e, "children");
    }
  };
  if (s || !c)
    return null;
  const u = orca.components.MenuText;
  return /* @__PURE__ */ o.jsx(
    u,
    {
      preIcon: "ti ti-cards",
      title: `复习此块卡片 (${n})`,
      onClick: d
    }
  );
}
async function ta(e) {
  const { getOrCreateReviewSessionBlock: t } = await Promise.resolve().then(() => ra), r = orca.state.activePanel;
  if (!r) {
    orca.notify("warn", "当前没有可用的面板", { title: "SRS 复习" });
    return;
  }
  const n = await t(e), a = orca.state.panels;
  let s = null;
  for (const [i, c] of Object.entries(a))
    if (c.parentId === r && c.position === "right") {
      s = i;
      break;
    }
  if (s)
    orca.nav.goTo("block", { blockId: n }, s);
  else if (s = orca.nav.addTo(r, "right", {
    view: "block",
    viewArgs: { blockId: n },
    viewState: {}
  }), !s) {
    orca.notify("error", "无法创建侧边面板", { title: "SRS 复习" });
    return;
  }
  s && setTimeout(() => {
    orca.nav.switchFocusTo(s);
  }, 100), console.log(`[${e}] 重复复习会话已启动，面板ID: ${s}`);
}
let Rt = null;
const xn = "reviewSessionBlockId";
async function wo(e) {
  if (Rt && await hn(Rt))
    return Rt;
  const t = await orca.plugins.getData(e, xn);
  if (typeof t == "number" && await hn(t))
    return Rt = t, t;
  const r = await Hl(e);
  return await orca.plugins.setData(e, xn, r), Rt = r, r;
}
async function Hl(e) {
  var n;
  const t = await orca.commands.invokeEditorCommand(
    "core.editor.insertBlock",
    null,
    null,
    null,
    [{ t: "t", v: `[SRS 复习会话 - ${e}]` }],
    { type: "srs.review-session" }
  );
  await orca.commands.invokeEditorCommand(
    "core.editor.setProperties",
    null,
    [t],
    [
      { name: "srs.isReviewSessionBlock", value: !0, type: 4 },
      { name: "srs.pluginName", value: e, type: 2 }
    ]
  );
  const r = (n = orca.state.blocks) == null ? void 0 : n[t];
  return r && (r._repr = {
    type: "srs.review-session"
  }), console.log(`[${e}] 创建复习会话块: #${t}`), t;
}
async function hn(e) {
  var r;
  const t = (r = orca.state.blocks) == null ? void 0 : r[e];
  if (t) return t;
  try {
    return await orca.invokeBackend("get-block", e);
  } catch (n) {
    return console.warn("[srs] 无法从后端获取复习会话块:", n), null;
  }
}
const ra = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getOrCreateReviewSessionBlock: wo
}, Symbol.toStringTag, { value: "Module" }));
let $t = null;
const gn = "flashcardHomeBlockId";
async function Il(e) {
  if ($t && await yn($t))
    return $t;
  const t = await orca.plugins.getData(e, gn);
  if (typeof t == "number" && await yn(t))
    return $t = t, t;
  const r = await Nl(e);
  return await orca.plugins.setData(e, gn, r), $t = r, r;
}
async function Nl(e) {
  var n;
  const t = await orca.commands.invokeEditorCommand(
    "core.editor.insertBlock",
    null,
    null,
    null,
    [{ t: "t", v: `[SRS Flashcard Home - ${e}]` }],
    { type: "srs.flashcard-home" }
  );
  await orca.commands.invokeEditorCommand(
    "core.editor.setProperties",
    null,
    [t],
    [
      { name: "srs.isFlashcardHomeBlock", value: !0, type: 4 },
      { name: "srs.pluginName", value: e, type: 2 }
    ]
  );
  const r = (n = orca.state.blocks) == null ? void 0 : n[t];
  return r && (r._repr = {
    type: "srs.flashcard-home"
  }), console.log(`[${e}] 创建 Flash Home 块: #${t}`), t;
}
async function yn(e) {
  var r;
  const t = (r = orca.state.blocks) == null ? void 0 : r[e];
  if (t) return t;
  try {
    return await orca.invokeBackend("get-block", e);
  } catch (n) {
    return console.warn("[srs] 无法从后端获取 Flash Home 块:", n), null;
  }
}
let re, oa = null, na = null;
async function Yl(e) {
  re = e, orca.state.locale;
  try {
    await orca.plugins.setSettingsSchema(re, {
      ...Pn,
      ...ds
    }), console.log(`[${re}] 插件设置已注册（AI + 复习）`);
  } catch (t) {
    console.warn(`[${re}] 注册插件设置失败:`, t);
  }
  console.log(`[${re}] 插件已加载`), Ns(re), Vs(re), Ml(re), Bl(re), Pl(re), console.log(`[${re}] 命令、UI 组件、渲染器、转换器、右键菜单已注册`);
}
async function Ul() {
  Ys(re), Ks(re), Al(re), Fl(re), Ll(re), console.log(`[${re}] 插件已卸载`);
}
async function ql(e, t = !1) {
  try {
    oa = e ?? null;
    const r = orca.state.activePanel;
    if (!r) {
      orca.notify("warn", "当前没有可用的面板", { title: "SRS 复习" });
      return;
    }
    na = r;
    const n = await wo(re);
    if (t) {
      orca.nav.goTo("block", { blockId: n }, r);
      const c = e ? `已打开 ${e} 复习会话` : "复习会话已打开";
      orca.notify("success", c, { title: "SRS 复习" }), console.log(`[${re}] 复习会话已在当前面板启动，面板ID: ${r}`);
      return;
    }
    const a = orca.state.panels;
    let s = null;
    for (const [c, l] of Object.entries(a))
      if (l.parentId === r && l.position === "right") {
        s = c;
        break;
      }
    if (s)
      orca.nav.goTo("block", { blockId: n }, s);
    else if (s = orca.nav.addTo(r, "right", {
      view: "block",
      viewArgs: { blockId: n },
      viewState: {}
    }), !s) {
      orca.notify("error", "无法创建侧边面板", { title: "SRS 复习" });
      return;
    }
    s && setTimeout(() => {
      orca.nav.switchFocusTo(s);
    }, 100);
    const i = e ? `已打开 ${e} 复习会话` : "复习会话已在右侧面板打开";
    orca.notify("success", i, { title: "SRS 复习" }), console.log(`[${re}] 复习会话已启动，面板ID: ${s}`);
  } catch (r) {
    console.error(`[${re}] 启动复习失败:`, r), orca.notify("error", `启动复习失败: ${r}`, { title: "SRS 复习" });
  }
}
function Vl() {
  return oa;
}
function Kl() {
  return na;
}
function Gl() {
  return re;
}
async function Jl(e = !1) {
  var t;
  try {
    const r = orca.state.activePanel;
    if (!r) {
      orca.notify("warn", "当前没有可用的面板", { title: "Flash Home" });
      return;
    }
    const n = await Il(re), a = orca.state.panels;
    for (const [i, c] of Object.entries(a))
      if (((t = c.viewArgs) == null ? void 0 : t.blockId) === n) {
        orca.nav.switchFocusTo(i), console.log(`[${re}] Flash Home 已存在，聚焦到面板: ${i}`);
        return;
      }
    if (e) {
      orca.nav.goTo("block", { blockId: n }, r), orca.notify("success", "Flash Home 已打开", { title: "SRS" }), console.log(`[${re}] Flash Home 已在当前面板打开，面板ID: ${r}`);
      return;
    }
    let s = null;
    for (const [i, c] of Object.entries(a))
      if (c.parentId === r && c.position === "right") {
        s = i;
        break;
      }
    if (s)
      orca.nav.goTo("block", { blockId: n }, s);
    else if (s = orca.nav.addTo(r, "right", {
      view: "block",
      viewArgs: { blockId: n },
      viewState: {}
    }), !s) {
      orca.notify("error", "无法创建侧边面板", { title: "Flash Home" });
      return;
    }
    s && setTimeout(() => {
      orca.nav.switchFocusTo(s);
    }, 100), orca.notify("success", "Flash Home 已在右侧面板打开", { title: "SRS" }), console.log(`[${re}] Flash Home 已打开，面板ID: ${s}`);
  } catch (r) {
    console.error(`[${re}] 打开 Flash Home 失败:`, r), orca.notify("error", `打开 Flash Home 失败: ${r}`, { title: "SRS" });
  }
}
async function Ql(e, t = !1) {
  var r;
  try {
    const n = orca.state.activePanel;
    if (!n) {
      orca.notify("warn", "当前没有可用的面板", { title: "SRS 复习" });
      return;
    }
    let a = (r = orca.state.blocks) == null ? void 0 : r[e];
    if (a || (a = await orca.invokeBackend("get-block", e)), !a) {
      orca.notify("error", "块不存在", { title: "SRS 复习" });
      return;
    }
    let s, i;
    if (or(a)) {
      const { getQueryResults: u } = await Promise.resolve().then(() => nr);
      if ((await u(e)).length === 0) {
        orca.notify("info", "查询结果为空", { title: "SRS 复习" });
        return;
      }
      if (s = await ho(e, re), i = "query", s.length === 0) {
        orca.notify("info", "查询结果中没有找到卡片", { title: "SRS 复习" });
        return;
      }
    } else {
      const { getAllDescendantIds: u } = await Promise.resolve().then(() => nr);
      if ((await u(e)).length === 0) {
        orca.notify("info", "该块没有子块", { title: "SRS 复习" });
        return;
      }
      if (s = await go(e, re), i = "children", s.length === 0) {
        orca.notify("info", "子块中没有找到卡片", { title: "SRS 复习" });
        return;
      }
    }
    br(s, e, i);
    const c = await wo(re);
    if (t) {
      orca.nav.goTo("block", { blockId: c }, n), orca.notify("success", `已开始复习 ${s.length} 张卡片`, { title: "SRS 复习" }), console.log(`[${re}] 重复复习会话已在当前面板启动，面板ID: ${n}`);
      return;
    }
    const l = orca.state.panels;
    let d = null;
    for (const [u, f] of Object.entries(l))
      if (f.parentId === n && f.position === "right") {
        d = u;
        break;
      }
    if (d)
      orca.nav.goTo("block", { blockId: c }, d);
    else if (d = orca.nav.addTo(n, "right", {
      view: "block",
      viewArgs: { blockId: c },
      viewState: {}
    }), !d) {
      orca.notify("error", "无法创建侧边面板", { title: "SRS 复习" });
      return;
    }
    d && setTimeout(() => {
      orca.nav.switchFocusTo(d);
    }, 100), orca.notify("success", `已开始复习 ${s.length} 张卡片`, { title: "SRS 复习" }), console.log(`[${re}] 重复复习会话已启动，面板ID: ${d}`);
  } catch (n) {
    console.error(`[${re}] 启动重复复习失败:`, n);
    const a = n instanceof Error ? n.message : String(n);
    a.includes("load") || a.includes("fetch") || a.includes("network") || a.includes("timeout") ? orca.notify("error", "卡片加载失败，请稍后重试", { title: "SRS 复习" }) : orca.notify("error", `启动复习失败: ${a}`, { title: "SRS 复习" });
  }
}
const He = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  buildReviewQueue: uo,
  buildReviewQueueWithChildren: Fn,
  calculateDeckStats: mn,
  collectChildCards: Un,
  collectReviewCards: st,
  extractDeckName: Bt,
  getCardKey: Vn,
  getPluginName: Gl,
  getReviewDeckFilter: Vl,
  getReviewHostPanelId: Kl,
  hasChildCards: qn,
  load: Yl,
  openFlashcardHome: Jl,
  startRepeatReviewSession: Ql,
  startReviewSession: ql,
  unload: Ul
}, Symbol.toStringTag, { value: "Module" }));
function So(e) {
  const t = /* @__PURE__ */ new Date();
  switch (e) {
    case "1month":
      return new Date(t.getFullYear(), t.getMonth() - 1, t.getDate());
    case "3months":
      return new Date(t.getFullYear(), t.getMonth() - 3, t.getDate());
    case "1year":
      return new Date(t.getFullYear() - 1, t.getMonth(), t.getDate());
    case "all":
      return /* @__PURE__ */ new Date(0);
  }
}
class Xl {
  constructor() {
    ce(this, "cache", /* @__PURE__ */ new Map());
    ce(this, "defaultTTL", 3e4);
    // 默认缓存 30 秒
    ce(this, "maxEntries", 100);
  }
  // 最大缓存条目数
  /**
   * 生成缓存键
   */
  generateKey(t, ...r) {
    return `${t}:${r.filter((n) => n !== void 0).join(":")}`;
  }
  /**
   * 获取缓存数据
   */
  get(t, ...r) {
    const n = this.generateKey(t, ...r), a = this.cache.get(n);
    return a ? Date.now() - a.timestamp > this.defaultTTL ? (this.cache.delete(n), null) : a.data : null;
  }
  /**
   * 设置缓存数据
   */
  set(t, r, ...n) {
    const a = this.generateKey(t, ...n);
    if (this.cache.size >= this.maxEntries) {
      const s = this.cache.keys().next().value;
      s && this.cache.delete(s);
    }
    this.cache.set(a, {
      data: r,
      timestamp: Date.now(),
      key: a
    });
  }
  /**
   * 清除特定类型的缓存
   */
  invalidate(t) {
    const r = `${t}:`;
    for (const n of this.cache.keys())
      n.startsWith(r) && this.cache.delete(n);
  }
  /**
   * 清除所有缓存
   */
  clear() {
    this.cache.clear();
  }
  /**
   * 获取缓存统计信息
   */
  getStats() {
    return {
      size: this.cache.size,
      maxSize: this.maxEntries
    };
  }
}
const me = new Xl();
function Zl() {
  me.clear();
}
function aa(e) {
  const t = new Date(e), r = /* @__PURE__ */ new Date();
  return t.getFullYear() === r.getFullYear() && t.getMonth() === r.getMonth() && t.getDate() === r.getDate();
}
function At(e) {
  return new Date(e.getFullYear(), e.getMonth(), e.getDate());
}
function Wt(e, t) {
  return t ? e.filter((r) => r.deckName === t) : e;
}
function Ot(e, t) {
  return t ? e.filter((r) => r.deck === t) : e;
}
function sa(e, t) {
  const n = Wt(e, t).filter((s) => aa(s.timestamp)), a = {
    reviewedCount: n.length,
    newLearnedCount: 0,
    relearnedCount: 0,
    totalTime: 0,
    gradeDistribution: {
      again: 0,
      hard: 0,
      good: 0,
      easy: 0
    }
  };
  for (const s of n)
    a.totalTime += s.duration, a.gradeDistribution[s.grade]++, s.previousState === "new" && a.newLearnedCount++, s.grade === "again" && a.relearnedCount++;
  return a;
}
async function ec(e, t) {
  const r = me.get("todayStats", e, t);
  if (r)
    return r;
  const a = At(/* @__PURE__ */ new Date()), s = new Date(a);
  s.setDate(s.getDate() + 1);
  const i = await Lt(e, a, s), c = sa(i, t);
  return me.set("todayStats", c, e, t), c;
}
function ia(e, t, r) {
  const n = Ot(e, r), s = At(/* @__PURE__ */ new Date()), i = [];
  let c = 0;
  for (let l = 0; l < t; l++) {
    const d = new Date(s);
    d.setDate(d.getDate() + l);
    const u = new Date(d);
    u.setDate(u.getDate() + 1);
    let f = 0, x = 0;
    for (const h of n) {
      const y = At(h.srs.due);
      y.getTime() >= d.getTime() && y.getTime() < u.getTime() && (h.isNew ? x++ : f++);
    }
    c += f + x, i.push({
      date: d,
      reviewDue: f,
      newAvailable: x,
      cumulative: c
    });
  }
  return { days: i };
}
async function tc(e, t = 30, r) {
  const n = me.get("futureForecast", e, t, r);
  if (n)
    return n;
  const a = await st(e), s = ia(a, t, r);
  return me.set("futureForecast", s, e, t, r), s;
}
function la(e, t, r, n) {
  const a = Wt(e, n), s = At(t), i = At(r), c = /* @__PURE__ */ new Map(), l = new Date(s);
  for (; l <= i; ) {
    const h = l.toISOString().split("T")[0];
    c.set(h, {
      date: new Date(l),
      again: 0,
      hard: 0,
      good: 0,
      easy: 0,
      total: 0
    }), l.setDate(l.getDate() + 1);
  }
  let d = 0;
  for (const h of a) {
    const g = new Date(h.timestamp).toISOString().split("T")[0], S = c.get(g);
    S && (S[h.grade]++, S.total++, d++);
  }
  const u = Array.from(c.values()).sort(
    (h, y) => h.date.getTime() - y.date.getTime()
  ), f = u.length || 1, x = d / f;
  return {
    days: u,
    totalReviews: d,
    averagePerDay: x
  };
}
async function rc(e, t, r) {
  const n = me.get("reviewHistory", e, t, r);
  if (n)
    return n;
  const a = /* @__PURE__ */ new Date(), s = So(t), i = await Lt(e, s, a), c = la(i, s, a, r);
  return me.set("reviewHistory", c, e, t, r), c;
}
function ca(e, t) {
  const r = Ot(e, t), n = {
    new: 0,
    learning: 0,
    review: 0,
    suspended: 0,
    total: r.length
  };
  for (const a of r)
    if (a.isNew)
      n.new++;
    else {
      const s = a.srs.state;
      s === 1 || s === 3 ? n.learning++ : n.review++;
    }
  return n;
}
async function oc(e, t) {
  const r = me.get("cardStateDistribution", e, t);
  if (r)
    return r;
  const n = await st(e), a = ca(n, t);
  return me.set("cardStateDistribution", a, e, t), a;
}
function da(e, t, r, n) {
  const a = Wt(e, n), s = (g) => g.toISOString().split("T")[0], i = (g) => {
    const S = s(g);
    return /* @__PURE__ */ new Date(S + "T00:00:00.000Z");
  }, c = i(t), l = i(r), d = /* @__PURE__ */ new Map(), u = new Date(c);
  for (; u <= l; ) {
    const g = s(u);
    d.set(g, {
      date: new Date(u),
      time: 0
    }), u.setUTCDate(u.getUTCDate() + 1);
  }
  let f = 0;
  for (const g of a) {
    const S = new Date(g.timestamp), m = s(S), v = d.get(m);
    v && (v.time += g.duration, f += g.duration);
  }
  const x = Array.from(d.values()).sort(
    (g, S) => g.date.getTime() - S.date.getTime()
  ), h = x.length || 1, y = f / h;
  return {
    dailyTime: x,
    averagePerDay: y,
    totalTime: f
  };
}
async function nc(e, t, r) {
  const n = me.get("reviewTimeStats", e, t, r);
  if (n)
    return n;
  const a = /* @__PURE__ */ new Date(), s = So(t), i = await Lt(e, s, a), c = da(i, s, a, r);
  return me.set("reviewTimeStats", c, e, t, r), c;
}
const ac = [
  { label: "0-1天", minDays: 0, maxDays: 1 },
  { label: "1-3天", minDays: 1, maxDays: 3 },
  { label: "3-7天", minDays: 3, maxDays: 7 },
  { label: "7-14天", minDays: 7, maxDays: 14 },
  { label: "14-30天", minDays: 14, maxDays: 30 },
  { label: "30-90天", minDays: 30, maxDays: 90 },
  { label: "90天以上", minDays: 90, maxDays: 1 / 0 }
];
function ua(e, t) {
  const r = Ot(e, t), n = ac.map((c) => ({
    label: c.label,
    minDays: c.minDays,
    maxDays: c.maxDays,
    count: 0
  }));
  let a = 0, s = 0;
  for (const c of r) {
    const l = c.srs.interval;
    a += l, l > s && (s = l);
    for (const d of n)
      if (l >= d.minDays && l < d.maxDays) {
        d.count++;
        break;
      }
  }
  const i = r.length > 0 ? a / r.length : 0;
  return {
    buckets: n,
    averageInterval: i,
    maxInterval: s
  };
}
async function sc(e, t) {
  const r = me.get("intervalDistribution", e, t);
  if (r)
    return r;
  const n = await st(e), a = ua(n, t);
  return me.set("intervalDistribution", a, e, t), a;
}
function fa(e, t) {
  const r = Wt(e, t), n = {
    again: 0,
    hard: 0,
    good: 0,
    easy: 0,
    total: r.length,
    correctRate: 0
  };
  for (const a of r)
    n[a.grade]++;
  return n.total > 0 && (n.correctRate = (n.good + n.easy) / n.total), n;
}
async function ic(e, t, r) {
  const n = me.get("answerButtonStats", e, t, r);
  if (n)
    return n;
  const a = /* @__PURE__ */ new Date(), s = So(t), i = await Lt(e, s, a), c = fa(i, r);
  return me.set("answerButtonStats", c, e, t, r), c;
}
const lc = [
  { label: "1-2", minValue: 1, maxValue: 2 },
  { label: "2-3", minValue: 2, maxValue: 3 },
  { label: "3-4", minValue: 3, maxValue: 4 },
  { label: "4-5", minValue: 4, maxValue: 5 },
  { label: "5-6", minValue: 5, maxValue: 6 },
  { label: "6-7", minValue: 6, maxValue: 7 },
  { label: "7-8", minValue: 7, maxValue: 8 },
  { label: "8-9", minValue: 8, maxValue: 9 },
  { label: "9-10", minValue: 9, maxValue: 10 }
];
function pa(e, t) {
  const r = Ot(e, t), n = lc.map((l) => ({
    label: l.label,
    minValue: l.minValue,
    maxValue: l.maxValue,
    count: 0
  }));
  let a = 0, s = 1 / 0, i = -1 / 0;
  for (const l of r) {
    const d = l.srs.difficulty;
    a += d, d < s && (s = d), d > i && (i = d);
    for (const u of n) {
      if (d >= u.minValue && d < u.maxValue) {
        u.count++;
        break;
      }
      if (d === 10 && u.maxValue === 10) {
        u.count++;
        break;
      }
    }
  }
  const c = r.length > 0 ? a / r.length : 0;
  return r.length === 0 && (s = 0, i = 0), {
    buckets: n,
    averageDifficulty: c,
    minDifficulty: s,
    maxDifficulty: i
  };
}
async function cc(e, t) {
  const r = me.get("difficultyDistribution", e, t);
  if (r)
    return r;
  const n = await st(e), a = pa(n, t);
  return me.set("difficultyDistribution", a, e, t), a;
}
const xa = "statisticsPreferences", Ir = {
  timeRange: "1month",
  selectedDeck: void 0
};
async function ha(e) {
  try {
    const t = await orca.plugins.getData(e, xa);
    if (!t)
      return { ...Ir };
    const r = JSON.parse(t);
    return {
      ...Ir,
      ...r
    };
  } catch (t) {
    return console.warn(`[${e}] 加载统计偏好设置失败:`, t), { ...Ir };
  }
}
async function Co(e, t) {
  try {
    const n = {
      ...await ha(e),
      ...t
    };
    await orca.plugins.setData(e, xa, JSON.stringify(n));
  } catch (r) {
    throw console.error(`[${e}] 保存统计偏好设置失败:`, r), r;
  }
}
async function dc(e, t) {
  await Co(e, { timeRange: t });
}
async function uc(e, t) {
  await Co(e, { selectedDeck: t });
}
const tr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  calculateAnswerButtonStats: fa,
  calculateCardStateDistribution: ca,
  calculateDifficultyDistribution: pa,
  calculateFutureForecast: ia,
  calculateIntervalDistribution: ua,
  calculateReviewHistory: la,
  calculateReviewTimeStats: da,
  calculateTodayStatistics: sa,
  clearStatisticsCache: Zl,
  filterCardsByDeck: Ot,
  filterLogsByDeck: Wt,
  getAnswerButtonStats: ic,
  getCardStateDistribution: oc,
  getDifficultyDistribution: cc,
  getFutureForecast: tc,
  getIntervalDistribution: sc,
  getReviewHistory: rc,
  getReviewTimeStats: nc,
  getStatisticsPreferences: ha,
  getTodayStatistics: ec,
  isToday: aa,
  saveSelectedDeckPreference: uc,
  saveStatisticsPreferences: Co,
  saveTimeRangePreference: dc
}, Symbol.toStringTag, { value: "Module" })), fc = 10, pc = 3, xc = 3, hc = 7, gc = 30;
function yc(e) {
  return e.clozeNumber ? `${e.id}_cloze_${e.clozeNumber}` : e.directionType ? `${e.id}_direction_${e.directionType}` : `${e.id}_basic`;
}
function mc(e) {
  return e.cardId.toString();
}
function vc(e, t) {
  const r = t.filter((i) => (mc(i), e.includes(i.cardId.toString())));
  if (r.length === 0)
    return { recentAgainCount: 0, lastReviewDate: null };
  r.sort((i, c) => c.timestamp - i.timestamp);
  const a = r.slice(0, fc).filter((i) => i.grade === "again").length, s = new Date(r[0].timestamp);
  return { recentAgainCount: a, lastReviewDate: s };
}
function bc(e, t) {
  const r = [];
  return t >= pc && r.push("high_again_rate"), e.srs.lapses >= xc && r.push("high_lapses"), e.srs.difficulty >= hc && r.push("high_difficulty"), r.length === 0 ? { isDifficult: !1, reason: "high_again_rate" } : { isDifficult: !0, reason: r.length > 1 ? "multiple" : r[0] };
}
async function wc(e, t) {
  const r = await st(e), n = t ? r.filter((l) => l.deck === t) : r, a = /* @__PURE__ */ new Date(), s = /* @__PURE__ */ new Date();
  s.setDate(s.getDate() - gc);
  const i = await Lt(e, s, a), c = [];
  for (const l of n) {
    if (l.isNew) continue;
    const d = yc(l), { recentAgainCount: u, lastReviewDate: f } = vc(d, i), { isDifficult: x, reason: h } = bc(l, u);
    x && c.push({
      card: l,
      reason: h,
      recentAgainCount: u,
      totalLapses: l.srs.lapses,
      difficulty: l.srs.difficulty,
      lastReviewDate: f
    });
  }
  return c.sort((l, d) => {
    const u = {
      multiple: 0,
      high_again_rate: 1,
      high_lapses: 2,
      high_difficulty: 3
    }, f = u[l.reason] - u[d.reason];
    return f !== 0 ? f : d.totalLapses - l.totalLapses;
  }), c;
}
const Sc = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getDifficultCards: wc
}, Symbol.toStringTag, { value: "Module" })), Gr = "deckNotes";
async function Cc(e, t, r) {
  try {
    const n = await orca.plugins.getData(e, Gr), a = n ? JSON.parse(n) : {};
    r.trim() === "" ? delete a[t] : a[t] = r.trim(), await orca.plugins.setData(e, Gr, JSON.stringify(a));
  } catch (n) {
    throw console.error(`[${e}] 设置卡组备注失败:`, n), n;
  }
}
async function jc(e) {
  try {
    const t = await orca.plugins.getData(e, Gr);
    return t ? JSON.parse(t) : {};
  } catch (t) {
    return console.warn(`[${e}] 获取所有卡组备注失败:`, t), {};
  }
}
const Jr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getAllDeckNotes: jc,
  setDeckNote: Cc
}, Symbol.toStringTag, { value: "Module" }));
export {
  uo as buildReviewQueue,
  Fn as buildReviewQueueWithChildren,
  mn as calculateDeckStats,
  Un as collectChildCards,
  st as collectReviewCards,
  Bt as extractDeckName,
  Vn as getCardKey,
  Gl as getPluginName,
  Vl as getReviewDeckFilter,
  Kl as getReviewHostPanelId,
  qn as hasChildCards,
  Yl as load,
  Jl as openFlashcardHome,
  Ql as startRepeatReviewSession,
  ql as startReviewSession,
  Ul as unload
};
